package com.lineage;

import java.io.FileInputStream;
import java.util.zip.ZipEntry;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;

public class CompressFile
{
    private static final int BUFFEREDSIZE = 1024;
    
    public synchronized void zip(final String inputFilename, final String zipFilename) throws IOException {
        this.zip(new File(inputFilename), zipFilename);
    }
    
    public synchronized void zip(final File inputFile, final String zipFilename) throws IOException {
        final ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFilename));
        try {
            this.zip(inputFile, out, "");
        }
        catch (IOException e) {
            throw e;
        }
        finally {
            out.close();
        }
        out.close();
    }
    
    private synchronized void zip(final File inputFile, final ZipOutputStream out, String base) throws IOException {
        if (inputFile.isDirectory()) {
            final File[] inputFiles = inputFile.listFiles();
            out.putNextEntry(new ZipEntry(String.valueOf(base) + "/"));
            base = ((base.length() == 0) ? "" : (String.valueOf(base) + "/"));
            for (int i = 0; i < inputFiles.length; ++i) {
                this.zip(inputFiles[i], out, String.valueOf(base) + inputFiles[i].getName());
            }
        }
        else {
            if (base.length() > 0) {
                out.putNextEntry(new ZipEntry(base));
            }
            else {
                out.putNextEntry(new ZipEntry(inputFile.getName()));
            }
            final FileInputStream in = new FileInputStream(inputFile);
            try {
                final byte[] by = new byte[1024];
                int c;
                while ((c = in.read(by)) != -1) {
                    out.write(by, 0, c);
                }
            }
            catch (IOException e) {
                throw e;
            }
            finally {
                in.close();
            }
            in.close();
        }
    }
}
