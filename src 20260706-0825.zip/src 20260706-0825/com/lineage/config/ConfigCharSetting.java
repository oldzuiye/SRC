package com.lineage.config;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.Properties;

public final class ConfigCharSetting
{
    public static int PRINCE_MAX_HP;
    public static int PRINCE_MAX_MP;
    public static int KNIGHT_MAX_HP;
    public static int KNIGHT_MAX_MP;
    public static int ELF_MAX_HP;
    public static int ELF_MAX_MP;
    public static int WIZARD_MAX_HP;
    public static int WIZARD_MAX_MP;
    public static int DARKELF_MAX_HP;
    public static int DARKELF_MAX_MP;
    public static int DRAGONKNIGHT_MAX_HP;
    public static int DRAGONKNIGHT_MAX_MP;
    public static int ILLUSIONIST_MAX_HP;
    public static int ILLUSIONIST_MAX_MP;
    public static int WARRIOR_MAX_HP;
    public static int WARRIOR_MAX_MP;
    private static final String CHAR_SETTINGS_CONFIG_FILE = "./config/charsettings.properties";
    
    public static void load() throws ConfigErrorException {
        final Properties set = new Properties();
        try {
            final InputStream is = new FileInputStream(new File("./config/charsettings.properties"));
            set.load(is);
            is.close();
            ConfigCharSetting.PRINCE_MAX_HP = Integer.parseInt(set.getProperty("PrinceMaxHP", "1000"));
            ConfigCharSetting.PRINCE_MAX_MP = Integer.parseInt(set.getProperty("PrinceMaxMP", "800"));
            ConfigCharSetting.KNIGHT_MAX_HP = Integer.parseInt(set.getProperty("KnightMaxHP", "1400"));
            ConfigCharSetting.KNIGHT_MAX_MP = Integer.parseInt(set.getProperty("KnightMaxMP", "600"));
            ConfigCharSetting.ELF_MAX_HP = Integer.parseInt(set.getProperty("ElfMaxHP", "1000"));
            ConfigCharSetting.ELF_MAX_MP = Integer.parseInt(set.getProperty("ElfMaxMP", "900"));
            ConfigCharSetting.WIZARD_MAX_HP = Integer.parseInt(set.getProperty("WizardMaxHP", "800"));
            ConfigCharSetting.WIZARD_MAX_MP = Integer.parseInt(set.getProperty("WizardMaxMP", "1200"));
            ConfigCharSetting.DARKELF_MAX_HP = Integer.parseInt(set.getProperty("DarkelfMaxHP", "1000"));
            ConfigCharSetting.DARKELF_MAX_MP = Integer.parseInt(set.getProperty("DarkelfMaxMP", "900"));
            ConfigCharSetting.DRAGONKNIGHT_MAX_HP = Integer.parseInt(set.getProperty("DragonKnightMaxHP", "1400"));
            ConfigCharSetting.DRAGONKNIGHT_MAX_MP = Integer.parseInt(set.getProperty("DragonKnightMaxMP", "600"));
            ConfigCharSetting.ILLUSIONIST_MAX_HP = Integer.parseInt(set.getProperty("IllusionistMaxHP", "900"));
            ConfigCharSetting.ILLUSIONIST_MAX_MP = Integer.parseInt(set.getProperty("IllusionistMaxMP", "1100"));
            ConfigCharSetting.WARRIOR_MAX_HP = Integer.parseInt(set.getProperty("WarriorMaxHP", "1400"));
            ConfigCharSetting.WARRIOR_MAX_MP = Integer.parseInt(set.getProperty("WarriorMaxMP", "600"));
        }
        catch (Exception e) {
            throw new ConfigErrorException("設置檔案遺失: ./config/charsettings.properties");
        }
        finally {
            set.clear();
        }
        set.clear();
    }
}
