package com.lineage.config;

import java.io.InputStream;
import java.io.Reader;
import java.io.LineNumberReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.File;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import java.util.Map;
import org.apache.commons.logging.Log;

public class ConfigKill
{
    private static final Log _log;
    public static final Map<Integer, String> KILL_TEXT_LIST;
    public static int KILLLEVEL;
    private static final String _kill_text = "./config/kill_desc.txt";
    
    static {
        _log = LogFactory.getLog((Class)ConfigKill.class);
        KILL_TEXT_LIST = new HashMap<Integer, String>();
        ConfigKill.KILLLEVEL = 90;
    }
    
    public static void load() throws ConfigErrorException {
        try {
            final InputStream is = new FileInputStream(new File("./config/kill_desc.txt"));
            final InputStreamReader isr = new InputStreamReader(is, "utf-8");
            final LineNumberReader lnr = new LineNumberReader(isr);
            boolean isWhile = false;
            int i = 1;
            String desc = null;
            while ((desc = lnr.readLine()) != null) {
                if (!isWhile) {
                    isWhile = true;
                }
                else {
                    if (desc.trim().length() == 0) {
                        continue;
                    }
                    if (desc.startsWith("#")) {
                        continue;
                    }
                    if (desc.startsWith("KILLLEVEL")) {
                        desc = desc.replaceAll(" ", "");
                        ConfigKill.KILLLEVEL = Integer.parseInt(desc.substring(10));
                    }
                    else {
                        ConfigKill.KILL_TEXT_LIST.put(new Integer(i++), desc);
                    }
                }
            }
            is.close();
            isr.close();
            lnr.close();
        }
        catch (Exception e) {
            ConfigKill._log.error((Object)"設置檔案遺失: ./config/kill_desc.txt");
        }
    }
}
