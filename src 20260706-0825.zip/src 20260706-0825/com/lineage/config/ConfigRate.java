package com.lineage.config;

import java.io.InputStream;
import java.util.Calendar;
import java.io.FileInputStream;
import java.io.File;
import java.util.Properties;

/**
 * 伺服器倍率設定
 * 此類別負責讀取 rates.properties 設定檔，並存儲伺服器倍率相關的變數
 * - 週末經驗與掉寶倍率調整
 * - 每日特定時段經驗與掉寶倍率調整
 * - 其他遊戲倍率，如 武器、裝備強化機率、商店價格等
 */
public final class ConfigRate {
    
    // 預設倍率 (從 rates.properties 讀取)
    public static double DEFAULT_EXP_RATE;   // 預設經驗倍率
    public static double DEFAULT_DROP_RATE;  // 預設掉寶倍率
    
    // 經驗倍率
    public static double RATE_XP;                   // 基本經驗倍率
    public static double WEEKEND_RATE_XP;           // 週末經驗倍率
    public static boolean IS_WEEKEND_RATE_XP;       // 是否啟用週末經驗倍率
    public static double DAILY_RATE_XP;             // 每日特定時段經驗倍率
    public static boolean IS_DAILY_RATE_XP;         // 是否啟用每日特定時段經驗倍率

    // 掉寶倍率
    public static double RATE_DROP_ITEMS;           // 基本掉寶倍率
    public static boolean IS_WEEKEND_RATE_DROP_ITEMS;  // 是否啟用週末掉寶倍率
    public static double WEEKEND_RATE_DROP_ITEMS;   // 週末掉寶倍率
    public static boolean IS_DAILY_RATE_DROP_ITEMS; // 是否啟用每日特定時段掉寶倍率
    public static double DAILY_RATE_DROP_ITEMS;     // 每日特定時段掉寶倍率
    public static double RATE_DROP_ADENA;           // 金幣掉落倍率

    // 其他遊戲倍率
    public static double RATE_LA;                   // 正義值倍率
    public static double RATE_KARMA;                // 友好度倍率
    public static int ENCHANT_CHANCE_WEAPON;        // 武器強化成功機率
    public static int ENCHANT_CHANCE_ARMOR;         // 防具強化成功機率
    public static int ATTR_ENCHANT_CHANCE;          // 屬性強化成功機率
    public static double RATE_WEIGHT_LIMIT;         // 角色負重倍率
    public static double RATE_WEIGHT_LIMIT_PET;     // 寵物負重倍率
    public static double RATE_SHOP_SELLING_PRICE;   // 商店販賣價格倍率
    public static double RATE_SHOP_PURCHASING_PRICE;// 商店購買價格倍率

    // 物品製作成功機率
    public static int CREATE_CHANCE_DIARY;
    public static int CREATE_CHANCE_RECOLLECTION;
    public static int CREATE_CHANCE_MYSTERIOUS;
    public static int CREATE_CHANCE_PROCESSING;
    public static int CREATE_CHANCE_PROCESSING_DIAMOND;
    public static int CREATE_CHANCE_DANTES;
    public static int CREATE_CHANCE_ANCIENT_AMULET;
    public static int CREATE_CHANCE_HISTORY_BOOK;

    // 設定檔路徑
    private static final String RATES_CONFIG_FILE = "./config/rates.properties";

    // 預設值初始化
    static {
        ConfigRate.IS_WEEKEND_RATE_DROP_ITEMS = false;
        ConfigRate.IS_WEEKEND_RATE_XP = false;
        ConfigRate.IS_DAILY_RATE_XP = false;
        ConfigRate.IS_DAILY_RATE_DROP_ITEMS = false;
    }

    /**
     * 讀取倍率設定檔案 rates.properties
     * @throws ConfigErrorException 當設定檔遺失或格式錯誤時拋出例外
     */
    public static void load() throws ConfigErrorException {
        final Properties set = new Properties();
        try (InputStream is = new FileInputStream(new File(RATES_CONFIG_FILE))) {
            set.load(is);

            // **讀取 `rates.properties` 內的預設倍率**
            DEFAULT_EXP_RATE = Double.parseDouble(set.getProperty("RateExp", "1.0"));
            DEFAULT_DROP_RATE = Double.parseDouble(set.getProperty("RateDropItems", "1.0"));
            		
            // 讀取基本倍率設定
            ConfigRate.RATE_XP = Double.parseDouble(set.getProperty("RateExp", "1.0"));
            ConfigRate.IS_WEEKEND_RATE_XP = Boolean.parseBoolean(set.getProperty("Is_WeekendRateXp", "false"));
            ConfigRate.WEEKEND_RATE_XP = Double.parseDouble(set.getProperty("WeekendRateXp", "2.0"));
            ConfigRate.IS_DAILY_RATE_XP = Boolean.parseBoolean(set.getProperty("Is_DailyRateXp", "false"));
            ConfigRate.DAILY_RATE_XP = Double.parseDouble(set.getProperty("DailyRateXp", "1.5"));

            // 讀取掉寶倍率設定
            ConfigRate.RATE_DROP_ADENA = Double.parseDouble(set.getProperty("RateDropAdena", "1.0"));
            ConfigRate.RATE_DROP_ITEMS = Double.parseDouble(set.getProperty("RateDropItems", "1.0"));
            ConfigRate.IS_WEEKEND_RATE_DROP_ITEMS = Boolean.parseBoolean(set.getProperty("Is_WeekendRateDropItems", "false"));
            ConfigRate.WEEKEND_RATE_DROP_ITEMS = Double.parseDouble(set.getProperty("WeekendRateDropItems", "2.0"));
            ConfigRate.IS_DAILY_RATE_DROP_ITEMS = Boolean.parseBoolean(set.getProperty("Is_DailyRateDropItems", "false"));
            ConfigRate.DAILY_RATE_DROP_ITEMS = Double.parseDouble(set.getProperty("DailyRateDropItems", "1.5"));

            // 讀取裝備強化機率
            ConfigRate.ENCHANT_CHANCE_WEAPON = Integer.parseInt(set.getProperty("EnchantChanceWeapon", "68"));
            ConfigRate.ENCHANT_CHANCE_ARMOR = Integer.parseInt(set.getProperty("EnchantChanceArmor", "52"));
            ConfigRate.ATTR_ENCHANT_CHANCE = Integer.parseInt(set.getProperty("AttrEnchantChance", "10"));

            // 讀取角色與寵物負重倍率
            ConfigRate.RATE_WEIGHT_LIMIT = Double.parseDouble(set.getProperty("RateWeightLimit", "1"));
            ConfigRate.RATE_WEIGHT_LIMIT_PET = Double.parseDouble(set.getProperty("RateWeightLimitForPet", "1"));

            // 讀取商店販賣與購買價格倍率
            ConfigRate.RATE_SHOP_SELLING_PRICE = Double.parseDouble(set.getProperty("RateShopSellingPrice", "1.0"));
            ConfigRate.RATE_SHOP_PURCHASING_PRICE = Double.parseDouble(set.getProperty("RateShopPurchasingPrice", "1.0"));
            
            ConfigRate.RATE_LA = Double.parseDouble(set.getProperty("RateLawful", "1.0"));
            ConfigRate.RATE_KARMA = Double.parseDouble(set.getProperty("RateKarma", "1.0"));
            ConfigRate.CREATE_CHANCE_DIARY = Integer.parseInt(set.getProperty("CreateChanceDiary", "33"));
            ConfigRate.CREATE_CHANCE_RECOLLECTION = Integer.parseInt(set.getProperty("CreateChanceRecollection", "90"));
            ConfigRate.CREATE_CHANCE_MYSTERIOUS = Integer.parseInt(set.getProperty("CreateChanceMysterious", "90"));
            ConfigRate.CREATE_CHANCE_PROCESSING = Integer.parseInt(set.getProperty("CreateChanceProcessing", "90"));
            ConfigRate.CREATE_CHANCE_PROCESSING_DIAMOND = Integer.parseInt(set.getProperty("CreateChanceProcessingDiamond", "90"));
            ConfigRate.CREATE_CHANCE_DANTES = Integer.parseInt(set.getProperty("CreateChanceDantes", "50"));
            ConfigRate.CREATE_CHANCE_ANCIENT_AMULET = Integer.parseInt(set.getProperty("CreateChanceAncientAmulet", "90"));
            ConfigRate.CREATE_CHANCE_HISTORY_BOOK = Integer.parseInt(set.getProperty("CreateChanceHistoryBook", "50"));

            // 讀取目前時間，確保倍率是否需要變更
            final Calendar cal = Calendar.getInstance();
            final int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
            final int hourOfDay = cal.get(Calendar.HOUR_OF_DAY);

            // 週末經驗與掉寶倍率 (週五 19:00 ~ 週一 07:00)
            final boolean isWeekend = (dayOfWeek == Calendar.FRIDAY && hourOfDay >= 19)
                    || (dayOfWeek == Calendar.SATURDAY)
                    || (dayOfWeek == Calendar.SUNDAY)
                    || (dayOfWeek == Calendar.MONDAY && hourOfDay < 7);

            // 每日晚間經驗與掉寶加成時段 (19:00 ~ 01:00)
            final boolean isDailyBoost = (hourOfDay >= 19 || hourOfDay < 1);

         // **使用 `DEFAULT_EXP_RATE` 作為回復基準**
            if (IS_WEEKEND_RATE_XP && isWeekend) {
                RATE_XP = WEEKEND_RATE_XP;
            } else if (IS_DAILY_RATE_XP && isDailyBoost) {
                RATE_XP = DAILY_RATE_XP;
            } else {
                RATE_XP = DEFAULT_EXP_RATE;
            }

            // **使用 `DEFAULT_DROP_RATE` 作為回復基準**
            if (IS_WEEKEND_RATE_DROP_ITEMS && isWeekend) {
                RATE_DROP_ITEMS = WEEKEND_RATE_DROP_ITEMS;
            } else if (IS_DAILY_RATE_DROP_ITEMS && isDailyBoost) {
                RATE_DROP_ITEMS = DAILY_RATE_DROP_ITEMS;
            } else {
                RATE_DROP_ITEMS = DEFAULT_DROP_RATE;
            }
            // 設定經驗倍率
            if (ConfigRate.IS_WEEKEND_RATE_XP && isWeekend) {
                ConfigRate.RATE_XP = ConfigRate.WEEKEND_RATE_XP;
            } else if (ConfigRate.IS_DAILY_RATE_XP && isDailyBoost) {
                ConfigRate.RATE_XP = ConfigRate.DAILY_RATE_XP;
            } else {
                ConfigRate.RATE_XP = Double.parseDouble(set.getProperty("RateExp", "1.0")); // ⚠ **確保倍率回歸預設**
            }

            // 設定掉寶倍率
            if (ConfigRate.IS_WEEKEND_RATE_DROP_ITEMS && isWeekend) {
                ConfigRate.RATE_DROP_ITEMS = ConfigRate.WEEKEND_RATE_DROP_ITEMS;
            } else if (ConfigRate.IS_DAILY_RATE_DROP_ITEMS && isDailyBoost) {
                ConfigRate.RATE_DROP_ITEMS = ConfigRate.DAILY_RATE_DROP_ITEMS;
            } else {
                ConfigRate.RATE_DROP_ITEMS = Double.parseDouble(set.getProperty("RateDropItems", "1.0")); // ⚠ **確保倍率回歸預設**
            }

        } catch (Exception e) {
            throw new ConfigErrorException("設定檔案遺失: " + RATES_CONFIG_FILE);
        } finally {
            set.clear();
        }
    }
}
