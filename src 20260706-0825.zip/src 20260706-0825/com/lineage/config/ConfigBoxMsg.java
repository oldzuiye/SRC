package com.lineage.config;

import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_BoxMessage;
import com.lineage.server.world.World;
import java.io.InputStream;
import java.io.Reader;
import java.io.LineNumberReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.File;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import java.util.Random;
import java.util.Map;
import org.apache.commons.logging.Log;

public class ConfigBoxMsg
{
    private static final Log _log;
    private static final Map<Integer, String> _box_msg_list;
    private static final Random _random;
    public static boolean ISMSG;
    private static final String _box_text = "./config/box_desc.txt";
    
    static {
        _log = LogFactory.getLog((Class)ConfigBoxMsg.class);
        _box_msg_list = new HashMap<Integer, String>();
        _random = new Random();
        ConfigBoxMsg.ISMSG = false;
    }
    
    public static void load() throws ConfigErrorException {
        try {
            final InputStream is = new FileInputStream(new File("./config/box_desc.txt"));
            final InputStreamReader isr = new InputStreamReader(is, "utf-8");
            final LineNumberReader lnr = new LineNumberReader(isr);
            boolean isWhile = false;
            int i = 1;
            String desc = null;
            while ((desc = lnr.readLine()) != null) {
                if (!isWhile) {
                    isWhile = true;
                }
                else {
                    if (desc.trim().length() == 0) {
                        continue;
                    }
                    if (desc.startsWith("#")) {
                        continue;
                    }
                    if (desc.startsWith("ISMSG")) {
                        desc = desc.replaceAll(" ", "");
                        ConfigBoxMsg.ISMSG = Boolean.parseBoolean(desc.substring(6));
                    }
                    else {
                        ConfigBoxMsg._box_msg_list.put(new Integer(i++), desc);
                    }
                }
            }
            is.close();
            isr.close();
            lnr.close();
        }
        catch (Exception e) {
            ConfigBoxMsg._log.error((Object)"設置檔案遺失: ./config/box_desc.txt");
        }
    }
    
    public static void msg(final String string1, final String string2, final String string3) {
        try {
            final String msg = ConfigBoxMsg._box_msg_list.get(ConfigBoxMsg._random.nextInt(ConfigBoxMsg._box_msg_list.size()) + 1);
            if (msg != null) {
                World.get().broadcastPacketToAll(new S_BoxMessage("\\aE玩家 -> [ " + string1 + " ] "));
                World.get().broadcastPacketToAll(new S_BoxMessage("\\aE經由 -> [ " + string2 + " ] "));
                World.get().broadcastPacketToAll(new S_BoxMessage("\\aE獲得 -> [ " + string3 + " ] "));
            }
        }
        catch (Exception e) {
            ConfigBoxMsg._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
