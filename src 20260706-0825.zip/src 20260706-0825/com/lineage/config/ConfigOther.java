package com.lineage.config;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.Properties;

public final class ConfigOther
{
    public static boolean SPEED;
    public static double SPEED_TIME;
    public static boolean KILLRED;
    public static int RATE_XP_WHO;
    public static boolean CLANDEL;
    public static boolean CLANTITLE;
    public static int CLANCOUNT;
    public static boolean LIGHT;
    public static int WEAPON100;
    public static int ARMOR100;
    public static boolean HPBAR;
    public static boolean SHOPINFO;
    public static int HOMEHPR;
    public static int HOMEMPR;
    public static int INNHPR;
    public static int INNMPR;
    public static int CASTLEHPR;
    public static int CASTLEMPR;
    public static int FORESTHPR;
    public static int FORESTMPR;
    public static boolean WAR_DOLL;
    public static boolean WAR_SOUL;
    public static int SET_GLOBAL;
    public static int SET_GLOBAL_COUNT;
    public static int SET_GLOBAL_TIME;
    public static int ENCOUNTER_LV;
    public static int ILLEGAL_SPEEDUP_PUNISHMENT;
    public static boolean KILLPink;
    public static boolean NewCreate;
    public static boolean NEW_ENCHANT_LV;
    public static int ENCHANT_WEAPON;
    public static int ENCHANT_ARMOR;
    private static final String LIANG = "./config/other.properties";
    
    static {
        ConfigOther.SPEED = false;
        ConfigOther.SPEED_TIME = 1.0;
        ConfigOther.KILLRED = true;
        ConfigOther.RATE_XP_WHO = 1;
        ConfigOther.KILLPink = true;
        ConfigOther.NewCreate = false;
        ConfigOther.NEW_ENCHANT_LV = true;
    }
    
    public static void load() throws ConfigErrorException {
        final Properties set = new Properties();
        try {
            final InputStream is = new FileInputStream(new File("./config/other.properties"));
            set.load(is);
            is.close();
            ConfigOther.SPEED = Boolean.parseBoolean(set.getProperty("speed", "false"));
            ConfigOther.SPEED_TIME = Double.parseDouble(set.getProperty("speed_time", "1.0"));
            ConfigOther.ILLEGAL_SPEEDUP_PUNISHMENT = Integer.parseInt(set.getProperty("Punishment", "0"));
            ConfigOther.ENCOUNTER_LV = Integer.parseInt(set.getProperty("encounter_lv", "20"));
            ConfigOther.KILLRED = Boolean.parseBoolean(set.getProperty("kill_red", "false"));
            ConfigOther.NewCreate = Boolean.parseBoolean(set.getProperty("NewCreate", "false"));
            ConfigOther.RATE_XP_WHO = Integer.parseInt(set.getProperty("rate_xp_who", "1"));
            ConfigOther.CLANDEL = Boolean.parseBoolean(set.getProperty("clanadel", "false"));
            ConfigOther.CLANTITLE = Boolean.parseBoolean(set.getProperty("clanatitle", "false"));
            ConfigOther.CLANCOUNT = Integer.parseInt(set.getProperty("clancount", "100"));
            ConfigOther.LIGHT = Boolean.parseBoolean(set.getProperty("light", "false"));
            ConfigOther.WEAPON100 = Integer.parseInt(set.getProperty("weapon100", "30"));
            ConfigOther.ARMOR100 = Integer.parseInt(set.getProperty("armor100", "30"));
            ConfigOther.HPBAR = Boolean.parseBoolean(set.getProperty("hpbar", "false"));
            ConfigOther.SHOPINFO = Boolean.parseBoolean(set.getProperty("shopinfo", "false"));
            ConfigOther.HOMEHPR = Integer.parseInt(set.getProperty("homehpr", "10"));
            ConfigOther.HOMEMPR = Integer.parseInt(set.getProperty("homempr", "10"));
            ConfigOther.INNHPR = Integer.parseInt(set.getProperty("innhpr", "10"));
            ConfigOther.INNMPR = Integer.parseInt(set.getProperty("innmpr", "10"));
            ConfigOther.CASTLEHPR = Integer.parseInt(set.getProperty("castlehpr", "10"));
            ConfigOther.CASTLEMPR = Integer.parseInt(set.getProperty("castlempr", "10"));
            ConfigOther.FORESTHPR = Integer.parseInt(set.getProperty("foresthpr", "10"));
            ConfigOther.FORESTMPR = Integer.parseInt(set.getProperty("forestmpr", "10"));
            ConfigOther.SET_GLOBAL = Integer.parseInt(set.getProperty("set_global", "100"));
            ConfigOther.SET_GLOBAL_COUNT = Integer.parseInt(set.getProperty("set_global_count", "100"));
            ConfigOther.SET_GLOBAL_TIME = Integer.parseInt(set.getProperty("set_global_time", "5"));
            ConfigOther.WAR_DOLL = Boolean.parseBoolean(set.getProperty("war_doll", "true"));
            ConfigOther.WAR_SOUL = Boolean.parseBoolean(set.getProperty("war_soul", "true"));
            ConfigOther.KILLPink = Boolean.parseBoolean(set.getProperty("kill_pink", "false"));
            ConfigOther.NEW_ENCHANT_LV = Boolean.parseBoolean(set.getProperty("newEnchantLv", "true"));
            ConfigOther.ENCHANT_WEAPON = Integer.parseInt(set.getProperty("EnchantWeapon", "1"));
            ConfigOther.ENCHANT_ARMOR = Integer.parseInt(set.getProperty("EnchantArmor", "1"));
        }
        catch (Exception e) {
            throw new ConfigErrorException("設置檔案遺失: ./config/other.properties");
        }
        finally {
            set.clear();
        }
        set.clear();
        set.clear();
    }
}
