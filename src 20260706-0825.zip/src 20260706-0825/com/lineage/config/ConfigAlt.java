package com.lineage.config;

import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.File;
import java.util.Properties;
import java.util.ArrayList;
import java.util.List;

public final class ConfigAlt
{
	public static int ALT_ITEM_DELETION_COUNTDOWN_TIME;
	public static short GLOBAL_CHAT_LEVEL;
    public static short WHISPER_CHAT_LEVEL;
    public static byte AUTO_LOOT;
    public static int LOOTING_RANGE;
    public static boolean ALT_NONPVP;
    public static boolean ALT_PUNISHMENT;
    public static boolean ALT_ATKMSG;
    public static boolean CLAN_ALLIANCE;
    public static int ALT_ITEM_DELETION_TIME;
    public static boolean ALT_WHO_COMMANDX;
    public static int ALT_WHO_TYPE;
    public static double ALT_WHO_COUNT;
    public static int ALT_WAR_TIME;
    public static int ALT_WAR_TIME_UNIT;
    public static int ALT_WAR_INTERVAL;
    public static int ALT_WAR_INTERVAL_UNIT;
    public static int ALT_RATE_OF_DUTY;
    public static boolean SPAWN_HOME_POINT;
    public static int SPAWN_HOME_POINT_RANGE;
    public static int SPAWN_HOME_POINT_COUNT;
    public static int SPAWN_HOME_POINT_DELAY;
    public static int ELEMENTAL_STONE_AMOUNT;
    public static int HOUSE_TAX_INTERVAL;
    public static int HOUSE_TAX_ADENA;
    public static int MAX_DOLL_COUNT;
    public static int MAX_NPC_ITEM;
    public static int MAX_PERSONAL_WAREHOUSE_ITEM;
    public static int MAX_CLAN_WAREHOUSE_ITEM;
    public static int DELETE_CHARACTER_AFTER_LV;
    public static boolean DELETE_CHARACTER_AFTER_7DAYS;
    public static int NPC_DELETION_TIME;
    public static int DEFAULT_CHARACTER_SLOT;
    public static int MEDICINE;
    public static int POWER;
    public static int POWERMEDICINE;
    public static boolean DORP_ITEM;
    public static final int MAX_NPC = 35;
    public static int MAX_PARTY_SIZE;
    public static int METE_LEVEL;
    public static int METE_MAX_COUNT;
    public static int METE_EXP_REDUCE;
    public static int METE_REMAIN_HP;
    public static int METE_REMAIN_MP;
    public static boolean METE_GIVE_POTION;
    public static boolean APPRENTICE_SWITCH;
    public static int APPRENTICE_LEVEL;
    public static int APPRENTICE_EXP_BONUS;
    public static int APPRENTICE_ITEM_ID;
    public static int ELYOS_ENCHANT_SUCCESS;
    public static int Orim_ENCHANT_SUCCESS;
    public static int Smith_ENCHANT_SUCCESS;
    public static int Famous_ENCHANT_SUCCESS;
    public static int Talented_ENCHANT_SUCCESS;
    public static List<Integer> DRAGON_KEY_MAP_LIST;
    public static List<Integer> GIVE_ITEM_LIST;
    public static List<Integer> NO_AI_MAP_LIST;
    public static List<String> NO_AI_SCAN_ACCOUNTS;
    public static boolean WHO_ONLINE_MSG_ON;
    public static boolean GM_OVERHEARD;
    public static boolean GM_OVERHEARD0;
    public static boolean GM_OVERHEARD4;
    public static boolean GM_OVERHEARD11;
    public static boolean GM_OVERHEARD13;
    public static boolean ALT_WARPUNISHMENT;
    public static int CHAR_BOOK_INIT_COUNT;
    public static int CHAR_BOOK_MAX_CHARGE;
    public static boolean BOSS_BONUS_DROP_SWITCH;
    private static final String ALT_SETTINGS_FILE = "./config/altsettings.properties";
    
    
    static {
        ConfigAlt.DRAGON_KEY_MAP_LIST = new ArrayList<Integer>();
        ConfigAlt.GIVE_ITEM_LIST = new ArrayList<Integer>();
        ConfigAlt.NO_AI_MAP_LIST = new ArrayList<Integer>();
        ConfigAlt.NO_AI_SCAN_ACCOUNTS = new ArrayList<>();
    }
 
    public static void load() throws ConfigErrorException {
        final Properties set = new Properties();
        try {
            final InputStream is = new FileInputStream(new File("./config/altsettings.properties"));
            final InputStreamReader isr = new InputStreamReader(is, "utf-8");
            set.load(isr);
            is.close();
            ConfigAlt.WHO_ONLINE_MSG_ON = Boolean.parseBoolean(set.getProperty("WHO_ONLINE_MSG_ON", "true"));
            ConfigAlt.BOSS_BONUS_DROP_SWITCH = Boolean.parseBoolean(set.getProperty("BOSS_BONUS_DROP_SWITCH", "false"));
            ConfigAlt.GM_OVERHEARD = Boolean.parseBoolean(set.getProperty("GM_OVERHEARD", "false"));
            ConfigAlt.GM_OVERHEARD0 = Boolean.parseBoolean(set.getProperty("GM_OVERHEARD0", "false"));
            ConfigAlt.GM_OVERHEARD4 = Boolean.parseBoolean(set.getProperty("GM_OVERHEARD4", "false"));
            ConfigAlt.GM_OVERHEARD11 = Boolean.parseBoolean(set.getProperty("GM_OVERHEARD11", "false"));
            ConfigAlt.GM_OVERHEARD13 = Boolean.parseBoolean(set.getProperty("GM_OVERHEARD13", "false"));
            ConfigAlt.GLOBAL_CHAT_LEVEL = Short.parseShort(set.getProperty("GlobalChatLevel", "30"));
            ConfigAlt.WHISPER_CHAT_LEVEL = Short.parseShort(set.getProperty("WhisperChatLevel", "5"));
            ConfigAlt.AUTO_LOOT = Byte.parseByte(set.getProperty("AutoLoot", "2"));
            ConfigAlt.LOOTING_RANGE = Integer.parseInt(set.getProperty("LootingRange", "3"));
            ConfigAlt.ALT_NONPVP = Boolean.parseBoolean(set.getProperty("NonPvP", "true"));
            ConfigAlt.ALT_PUNISHMENT = Boolean.parseBoolean(set.getProperty("Punishment", "true"));
            ConfigAlt.ALT_WARPUNISHMENT = Boolean.parseBoolean(set.getProperty("WarPunishment", "false"));
            ConfigAlt.CLAN_ALLIANCE = Boolean.parseBoolean(set.getProperty("ClanAlliance", "true"));
            ConfigAlt.ALT_ITEM_DELETION_TIME = Integer.parseInt(set.getProperty("ItemDeletionTime", "10"));
            if (ConfigAlt.ALT_ITEM_DELETION_TIME > 60) {
                ConfigAlt.ALT_ITEM_DELETION_TIME = 60;
            }
            ConfigAlt.ALT_ITEM_DELETION_COUNTDOWN_TIME = Integer.parseInt(
            	    set.getProperty("ItemDeletionCountdownTime", "10")); // 預設為 10 秒

            ConfigAlt.ALT_WHO_COMMANDX = Boolean.parseBoolean(set.getProperty("WhoCommandx", "false"));
            ConfigAlt.ALT_WHO_TYPE = Integer.parseInt(set.getProperty("Who_type", "0"));
            ConfigAlt.ALT_WHO_COUNT = Double.parseDouble(set.getProperty("WhoCommandcount", "1.0"));
            if (ConfigAlt.ALT_WHO_COUNT < 1.0) {
                ConfigAlt.ALT_WHO_COUNT = 1.0;
            }
            String strWar = set.getProperty("WarTime", "2h");
            if (strWar.indexOf("d") >= 0) {
                ConfigAlt.ALT_WAR_TIME_UNIT = 5;
                strWar = strWar.replace("d", "");
            }
            else if (strWar.indexOf("h") >= 0) {
                ConfigAlt.ALT_WAR_TIME_UNIT = 11;
                strWar = strWar.replace("h", "");
            }
            else if (strWar.indexOf("m") >= 0) {
                ConfigAlt.ALT_WAR_TIME_UNIT = 12;
                strWar = strWar.replace("m", "");
            }
            ConfigAlt.ALT_WAR_TIME = Integer.parseInt(strWar);
            strWar = set.getProperty("WarInterval", "4d");
            if (strWar.indexOf("d") >= 0) {
                ConfigAlt.ALT_WAR_INTERVAL_UNIT = 5;
                strWar = strWar.replace("d", "");
            }
            else if (strWar.indexOf("h") >= 0) {
                ConfigAlt.ALT_WAR_INTERVAL_UNIT = 11;
                strWar = strWar.replace("h", "");
            }
            else if (strWar.indexOf("m") >= 0) {
                ConfigAlt.ALT_WAR_INTERVAL_UNIT = 12;
                strWar = strWar.replace("m", "");
            }
            ConfigAlt.ALT_WAR_INTERVAL = Integer.parseInt(strWar);
            ConfigAlt.SPAWN_HOME_POINT = Boolean.parseBoolean(set.getProperty("SpawnHomePoint", "true"));
            ConfigAlt.SPAWN_HOME_POINT_COUNT = Integer.parseInt(set.getProperty("SpawnHomePointCount", "2"));
            ConfigAlt.SPAWN_HOME_POINT_DELAY = Integer.parseInt(set.getProperty("SpawnHomePointDelay", "100"));
            ConfigAlt.SPAWN_HOME_POINT_RANGE = Integer.parseInt(set.getProperty("SpawnHomePointRange", "8"));
            ConfigAlt.ELEMENTAL_STONE_AMOUNT = Integer.parseInt(set.getProperty("ElementalStoneAmount", "300"));
            ConfigAlt.HOUSE_TAX_INTERVAL = Integer.parseInt(set.getProperty("HouseTaxInterval", "10"));
            ConfigAlt.HOUSE_TAX_ADENA = Integer.parseInt(set.getProperty("HouseTaxAdena", "2000"));
            ConfigAlt.MAX_DOLL_COUNT = Integer.parseInt(set.getProperty("MaxDollCount", "1"));
            ConfigAlt.MAX_NPC_ITEM = Integer.parseInt(set.getProperty("MaxNpcItem", "8"));
            ConfigAlt.MAX_PERSONAL_WAREHOUSE_ITEM = Integer.parseInt(set.getProperty("MaxPersonalWarehouseItem", "100"));
            ConfigAlt.MAX_CLAN_WAREHOUSE_ITEM = Integer.parseInt(set.getProperty("MaxClanWarehouseItem", "200"));
            ConfigAlt.DELETE_CHARACTER_AFTER_LV = Integer.parseInt(set.getProperty("DeleteCharacterAfterLV", "60"));
            ConfigAlt.DELETE_CHARACTER_AFTER_7DAYS = Boolean.parseBoolean(set.getProperty("DeleteCharacterAfter7Days", "True"));
            ConfigAlt.NPC_DELETION_TIME = Integer.parseInt(set.getProperty("NpcDeletionTime", "10"));
            ConfigAlt.DEFAULT_CHARACTER_SLOT = Integer.parseInt(set.getProperty("DefaultCharacterSlot", "4"));
            ConfigAlt.MEDICINE = Integer.parseInt(set.getProperty("Medicine", "20"));
            ConfigAlt.POWER = Integer.parseInt(set.getProperty("Power", "35"));
            ConfigAlt.POWERMEDICINE = Integer.parseInt(set.getProperty("MedicinePower", "45"));
            ConfigAlt.DORP_ITEM = Boolean.parseBoolean(set.getProperty("dorpitem", "true"));
            ConfigAlt.MAX_PARTY_SIZE = Integer.parseInt(set.getProperty("MaxPT", "8"));
            ConfigAlt.METE_LEVEL = Integer.parseInt(set.getProperty("MeteLevel", "99"));
            ConfigAlt.METE_MAX_COUNT = Integer.parseInt(set.getProperty("MeteMaxCount", "20"));
            ConfigAlt.METE_EXP_REDUCE = Integer.parseInt(set.getProperty("MeteExpReduce", "0"));
            ConfigAlt.METE_REMAIN_HP = Integer.parseInt(set.getProperty("MeteRemainHp", "15"));
            ConfigAlt.METE_REMAIN_MP = Integer.parseInt(set.getProperty("MeteRemainMp", "15"));
            ConfigAlt.METE_GIVE_POTION = Boolean.parseBoolean(set.getProperty("MeteGivePotion", "false"));
            ConfigAlt.APPRENTICE_SWITCH = Boolean.parseBoolean(set.getProperty("ApprenticeSwitch", "false"));
            ConfigAlt.APPRENTICE_LEVEL = Integer.parseInt(set.getProperty("ApprenticeLevel", "70"));
            ConfigAlt.APPRENTICE_EXP_BONUS = Integer.parseInt(set.getProperty("ApprenticeExpBonus", "0"));
            ConfigAlt.APPRENTICE_ITEM_ID = Integer.parseInt(set.getProperty("ApprenticeItemId", "30125"));
            ConfigAlt.ELYOS_ENCHANT_SUCCESS = Integer.parseInt(set.getProperty("ElyosEnchantSuccess", "0"));
            ConfigAlt.Orim_ENCHANT_SUCCESS = Integer.parseInt(set.getProperty("OrimEnchantSuccess", "0"));
            ConfigAlt.Smith_ENCHANT_SUCCESS = Integer.parseInt(set.getProperty("SmithEnchantSuccess", "0"));
            ConfigAlt.Famous_ENCHANT_SUCCESS = Integer.parseInt(set.getProperty("FamousEnchantSuccess", "0"));
            ConfigAlt.Talented_ENCHANT_SUCCESS = Integer.parseInt(set.getProperty("TalentedEnchantSuccess", "0"));
            ConfigAlt.CHAR_BOOK_INIT_COUNT = Integer.parseInt(set.getProperty("CharBookInitCount", "60"));
            ConfigAlt.CHAR_BOOK_MAX_CHARGE = Integer.parseInt(set.getProperty("CharBookMaxCharge", "4"));
            if (set.getProperty("DragonKeyMapList") != null) {
                String[] split;
                for (int length = (split = set.getProperty("DragonKeyMapList").split(",")).length, i = 0; i < length; ++i) {
                    final String str = split[i];
                    ConfigAlt.DRAGON_KEY_MAP_LIST.add(Integer.parseInt(str));
                }
            }
            if (set.getProperty("GiveItemList") != null) {
                String[] split2;
                for (int length2 = (split2 = set.getProperty("GiveItemList").split(",")).length, j = 0; j < length2; ++j) {
                    final String str = split2[j];
                    ConfigAlt.GIVE_ITEM_LIST.add(Integer.parseInt(str));
                }
            }
            if (set.getProperty("NoAIMapList") != null) {
                String[] split3;
                for (int length3 = (split3 = set.getProperty("NoAIMapList").split(",")).length, k = 0; k < length3; ++k) {
                    final String str = split3[k];
                    ConfigAlt.NO_AI_MAP_LIST.add(Integer.parseInt(str));
                }
            }
            if (set.getProperty("NoAIScanAccounts") != null) {
                String[] split4;
                for (int length4 = (split4 = set.getProperty("NoAIScanAccounts").split(",")).length, m = 0; m < length4; ++m) {
                    final String acc = split4[m].trim().toLowerCase();
                    if (!acc.isEmpty()) {
                        ConfigAlt.NO_AI_SCAN_ACCOUNTS.add(acc);
                    }
                }
            }

        } catch (Exception e) {
            throw new ConfigErrorException("設置檔案遺失: ./config/altsettings.properties");
        } finally {
            set.clear();
        }
    }
}