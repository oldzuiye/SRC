package com.lineage.config;

import java.io.InputStream;
import java.io.Reader;
import java.io.LineNumberReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ConfigDescs
{
    private static final Map<Integer, String> _show_desc;
    private static final String _show_desc_file = "./config/show_desc.txt";
    
    static {
        _show_desc = new HashMap<Integer, String>();
    }
    
    public static void load() throws ConfigErrorException {
        try {
            final InputStream is = new FileInputStream(new File("./config/show_desc.txt"));
            final InputStreamReader isr = new InputStreamReader(is, "utf-8");
            final LineNumberReader lnr = new LineNumberReader(isr);
            boolean isWhile = false;
            int i = 1;
            String desc = null;
            while ((desc = lnr.readLine()) != null) {
                if (!isWhile) {
                    isWhile = true;
                }
                else {
                    if (desc.trim().length() == 0) {
                        continue;
                    }
                    if (desc.startsWith("#")) {
                        continue;
                    }
                    if (desc.startsWith("SERVER_NAME")) {
                        desc = desc.replaceAll(" ", "");
                        Config.SERVERNAME = desc.substring(12);
                    }
                    else {
                        ConfigDescs._show_desc.put(new Integer(i++), desc);
                    }
                }
            }
            is.close();
            isr.close();
            lnr.close();
        }
        catch (Exception e) {
            throw new ConfigErrorException("設置檔案遺失: ./config/show_desc.txt");
        }
    }
    
    public static String getShow(final int nameid) {
        try {
            return ConfigDescs._show_desc.get(new Integer(nameid));
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static int get_show_size() {
        return ConfigDescs._show_desc.size();
    }
}
