package com.lineage.data.item_etcitem.extra;

import com.lineage.server.templates.L1AttrWeapon;
import com.lineage.server.datatables.ExtraAttrWeaponTable;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import java.util.Random;
import com.lineage.data.executor.ItemExecutor;

public class AttrWeaponScroll2 extends ItemExecutor
{
    private static final Random _random;
    private int _attr_id;
    
    static {
        _random = new Random();
    }
    
    public static ItemExecutor get() {
        return new AttrWeaponScroll2();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int targObjId = data[0];
        final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
        if (tgItem == null) {
            return;
        }
        if (tgItem.getItem().getType2() != 1) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        if (tgItem.getBless() >= 128) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        final int EnchantLvl = tgItem.getEnchantLevel();
        final int attrEnchantKind = tgItem.getAttrEnchantKind();
        int attrEnchantLevel = tgItem.getAttrEnchantLevel();
        if (attrEnchantKind != this._attr_id) {
            attrEnchantLevel = 0;
        }
        boolean isUnstable = (tgItem.getItem().get_safeenchant() <= 0); // `-1` 和 `0` 都進入此條件

        if (isUnstable) { 
            if (tgItem.getItem().get_safeenchant() == -1) {
                // **無法強化的武器 (`safeenchant == -1`) 仍然允許屬性強化**
                if (attrEnchantLevel >= 5) {
                    pc.sendPackets(new S_ServerMessage(79)); // 防止超過第五階段
                    return;
                }
            } else if (tgItem.getItem().get_safeenchant() == 0) {
                // **安定 0 (`safeenchant == 0`) 的武器屬性強化規則**
                if (EnchantLvl == 0 && attrEnchantLevel >= 2) { 
                    pc.sendPackets(new S_ServerMessage(79)); // `+0` 不能 `+3`
                    return;
                }
                if (EnchantLvl == 1 && attrEnchantLevel >= 3) {
                    pc.sendPackets(new S_ServerMessage(79)); // `+1` 不能 `+4`
                    return;
                }
                if (EnchantLvl == 2 && attrEnchantLevel >= 4) { 
                    pc.sendPackets(new S_ServerMessage(79)); // `+2` 不能 `+5`
                    return;
                }
                if (EnchantLvl == 3 && attrEnchantLevel >= 5) {
                    pc.sendPackets(new S_ServerMessage(79)); // `+3` 不能 `+5` (避免超過)
                    return;
                }
            }
        } else {
            // **一般武器的屬性強化限制**
            if (EnchantLvl <= 7 && attrEnchantLevel >= 3) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            if (EnchantLvl == 8 && attrEnchantLevel >= 4) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            if (EnchantLvl >= 9 && attrEnchantLevel >= 5) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
        }
        final L1AttrWeapon attrWeapon = ExtraAttrWeaponTable.getInstance().get(this._attr_id, attrEnchantLevel + 1);
        if (attrWeapon == null || attrWeapon.getChance() <= 0) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        pc.getInventory().removeItem(item, 1L);
        if (AttrWeaponScroll2._random.nextInt(100) < attrWeapon.getChance()) {
            pc.sendPackets(new S_ServerMessage(1410, tgItem.getLogName()));
            tgItem.setAttrEnchantKind(this._attr_id);
            tgItem.setAttrEnchantLevel(attrEnchantLevel + 1);
        }
        else {
            pc.sendPackets(new S_ServerMessage(1411, tgItem.getLogName()));
            tgItem.setAttrEnchantKind(this._attr_id);
            tgItem.setAttrEnchantLevel(attrEnchantLevel - 1);
        }
        final int column = 3072;
        pc.getInventory().updateItem(tgItem, column);
        pc.getInventory().saveItem(tgItem, column);
    }
    
    @Override
    public void set_set(final String[] set) {
        try {
            this._attr_id = Integer.parseInt(set[1]);
        }
        catch (Exception ex) {}
    }
}
