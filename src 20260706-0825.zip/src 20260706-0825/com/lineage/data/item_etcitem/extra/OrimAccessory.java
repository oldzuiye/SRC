package com.lineage.data.item_etcitem.extra;

import com.lineage.data.cmd.EnchantExecutor;
import com.lineage.config.ConfigAlt;
import com.lineage.data.cmd.EnchantArmor;
import java.util.Random;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class OrimAccessory extends ItemExecutor
{
    public static ItemExecutor get() {
        return new OrimAccessory();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int targObjId = data[0];
        final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
        if (tgItem == null) {
            return;
        }
        final int safe_enchant = tgItem.getItem().get_safeenchant();
        boolean isErr = false;
        final int use_type = tgItem.getItem().getUseType();
        switch (use_type) {
            case 23:
            case 24:
            case 37:
            case 40: {
                if (tgItem.getItem().get_greater() == 3) {
                    isErr = true;
                }
                if (safe_enchant < 0) {
                    isErr = true;
                    break;
                }
                break;
            }
            default: {
                isErr = true;
                break;
            }
        }
        if (tgItem.getBless() >= 128) {
            isErr = true;
        }
        if (isErr) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        final int enchant_level = tgItem.getEnchantLevel();
        if (enchant_level >= 8) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        pc.getInventory().removeItem(item, 1L);
        final Random random = new Random();
        final int rnd = random.nextInt(100) + 1;
        final EnchantExecutor enchantExecutor = new EnchantArmor();
        if (enchant_level < -6) {
            enchantExecutor.failureEnchant(pc, tgItem);
        }
        else if (rnd <= ConfigAlt.Orim_ENCHANT_SUCCESS) {
            enchantExecutor.successEnchant(pc, tgItem, 1);
        }
        else if (item.getBless() == 0) {
            enchantExecutor.successEnchant(pc, tgItem, 0);
        }
        else if (random.nextBoolean()) {
            enchantExecutor.successEnchant(pc, tgItem, -1);
        }
        else {
            enchantExecutor.successEnchant(pc, tgItem, 0);
        }
    }
}
