package com.lineage.data.item_etcitem.extra;

import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class AttrWeaponScroll extends ItemExecutor
{
    private int _attr_id;
    private int _stage;
    
    public static ItemExecutor get() {
        return new AttrWeaponScroll();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int targObjId = data[0];
        final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
        if (tgItem == null) {
            return;
        }
        if (tgItem.getItem().getType2() != 1) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        if (tgItem.getBless() >= 128) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        final int attrEnchantKind = tgItem.getAttrEnchantKind();
        final int attrEnchantLevel = tgItem.getAttrEnchantLevel();
        if (attrEnchantKind == this._attr_id && attrEnchantLevel >= this._stage) {
            pc.sendPackets(new S_SystemMessage("武器本身階級已超過卷軸階級。"));
            return;
        }
        pc.getInventory().removeItem(item, 1L);
        pc.sendPackets(new S_ServerMessage(1410, tgItem.getLogName()));
        tgItem.setAttrEnchantKind(this._attr_id);
        tgItem.setAttrEnchantLevel(this._stage);
        final int column = 3072;
        pc.getInventory().updateItem(tgItem, column);
        pc.getInventory().saveItem(tgItem, column);
    }
    
    @Override
    public void set_set(final String[] set) {
        try {
            this._attr_id = Integer.parseInt(set[1]);
        }
        catch (Exception ex) {}
        try {
            this._stage = Integer.parseInt(set[2]);
        }
        catch (Exception ex2) {}
    }
}
