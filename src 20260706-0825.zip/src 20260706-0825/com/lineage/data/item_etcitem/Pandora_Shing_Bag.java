package com.lineage.data.item_etcitem;

import com.lineage.data.cmd.CreateNewItem;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Pandora_Shing_Bag extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Pandora_Shing_Bag();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int item_id = 86010;
        final int count = 5;
        CreateNewItem.createNewItem(pc, item_id, count);
    }
}
