package com.lineage.data.item_etcitem.event;

import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.skill.L1BuffUtil;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class SExp150 extends ItemExecutor
{
    public static ItemExecutor get() {
        return new SExp150();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        if (L1BuffUtil.cancelExpSkill_2(pc)) {
            final int time = 900;
            if (pc.getInventory().removeItem(item, 1L) == 1L) {
                pc.setSkillEffect(5000, time * 1000);
                pc.sendPackets(new S_ServerMessage("第二段 經驗值提升150%(900秒)"));
                pc.sendPackets(new S_SkillSound(pc.getId(), 750));
            }
        }
    }
}
