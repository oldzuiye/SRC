package com.lineage.data.item_etcitem.event;

import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import java.util.Calendar;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Item_Mazu extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)Item_Mazu.class);
    }
    
    public static ItemExecutor get() {
        return new Item_Mazu();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            if (item == null) {
                return;
            }
            if (pc == null) {
                return;
            }
            if (pc.is_mazu()) {
                final Calendar cal = Calendar.getInstance();
                final long now_time = cal.getTimeInMillis() / 1000L;
                final long o_time = 2400L - (now_time - pc.get_mazu_time());
                if (o_time <= 2400L) {
                    pc.sendPackets(new S_ServerMessage("\\fV媽祖祝福效果時間尚有" + o_time + "秒"));
                    return;
                }
            }
            pc.getInventory().removeItem(item, 1L);
            pc.set_mazu(true);
            pc.sendPacketsX8(new S_SkillSound(pc.getId(), 7321));
            final Calendar cal = Calendar.getInstance();
            final long h_time = cal.getTimeInMillis() / 1000L;
            pc.set_mazu_time(h_time);
        }
        catch (Exception e) {
            Item_Mazu._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
