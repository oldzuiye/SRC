package com.lineage.data.item_etcitem.event;

import java.util.Calendar;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.skill.L1BuffUtil;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class ExpTime extends ItemExecutor
{
    public static ItemExecutor get() {
        return new ExpTime();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        if (L1BuffUtil.cancelExpSkill(pc)) {
            pc.sendPackets(new S_ServerMessage("\\fX目前沒有一段經驗加倍藥水效果。"));
        }
        if (L1BuffUtil.cancelExpSkill_2(pc)) {
            pc.sendPackets(new S_ServerMessage("\\fY目前沒有二段經驗加倍藥水效果。"));
        }
        if (pc.is_mazu()) {
            final Calendar cal = Calendar.getInstance();
            final long now_time = cal.getTimeInMillis() / 1000L;
            final long o_time = 2400L - (now_time - pc.get_mazu_time());
            if (o_time <= 2400L) {
                pc.sendPackets(new S_ServerMessage("\\fV媽祖祝福效果時間尚有" + o_time + "秒"));
            }
        }
        else {
            pc.sendPackets(new S_ServerMessage("\\fV目前沒有媽祖祝福效果。"));
        }
    }
}
