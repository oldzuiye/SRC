package com.lineage.data.item_etcitem.magicreel;

import com.lineage.server.templates.L1Skills;
import com.lineage.server.model.L1Object;
import com.lineage.server.model.skill.L1SkillUse;
import com.lineage.server.model.skill.L1BuffUtil;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.types.Point;
import com.lineage.server.datatables.SkillsTable;
import com.lineage.server.model.L1Character;
import com.lineage.server.world.World;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class MagicReel_Long extends ItemExecutor
{
    private int _skillid;
    private int _consume;
    
    public MagicReel_Long() {
        this._skillid = 0;
        this._consume = 1;
    }
    
    public static ItemExecutor get() {
        return new MagicReel_Long();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (pc == null) {
            return;
        }
        if (item == null) {
            return;
        }
        if (pc.isInvisble() || pc.isInvisDelay()) {
            pc.sendPackets(new S_ServerMessage(281));
            return;
        }
        final int targetID = data[0];
        final int spellsc_x = data[1];
        final int spellsc_y = data[2];
        if (targetID == pc.getId() || targetID == 0) {
            pc.sendPackets(new S_ServerMessage(281));
            return;
        }
        final L1Object object = World.get().findObject(targetID);
        L1Character target = null;
        if (object instanceof L1Character) {
            target = (L1Character)object;
        }
        if (target == null) {
            return;
        }
        final L1Skills skill = SkillsTable.get().getTemplate(this._skillid);
        if (skill.getRanged() != -1) {
            if (pc.getLocation().getTileLineDistance(target.getLocation()) > skill.getRanged()) {
                pc.sendPackets(new S_SystemMessage("超過技能施放距離，無法使用。"));
                return;
            }
        }
        else if (!pc.getLocation().isInScreen(target.getLocation())) {
            return;
        }
        pc.getInventory().removeItem(item, this._consume);
        L1BuffUtil.cancelAbsoluteBarrier(pc);
        final L1SkillUse l1skilluse = new L1SkillUse();
        l1skilluse.handleCommands(pc, this._skillid, targetID, spellsc_x, spellsc_y, 0, 2);
    }
    
    @Override
    public void set_set(final String[] set) {
        try {
            this._skillid = Integer.parseInt(set[1]);
        }
        catch (Exception ex) {}
        try {
            this._consume = Integer.parseInt(set[2]);
        }
        catch (Exception ex2) {}
    }
}
