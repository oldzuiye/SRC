package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_OwnCharStatus2;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Nostrum extends ItemExecutor
{
    private static final Log _log;
    private int _add_power;
    
    static {
        _log = LogFactory.getLog((Class)Nostrum.class);
    }
    
    public Nostrum() {
        this._add_power = 25;
    }
    
    public static ItemExecutor get() {
        return new Nostrum();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            for (int i = pc.getBaseStr(); i < this._add_power; ++i) {
                pc.addBaseStr(1);
                pc.setBonusStats(pc.getBonusStats() + 1);
            }
            for (int i = pc.getBaseDex(); i < this._add_power; ++i) {
                pc.addBaseDex(1);
                pc.setBonusStats(pc.getBonusStats() + 1);
            }
            for (int i = pc.getBaseCon(); i < this._add_power; ++i) {
                pc.addBaseCon(1);
                pc.setBonusStats(pc.getBonusStats() + 1);
            }
            for (int i = pc.getBaseWis(); i < this._add_power; ++i) {
                pc.addBaseWis(1);
                pc.setBonusStats(pc.getBonusStats() + 1);
            }
            for (int i = pc.getBaseCha(); i < this._add_power; ++i) {
                pc.addBaseCha(1);
                pc.setBonusStats(pc.getBonusStats() + 1);
            }
            for (int i = pc.getBaseInt(); i < this._add_power; ++i) {
                pc.addBaseInt(1);
                pc.setBonusStats(pc.getBonusStats() + 1);
            }
            pc.sendPackets(new S_OwnCharStatus2(pc));
            pc.save();
            pc.getInventory().removeItem(item, 1L);
        }
        catch (Exception ex) {}
    }
    
    @Override
    public void set_set(final String[] set) {
        try {
            this._add_power = Integer.parseInt(set[1]);
            if (this._add_power <= 0) {
                Nostrum._log.error((Object)"Nostrum 設置錯誤:全能力增加數值小於等於0! 使用預設25");
                this._add_power = 25;
            }
        }
        catch (Exception ex) {}
    }
}
