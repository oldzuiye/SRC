package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_Liquor;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Liquor extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Liquor();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        pc.setDrink(true);
        pc.sendPackets(new S_Liquor(pc.getId()));
        pc.getInventory().removeItem(item, 1L);
    }
}
