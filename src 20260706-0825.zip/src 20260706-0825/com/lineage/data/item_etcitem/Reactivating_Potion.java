package com.lineage.data.item_etcitem;

import com.lineage.server.model.L1Teleport;
import com.lineage.server.serverpackets.S_PacketBox;
import com.lineage.server.serverpackets.S_OwnCharStatus;
import com.lineage.server.serverpackets.S_SPMR;
import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.config.ConfigAlt;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Reactivating_Potion extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)Reactivating_Potion.class);
    }
    
    public static ItemExecutor get() {
        return new Reactivating_Potion();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (pc.getMeteLevel() >= ConfigAlt.METE_MAX_COUNT) {
            pc.sendPackets(new S_ServerMessage("超過允許轉生上限: [" + ConfigAlt.METE_MAX_COUNT + "次]"));
            return;
        }
        if (pc.getLevel() < ConfigAlt.METE_LEVEL) {
            pc.sendPackets(new S_ServerMessage("等級太低以至於無法轉生。"));
            return;
        }
        pc.getInventory().removeItem(item, 1L);
        pc.sendPacketsX8(new S_SkillSound(pc.getId(), 191));
        pc.setExp(1L);
        pc.onChangeExp();
        pc.setBonusStats(0);
        pc.setMeteLevel(pc.getMeteLevel() + 1);
        final int randomHp = pc.getMaxHp() * ConfigAlt.METE_REMAIN_HP / 100;
        final int randomMp = pc.getMaxMp() * ConfigAlt.METE_REMAIN_MP / 100;
        pc.addBaseMaxHp((short)randomHp);
        pc.addBaseMaxMp((short)randomMp);
        pc.setCurrentHp(pc.getMaxHp());
        pc.setCurrentMp(pc.getMaxMp());
        pc.resetMeteAbility();
        pc.sendPackets(new S_ServerMessage(822));
        pc.getQuest().set_step(85, 0);
        pc.getQuest().set_step(86, 0);
        pc.getQuest().set_step(87, 0);
        pc.getQuest().set_step(88, 0);
        pc.getQuest().set_step(89, 0);
        pc.getQuest().set_step(90, 0);
        pc.sendPackets(new S_SPMR(pc));
        pc.sendPackets(new S_OwnCharStatus(pc));
        pc.sendPackets(new S_PacketBox(132, pc.getEr()));
        L1Teleport.teleport(pc, 33441, 32809, (short)4, pc.getHeading(), true);
        try {
            pc.save();
        }
        catch (Exception e) {
            Reactivating_Potion._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
