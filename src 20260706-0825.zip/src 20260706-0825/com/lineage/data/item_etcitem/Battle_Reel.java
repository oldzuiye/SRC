package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SPMR;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Battle_Reel extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Battle_Reel();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        if (!pc.hasSkillEffect(8060)) {
            pc.setSkillEffect(8060, 3600000);
            pc.getInventory().removeItem(item, 1L);
            pc.addHitup(3);
            pc.addDmgup(3);
            pc.addBowHitup(3);
            pc.addBowDmgup(3);
            pc.addSp(3);
            pc.sendPackets(new S_SPMR(pc));
            pc.sendPacketsAll(new S_SkillSound(pc.getId(), 6995));
        }
        else {
            final int time = pc.getSkillEffectTimeSec(8060);
            pc.sendPackets(new S_ServerMessage("戰鬥強化狀態 剩餘時間(秒):" + time));
        }
    }
}
