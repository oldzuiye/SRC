package com.lineage.data.item_etcitem.quest;

import java.util.Iterator;
import com.lineage.server.model.L1Teleport;
import com.lineage.server.model.Instance.L1NpcInstance;
import java.util.Map;
import com.lineage.server.world.World;
import com.lineage.server.model.L1Object;
import java.util.HashMap;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class DeLv50Key extends ItemExecutor
{
    public static ItemExecutor get() {
        return new DeLv50Key();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (!pc.isDarkelf()) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        final HashMap<Integer, L1Object> mapList = new HashMap<Integer, L1Object>();
        mapList.putAll(World.get().getVisibleObjects(306));
        int i = 0;
        for (final L1Object tgobj : mapList.values()) {
            if (tgobj instanceof L1NpcInstance) {
                final L1NpcInstance tgnpc = (L1NpcInstance)tgobj;
                if (tgnpc.getNpcId() != 70905 || tgnpc.get_showId() != pc.get_showId()) {
                    continue;
                }
                ++i;
            }
        }
        if (i > 0) {
            pc.sendPackets(new S_ServerMessage(79));
        }
        else if (pc.getMapId() == 306) {
            pc.getInventory().removeItem(item, 1L);
            L1Teleport.teleport(pc, 32591, 32813, (short)306, 5, true);
        }
        else {
            pc.sendPackets(new S_ServerMessage(79));
        }
        mapList.clear();
    }
}
