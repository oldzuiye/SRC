package com.lineage.data.item_etcitem.reel;

import com.lineage.data.cmd.EnchantExecutor;
import com.lineage.data.cmd.EnchantWeapon;
import com.lineage.config.ConfigOther;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Dai_Percentage_Hundred extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Dai_Percentage_Hundred();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int targObjId = data[0];
        final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
        if (tgItem == null) {
            return;
        }
        final int safe_enchant = tgItem.getItem().get_safeenchant();
        boolean isErr = false;
        final int use_type = tgItem.getItem().getUseType();
        switch (use_type) {
            case 1: {
                if (safe_enchant < 0) {
                    isErr = true;
                    break;
                }
                break;
            }
            default: {
                isErr = true;
                break;
            }
        }
        final int weaponId = tgItem.getItem().getItemId();
        if (weaponId >= 246 && weaponId <= 255) {
            isErr = true;
        }
        if (tgItem.getBless() >= 128) {
            isErr = true;
        }
        if (isErr) {
            pc.sendPackets(new S_ServerMessage(79));
            return;
        }
        if (tgItem.getEnchantLevel() < ConfigOther.WEAPON100) {
            pc.getInventory().removeItem(item, 1L);
            final EnchantExecutor enchantExecutor = new EnchantWeapon();
            final int randomELevel = enchantExecutor.randomELevel(tgItem, item.getBless());
            enchantExecutor.successEnchant(pc, tgItem, randomELevel);
        }
        else {
            pc.sendPackets(new S_ServerMessage("已達武器最大強化!"));
        }
    }
}
