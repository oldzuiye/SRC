package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.S_PacketBox;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Holy_Meatball extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Holy_Meatball();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        int time = 300;
        if (item.getItemId() == 85003) {
            time = 1800;
        }
        if (pc.hasSkillEffect(4025)) {
            pc.killSkillEffectTimer(4025);
        }
        pc.sendPackets(new S_SkillSound(pc.getId(), 7612));
        pc.sendPackets(new S_PacketBox(154, 20, time, true));
        pc.setSkillEffect(4025, time * 1000);
        pc.getInventory().removeItem(item, 1L);
        pc.sendPackets(new S_ServerMessage(3673));
    }
}
