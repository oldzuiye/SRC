package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import java.util.Random;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Dice extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Dice();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int itemId = item.getItemId();
        final Random _random = new Random();
        int gfxid = 0;
        switch (itemId) {
            case 40325: {
                if (pc.getInventory().checkItem(40318, 1L)) {
                    gfxid = 3237 + _random.nextInt(2);
                    break;
                }
                pc.sendPackets(new S_ServerMessage(79));
                break;
            }
            case 40326: {
                if (pc.getInventory().checkItem(40318, 1L)) {
                    gfxid = 3229 + _random.nextInt(3);
                    break;
                }
                pc.sendPackets(new S_ServerMessage(79));
                break;
            }
            case 40327: {
                if (pc.getInventory().checkItem(40318, 1L)) {
                    gfxid = 3241 + _random.nextInt(4);
                    break;
                }
                pc.sendPackets(new S_ServerMessage(79));
                break;
            }
            case 40328: {
                if (pc.getInventory().checkItem(40318, 1L)) {
                    gfxid = 3204 + _random.nextInt(6);
                    break;
                }
                pc.sendPackets(new S_ServerMessage(79));
                break;
            }
        }
        if (gfxid != 0) {
            pc.getInventory().consumeItem(40318, 1L);
            pc.sendPacketsAll(new S_SkillSound(pc.getId(), gfxid));
        }
    }
}
