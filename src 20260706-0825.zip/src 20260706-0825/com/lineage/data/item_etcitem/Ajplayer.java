package com.lineage.data.item_etcitem;

import com.lineage.server.model.L1Object;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1NpcInstance;
import com.lineage.server.model.Instance.L1MonsterInstance;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_NPCTalkReturn;
import com.lineage.server.world.World;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Ajplayer extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Ajplayer();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int spellsc_objid = data[0];
        this.sneakpeek(pc, spellsc_objid, item);
    }
    
    private void sneakpeek(final L1PcInstance pc, final int targetId, final L1ItemInstance item) {
        final L1Object target = World.get().findObject(targetId);
        if (target != null) {
            String msg0 = "";
            String msg2 = "";
            String msg3 = "";
            String msg4 = "";
            String msg5 = "";
            String msg6 = "";
            String msg7 = "";
            String msg8 = "";
            String msg9 = "";
            String msg10 = "";
            String msg11 = "";
            String msg12 = "";
            String msg13 = "";
            String msg14 = "";
            String msg15 = "";
            String msg16 = "";
            String msg17 = "";
            String msg18 = "";
            String msg19 = "";
            String msg20 = "";
            String msg21 = "";
            String msg22 = "";
            String msg23 = "";
            if (target instanceof L1PcInstance) {
                final L1PcInstance target_pc = (L1PcInstance)target;
                if (!target_pc.getInventory().checkItem(50104, 1L) || pc.isGm()) {
                    msg0 = target_pc.getName();
                    msg2 = new StringBuilder().append(target_pc.getLevel()).toString();
                    msg3 = target_pc.getCurrentHp() + " / " + target_pc.getMaxHp();
                    msg4 = target_pc.getCurrentMp() + " / " + target_pc.getMaxMp();
                    msg5 = new StringBuilder().append(target_pc.getAc()).toString();
                    msg6 = new StringBuilder().append(target_pc.getEr()).toString();
                    msg7 = target_pc.getMr() + " %";
                    msg8 = target_pc.getFire() + " %";
                    msg9 = target_pc.getWater() + " %";
                    msg10 = target_pc.getWind() + " %";
                    msg11 = target_pc.getEarth() + " %";
                    msg13 = new StringBuilder().append(target_pc.getStr()).toString();
                    msg14 = new StringBuilder().append(target_pc.getCon()).toString();
                    msg15 = new StringBuilder().append(target_pc.getDex()).toString();
                    msg16 = new StringBuilder().append(target_pc.getWis()).toString();
                    msg17 = new StringBuilder().append(target_pc.getInt()).toString();
                    msg18 = new StringBuilder().append(target_pc.getCha()).toString();
                    msg19 = "0";
                    msg20 = new StringBuilder().append(target_pc.getGfxId()).toString();
                    msg21 = new StringBuilder().append(target_pc.getExp()).toString();
                    msg22 = new StringBuilder().append(target_pc.getLawful()).toString();
                    msg23 = new StringBuilder().append(target_pc.getSp()).toString();
                    final L1ItemInstance weapon = target_pc.getWeapon();
                    if (weapon != null) {
                        msg12 = new StringBuilder().append(weapon.getLogName()).toString();
                    }
                    else {
                        msg12 = "無裝備武器";
                    }
                    final String[] msg24 = { msg0, msg2, msg3, msg4, msg5, msg6, msg7, msg8, msg9, msg10, msg11, msg12, msg13, msg14, msg15, msg16, msg17, msg18, msg19, msg20, msg21, msg22, msg23 };
                    pc.sendPackets(new S_NPCTalkReturn(pc.getId(), "ajplayer", msg24));
                    pc.getInventory().removeItem(item, 1L);
                }
                else {
                    final int deleitem = 50104;
                    target_pc.getInventory().consumeItem(deleitem, 1L);
                    target_pc.sendPackets(new S_SystemMessage(String.valueOf(pc.getName()) + "對你使用偷窺卡，但是沒有偷窺成功。"));
                    pc.getInventory().removeItem(item, 1L);
                }
            }
            else if (pc.isGm()) {
                L1NpcInstance target_npc = null;
                if (target instanceof L1MonsterInstance) {
                    target_npc = (L1MonsterInstance)target;
                }
                else if (target instanceof L1NpcInstance) {
                    target_npc = (L1NpcInstance)target;
                }
                msg0 = target_npc.getName();
                msg2 = new StringBuilder().append(target_npc.getLevel()).toString();
                msg3 = target_npc.getCurrentHp() + " / " + target_npc.getMaxHp();
                msg4 = target_npc.getCurrentMp() + " / " + target_npc.getMaxMp();
                msg5 = new StringBuilder().append(target_npc.getAc()).toString();
                msg6 = "0";
                msg7 = target_npc.getMr() + " %";
                msg8 = target_npc.getFire() + " %";
                msg9 = target_npc.getWater() + " %";
                msg10 = target_npc.getWind() + " %";
                msg11 = target_npc.getEarth() + " %";
                msg12 = "砂鍋大的拳頭";
                msg13 = new StringBuilder().append(target_npc.getStr()).toString();
                msg14 = new StringBuilder().append(target_npc.getCon()).toString();
                msg15 = new StringBuilder().append(target_npc.getDex()).toString();
                msg16 = new StringBuilder().append(target_npc.getWis()).toString();
                msg17 = new StringBuilder().append(target_npc.getInt()).toString();
                msg18 = new StringBuilder().append(target_npc.getCha()).toString();
                msg19 = new StringBuilder().append(target_npc.getNpcId()).toString();
                msg20 = new StringBuilder().append(target_npc.getGfxId()).toString();
                msg21 = new StringBuilder().append(target_npc.getExp()).toString();
                msg22 = new StringBuilder().append(target_npc.getLawful()).toString();
                msg23 = new StringBuilder().append(target_npc.getSp()).toString();
                final String[] msg25 = { msg0, msg2, msg3, msg4, msg5, msg6, msg7, msg8, msg9, msg10, msg11, msg12, msg13, msg14, msg15, msg16, msg17, msg18, msg19, msg20, msg21, msg22, msg23 };
                pc.sendPackets(new S_NPCTalkReturn(pc.getId(), "ajplayer", msg25));
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
    }
}
