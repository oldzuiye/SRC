package com.lineage.data.item_etcitem.power;

import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_OwnCharStatus2;
import com.lineage.config.ConfigAlt;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class PanaceaCha extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)PanaceaCha.class);
    }
    
    public static ItemExecutor get() {
        return new PanaceaCha();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (pc.getBaseCha() < ConfigAlt.POWERMEDICINE) {
            if (ConfigAlt.MEDICINE > 0) {
                if (pc.getElixirStats() < ConfigAlt.MEDICINE) {
                    pc.addBaseCha(1);
                    pc.setElixirStats(pc.getElixirStats() + 1);
                    pc.getInventory().removeItem(item, 1L);
                    pc.sendPackets(new S_OwnCharStatus2(pc));
                    try {
                        pc.save();
                    }
                    catch (Exception e) {
                        PanaceaCha._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
                    }
                }
                else {
                    pc.sendPackets(new S_ServerMessage(79));
                }
            }
            else if (pc.getLevel() >= 50) {
                final int medicine = (pc.getLevel() - 50) / 5 + 1;
                if (pc.getElixirStats() < medicine) {
                    pc.addBaseCha(1);
                    pc.setElixirStats(pc.getElixirStats() + 1);
                    pc.getInventory().removeItem(item, 1L);
                    pc.sendPackets(new S_OwnCharStatus2(pc));
                    try {
                        pc.save();
                    }
                    catch (Exception e2) {
                        PanaceaCha._log.error((Object)e2.getLocalizedMessage(), (Throwable)e2);
                    }
                }
                else {
                    pc.sendPackets(new S_ServerMessage(79));
                }
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
        else {
            pc.sendPackets(new S_ServerMessage("屬性最大值只能到" + ConfigAlt.POWER + "。 請重試一次。"));
        }
    }
}
