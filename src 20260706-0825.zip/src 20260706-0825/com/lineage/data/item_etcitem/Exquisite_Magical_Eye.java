package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.data.cmd.CreateNewItem;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Exquisite_Magical_Eye extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Exquisite_Magical_Eye();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int itemId = item.getItemId();
        final int itemobj = data[0];
        final L1ItemInstance tgitem = pc.getInventory().getItem(itemobj);
        if (tgitem == null) {
            return;
        }
        if (itemId == 42525) {
            final int tgitemId = tgitem.getItem().getItemId();
            if (tgitemId == 42526) {
                CreateNewItem.createNewItem(pc, 42522, 1L);
                pc.getInventory().removeItem(tgitem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
        if (itemId == 42526) {
            final int tgitemId = tgitem.getItem().getItemId();
            if (tgitemId == 42525) {
                CreateNewItem.createNewItem(pc, 42522, 1L);
                pc.getInventory().removeItem(tgitem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
        if (itemId == 42529) {
            final int tgitemId = tgitem.getItem().getItemId();
            if (tgitemId == 42527) {
                CreateNewItem.createNewItem(pc, 42523, 1L);
                pc.getInventory().removeItem(tgitem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
        if (itemId == 42527) {
            final int tgitemId = tgitem.getItem().getItemId();
            if (tgitemId == 42529) {
                CreateNewItem.createNewItem(pc, 42523, 1L);
                pc.getInventory().removeItem(tgitem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
        if (itemId == 42530) {
            final int tgitemId = tgitem.getItem().getItemId();
            if (tgitemId == 42528) {
                CreateNewItem.createNewItem(pc, 42524, 1L);
                pc.getInventory().removeItem(tgitem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
        if (itemId == 42528) {
            final int tgitemId = tgitem.getItem().getItemId();
            if (tgitemId == 42530) {
                CreateNewItem.createNewItem(pc, 42524, 1L);
                pc.getInventory().removeItem(tgitem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else {
                pc.sendPackets(new S_ServerMessage(79));
            }
        }
    }
}
