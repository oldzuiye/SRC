package com.lineage.data.item_etcitem.doll;

import java.util.Map;
import com.lineage.server.templates.L1Doll;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.templates.L1ItemPowerUpdate;
import com.lineage.server.datatables.DollPowerTable;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.datatables.ItemPowerUpdateTable;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import java.util.Random;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class DollSolution extends ItemExecutor
{
    private static final Log _log;
    private static final Random _random;
    
    static {
        _log = LogFactory.getLog((Class)DollSolution.class);
        _random = new Random();
    }
    
    public static ItemExecutor get() {
        return new DollSolution();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            final int targObjId = data[0];
            final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
            if (tgItem == null) {
                return;
            }
            final String key = String.valueOf(tgItem.getItemId()) + "/" + item.getItemId();
            final L1ItemPowerUpdate info = ItemPowerUpdateTable.get().gettemplate(key);
            if (info == null) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            final L1Doll doll = DollPowerTable.get().get_type(tgItem.getItemId());
            if (doll == null) {
                pc.sendPackets(new S_ServerMessage(2477));
                return;
            }
            if (pc.getDoll(tgItem.getId()) != null) {
                pc.sendPackets(new S_ServerMessage(1181));
                return;
            }
            if (info.get_mode() == 4) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            if (info.get_nedid() != item.getItemId()) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            final Map<Integer, L1ItemPowerUpdate> tmplist = ItemPowerUpdateTable.get().get_type_updatemap(key);
            if (tmplist.isEmpty()) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            final int order_id = info.get_order_id();
            final L1ItemPowerUpdate tginfo = tmplist.get(order_id + 1);
            if (tginfo == null) {
                pc.sendPackets(new S_ServerMessage(79));
                return;
            }
            final int remainingtime = tgItem.getRemainingTime();
            pc.getInventory().removeItem(item, 1L);
            if (DollSolution._random.nextInt(1000) < info.get_random()) {
                pc.getInventory().removeItem(tgItem, 1L);
                final L1ItemInstance tginfo_item = ItemTable.get().createItem(tginfo.get_itemid());
                if (tginfo_item != null) {
                    if (remainingtime > 0) {
                        tginfo_item.setRemainingTime(remainingtime);
                    }
                    tginfo_item.setIdentified(true);
                    tginfo_item.setCount(1L);
                    pc.getInventory().storeItem(tginfo_item);
                    pc.sendPackets(new S_ServerMessage("\\fT獲得嶄新的 " + tginfo_item.getName()));
                    return;
                }
                DollSolution._log.error((Object)("給予物件失敗 原因: 指定編號物品不存在(" + tginfo.get_itemid() + ")"));
            }
            else {
                switch (info.get_mode()) {
                    case 0: {
                        pc.sendPackets(new S_ServerMessage(160, tgItem.getLogName(), "$252", "$248"));
                        break;
                    }
                    case 1: {
                        final L1ItemPowerUpdate ole1 = tmplist.get(order_id - 1);
                        pc.sendPackets(new S_ServerMessage("\\fR" + tgItem.getName() + "升級失敗!"));
                        pc.getInventory().removeItem(tgItem, 1L);
                        final L1ItemInstance ole1item = ItemTable.get().createItem(ole1.get_itemid());
                        ole1item.setIdentified(true);
                        ole1item.setCount(1L);
                        pc.getInventory().storeItem(ole1item);
                        break;
                    }
                    case 2: {
                        pc.sendPackets(new S_ServerMessage(164, tgItem.getLogName(), "$252"));
                        pc.getInventory().removeItem(tgItem, 1L);
                        break;
                    }
                    case 3: {
                        if (DollSolution._random.nextBoolean()) {
                            final L1ItemPowerUpdate ole2 = tmplist.get(order_id - 1);
                            pc.sendPackets(new S_ServerMessage("\\fR" + tgItem.getName() + "升級失敗!"));
                            pc.getInventory().removeItem(tgItem, 1L);
                            final L1ItemInstance ole2item = ItemTable.get().createItem(ole2.get_itemid());
                            ole2item.setIdentified(true);
                            ole2item.setCount(1L);
                            pc.getInventory().storeItem(ole2item);
                            break;
                        }
                        pc.sendPackets(new S_ServerMessage(164, tgItem.getLogName(), "$252"));
                        pc.getInventory().removeItem(tgItem, 1L);
                        break;
                    }
                }
            }
        }
        catch (Exception e) {
            DollSolution._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
