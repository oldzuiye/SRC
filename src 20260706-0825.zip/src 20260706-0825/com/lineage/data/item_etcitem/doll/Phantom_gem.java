package com.lineage.data.item_etcitem.doll;

import com.lineage.server.templates.L1Doll;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.utils.Random;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.datatables.DollPowerTable;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Phantom_gem extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)Phantom_gem.class);
    }
    
    public static ItemExecutor get() {
        return new Phantom_gem();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            final int targObjId = data[0];
            final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
            if (tgItem == null) {
                return;
            }
            final L1Doll doll = DollPowerTable.get().get_type(tgItem.getItemId());
            if (doll == null) {
                pc.sendPackets(new S_ServerMessage(2477));
                return;
            }
            if (pc.getDoll(tgItem.getId()) != null) {
                pc.sendPackets(new S_ServerMessage(1181));
                return;
            }
            final int[] firegirls2 = { 80300, 80301, 80302, 80303, 80304 };
            final int givegirl2 = firegirls2[Random.getInt(firegirls2.length)];
            final int[] fireboys2 = { 80315, 80316, 80317, 80318, 80319 };
            final int giveboy2 = fireboys2[Random.getInt(fireboys2.length)];
            if (tgItem.getItemId() >= 80300 && tgItem.getItemId() <= 80304) {
                pc.getInventory().removeItem(item, 1L);
                pc.getInventory().removeItem(tgItem, 1L);
                final L1ItemInstance giveitem = ItemTable.get().createItem(givegirl2);
                giveitem.setRemainingTime(90000);
                giveitem.setIdentified(true);
                giveitem.setCount(1L);
                pc.getInventory().storeItem(giveitem);
                return;
            }
            if (tgItem.getItemId() >= 80315 && tgItem.getItemId() <= 80319) {
                pc.getInventory().removeItem(item, 1L);
                pc.getInventory().removeItem(tgItem, 1L);
                final L1ItemInstance giveitem = ItemTable.get().createItem(giveboy2);
                giveitem.setRemainingTime(90000);
                giveitem.setIdentified(true);
                giveitem.setCount(1L);
                pc.getInventory().storeItem(giveitem);
                return;
            }
            pc.sendPackets(new S_ServerMessage("魔幻的寶石只可使用於爆擊火焰衝擊系列"));
        }
        catch (Exception e) {
            Phantom_gem._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
