package com.lineage.data.item_etcitem.doll;

import com.lineage.server.templates.L1Doll;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.datatables.DollPowerTable;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class TimeRecharge extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)TimeRecharge.class);
    }
    
    public static ItemExecutor get() {
        return new TimeRecharge();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        try {
            final int targObjId = data[0];
            final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
            if (tgItem == null) {
                return;
            }
            final L1Doll doll = DollPowerTable.get().get_type(tgItem.getItemId());
            if (doll == null) {
                pc.sendPackets(new S_ServerMessage(2477));
                return;
            }
            if (tgItem.getRemainingTime() > 1800) {
                pc.sendPackets(new S_ServerMessage(3331));
                return;
            }
            if (tgItem.getItem().getMaxUseTime() <= 0) {
                pc.sendPackets(new S_ServerMessage(3329));
                return;
            }
            pc.getInventory().removeItem(item, 1L);
            int time = 0;
            switch (item.getItemId()) {
                case 44215: {
                    time = 18000;
                    break;
                }
                case 44216: {
                    time = 36000;
                    break;
                }
                case 44217: {
                    time = 86400;
                    break;
                }
                case 44218: {
                    time = 360000;
                    break;
                }
            }
            tgItem.setRemainingTime(time);
            pc.getInventory().updateItem(tgItem, 256);
        }
        catch (Exception e) {
            TimeRecharge._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
