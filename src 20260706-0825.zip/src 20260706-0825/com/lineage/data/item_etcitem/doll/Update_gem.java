package com.lineage.data.item_etcitem.doll;

import com.lineage.server.templates.L1Doll;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.utils.Random;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.datatables.DollPowerTable;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Update_gem extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)Update_gem.class);
    }
    
    public static ItemExecutor get() {
        return new Update_gem();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            final int targObjId = data[0];
            final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
            if (tgItem == null) {
                return;
            }
            final L1Doll doll = DollPowerTable.get().get_type(tgItem.getItemId());
            if (doll == null) {
                pc.sendPackets(new S_ServerMessage(2477));
                return;
            }
            if (pc.getDoll(tgItem.getId()) != null) {
                pc.sendPackets(new S_ServerMessage(1181));
                return;
            }
            final int[] firegirls = { 80290, 80291, 80292, 80293, 80294, 80295, 80296, 80297, 80298, 80299 };
            final int givegirl = firegirls[Random.getInt(firegirls.length)];
            final int[] firegirls2 = { 80300, 80301, 80302, 80303, 80304 };
            final int givegirl2 = firegirls2[Random.getInt(firegirls2.length)];
            final int[] fireboys = { 80305, 80306, 80307, 80308, 80309, 80310, 80311, 80312, 80313, 80314 };
            final int giveboy = fireboys[Random.getInt(fireboys.length)];
            final int[] fireboys2 = { 80315, 80316, 80317, 80318, 80319 };
            final int giveboy2 = fireboys2[Random.getInt(fireboys2.length)];
            if (tgItem.getItemId() == 80283 || (tgItem.getItemId() >= 80290 && tgItem.getItemId() <= 80299)) {
                pc.getInventory().removeItem(item, 1L);
                pc.getInventory().removeItem(tgItem, 1L);
                if (Random.nextInt(100) + 1 <= 95) {
                    final L1ItemInstance giveitem = ItemTable.get().createItem(givegirl);
                    giveitem.setRemainingTime(90000);
                    giveitem.setIdentified(true);
                    giveitem.setCount(1L);
                    pc.getInventory().storeItem(giveitem);
                    return;
                }
                final L1ItemInstance giveitem = ItemTable.get().createItem(givegirl2);
                giveitem.setRemainingTime(90000);
                giveitem.setIdentified(true);
                giveitem.setCount(1L);
                pc.getInventory().storeItem(giveitem);
            }
            else if (tgItem.getItemId() == 80288 || (tgItem.getItemId() >= 80305 && tgItem.getItemId() <= 80314)) {
                pc.getInventory().removeItem(item, 1L);
                pc.getInventory().removeItem(tgItem, 1L);
                if (Random.nextInt(100) + 1 <= 95) {
                    final L1ItemInstance giveitem = ItemTable.get().createItem(giveboy);
                    giveitem.setRemainingTime(90000);
                    giveitem.setIdentified(true);
                    giveitem.setCount(1L);
                    pc.getInventory().storeItem(giveitem);
                    return;
                }
                final L1ItemInstance giveitem = ItemTable.get().createItem(giveboy2);
                giveitem.setRemainingTime(90000);
                giveitem.setIdentified(true);
                giveitem.setCount(1L);
                pc.getInventory().storeItem(giveitem);
            }
            else {
                pc.sendPackets(new S_ServerMessage("精靈的寶石只可使用於火焰衝擊系列"));
            }
        }
        catch (Exception e) {
            Update_gem._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
