package com.lineage.data.item_etcitem.doll;

import com.lineage.server.templates.L1Npc;
import com.lineage.server.templates.L1Item;
import com.lineage.server.templates.L1Doll;
import java.util.List;
import java.util.Iterator;
import com.lineage.server.world.WorldItem;
import com.lineage.server.model.L1Character;
import com.lineage.server.datatables.NpcTable;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.datatables.DollPowerTable;
import com.lineage.server.model.L1War;
import com.lineage.server.world.WorldWar;
import com.lineage.server.timecontroller.server.ServerWarExecutor;
import com.lineage.config.ConfigOther;
import com.lineage.server.model.Instance.L1DollInstance;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.config.ConfigAlt;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Magic_Doll extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Magic_Doll();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int itemId = item.getItemId();
        final int itemobj = item.getId();
        this.useMagicDoll(pc, itemId, itemobj);
    }
    
    private void useMagicDoll(final L1PcInstance pc, final int itemId, final int itemObjectId) {
        if (pc.getDoll(itemObjectId) != null) {
            pc.getDoll(itemObjectId).deleteDoll();
            return;
        }
        if (pc.getDolls().size() >= ConfigAlt.MAX_DOLL_COUNT) {
            pc.sendPackets(new S_ServerMessage(319));
            return;
        }
        if (!pc.getDolls().isEmpty()) {
            for (final L1DollInstance doll : pc.getDolls().values()) {
                if (pc.getInventory().getItem(doll.getItemObjId()).getItemId() == itemId) {
                    pc.sendPackets(new S_ServerMessage("\\fY不能攜帶相同的娃娃"));
                    return;
                }
            }
        }
        if (!ConfigOther.WAR_DOLL && pc.getClan() != null) {
            boolean inWar = false;
            if (pc.getClan().getCastleId() != 0) {
                if (ServerWarExecutor.get().isNowWar(pc.getClan().getCastleId())) {
                    inWar = true;
                }
            }
            else {
                final List<L1War> warList = WorldWar.get().getWarList();
                for (final L1War war : warList) {
                    if (war.checkClanInWar(pc.getClan().getClanName())) {
                        inWar = true;
                        break;
                    }
                }
            }
            if (inWar) {
                pc.sendPackets(new S_ServerMessage(1531));
                return;
            }
        }
        boolean iserror = false;
        final L1Doll type = DollPowerTable.get().get_type(itemId);
        if (type != null) {
            if (type.get_need() != null) {
                final int[] itemids = type.get_need();
                final int[] counts = type.get_counts();
                for (int i = 0; i < itemids.length; ++i) {
                    if (!pc.getInventory().checkItem(itemids[i], counts[i])) {
                        final L1Item temp = ItemTable.get().getTemplate(itemids[i]);
                        pc.sendPackets(new S_ServerMessage(337, temp.getNameId()));
                        iserror = true;
                    }
                }
                if (!iserror) {
                    for (int i = 0; i < itemids.length; ++i) {
                        pc.getInventory().consumeItem(itemids[i], counts[i]);
                    }
                }
            }
            if (!iserror) {
                final L1Npc template = NpcTable.get().getTemplate(71082);
                final L1DollInstance doll2 = new L1DollInstance(template, pc, itemObjectId, type);
                final L1ItemInstance item = WorldItem.get().getItem(itemObjectId);
                item.startEquipmentTimer(pc);
            }
        }
    }
}
