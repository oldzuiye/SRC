package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.serverpackets.S_SPMR;
import com.lineage.server.serverpackets.S_MPUpdate;
import com.lineage.server.serverpackets.S_HPUpdate;
import com.lineage.server.serverpackets.S_OwnCharStatus;
import com.lineage.server.serverpackets.S_Liquor;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_PacketBoxThirdSpeed;
import com.lineage.server.model.skill.L1BuffUtil;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Ancient_Potion extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Ancient_Potion();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        L1BuffUtil.cancelAbsoluteBarrier(pc);
        if (pc.hasSkillEffect(8061)) {
            pc.removeSkillEffect(8061);
        }
        final int time = 600000;
        pc.setSkillEffect(8061, time);
        if (pc.hasSkillEffect(998)) {
            pc.killSkillEffectTimer(998);
            pc.sendPackets(new S_PacketBoxThirdSpeed(4));
        }
        pc.sendPacketsAll(new S_Liquor(pc.getId(), 8));
        pc.addMaxHp(100);
        pc.addMaxMp(100);
        pc.addHitup(10);
        pc.addDmgup(5);
        pc.addBowHitup(10);
        pc.addBowDmgup(5);
        pc.addSp(5);
        pc.addAc(-10);
        pc.addMr(10);
        pc.sendPackets(new S_OwnCharStatus(pc));
        pc.sendPackets(new S_HPUpdate(pc));
        if (pc.isInParty()) {
            pc.getParty().updateMiniHP(pc);
        }
        pc.sendPackets(new S_MPUpdate(pc));
        pc.sendPackets(new S_SPMR(pc));
        pc.sendPackets(new S_SkillSound(pc.getId(), 10386));
    }
}
