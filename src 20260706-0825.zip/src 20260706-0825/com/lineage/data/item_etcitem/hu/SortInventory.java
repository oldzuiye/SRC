package com.lineage.data.item_etcitem.hu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.server.model.L1PcInventory;
import com.lineage.server.serverpackets.S_AddItem;
import com.lineage.server.serverpackets.S_DeleteInventoryItem;
import com.lineage.server.serverpackets.S_PacketBox;
import com.lineage.server.templates.L1Item;
import com.lineage.data.executor.ItemExecutor;

/**
 * 【一鍵整理背包系統】
 * 功能：自動整理玩家背包中的未裝備物品
 * 排序規則：按優先級、強化等級、物品類型排列
 */
public class SortInventory extends ItemExecutor {

    private static SortInventory instance;

    /**
     * 【靜態初始化塊】
     * 在類加載時自動執行
     */
    static {
        SortInventoryConfig.loadConfig();
    }

    /**
     * 【取得單例】
     * @return SortInventory 單例實例
     */
    public static SortInventory get() {
        if (instance == null) {
            instance = new SortInventory();
        }
        return instance;
    }

    /**
     * 【執行方法】
     * 實現 ItemExecutor 介面
     */
    @Override
    public void execute(int[] params, L1PcInstance pc, L1ItemInstance item) {
        try {
            if (pc == null) {
                return;
            }
            sort(pc);
        } catch (Exception e) {
            // 錯誤靜默處理
        }
    }

    /**
     * 【核心排序方法】
     * 整理指定玩家的背包（未裝備物品）
     * 
     * 流程：
     * 1. 提取背包所有物品
     * 2. 過濾掉已裝備的物品
     * 3. 按自訂規則排序
     * 4. 發送客戶端更新通知
     * 
     * @param pc 目標玩家
     */
    public static void sort(L1PcInstance pc) {
        // 【檢查】玩家對象
        if (pc == null) {
            return;
        }

        // 【取得】背包
        L1PcInventory inventory = pc.getInventory();
        if (inventory == null) {
            return;
        }

        List<L1ItemInstance> items = new ArrayList<>(inventory.getItems());

        // 【過濾】未裝備物品
        List<L1ItemInstance> unequippedItems = new ArrayList<>();
        for (L1ItemInstance item : items) {
            if (item != null && !item.isEquipped()) {
                unequippedItems.add(item);
            }
        }

        // 【檢查】是否有未裝備物品
        if (unequippedItems.isEmpty()) {
            return;
        }

        // 【排序】使用自訂比較器
        Collections.sort(unequippedItems, new InventoryComparator());

        // 【刪除】舊位置
        for (L1ItemInstance item : unequippedItems) {
            pc.sendPackets(new S_DeleteInventoryItem(item));
        }

        // 【添加】新位置
        for (L1ItemInstance item : unequippedItems) {
            pc.sendPackets(new S_AddItem(item));
        }

        // 【更新】重量顯示
        pc.sendPackets(new S_PacketBox(S_PacketBox.WEIGHT, inventory.getWeight()));
    }

    /**
     * 【排序比較器】
     * 實現 Comparator 介面，定義物品排序規則
     * 
     * 排序優先級（從高到低）：
     * 1. 分類優先級（武器 > 防具 > 藥水 > 食物 > 材料 > 其他）
     * 2. 強化等級（高強化優先）
     * 3. 物品類型（高類型優先）
     * 4. 物品 ID（最終決斷）
     */
    private static class InventoryComparator implements Comparator<L1ItemInstance> {

        /**
         * 【比較方法】
         * 比較兩個物品的排序權重
         * 
         * @param item1 第一個物品
         * @param item2 第二個物品
         * @return 負數 = item1排前面，0 = 相同位置，正數 = item2排前面
         */
        @Override
        public int compare(L1ItemInstance item1, L1ItemInstance item2) {
            // 【檢查】物品有效性
            if (item1 == null || item2 == null) {
                return 0;
            }

            // 【提取】物品模板
            L1Item template1 = item1.getItem();
            L1Item template2 = item2.getItem();

            if (template1 == null || template2 == null) {
                return 0;
            }

            // 【取得】物品主類型
            int type2_1 = template1.getType2();
            int type2_2 = template2.getType2();

            // 【計算】排序值
            int sort1 = getSortOrder(type2_1, template1.getType(), item1.getEnchantLevel(), template1.getItemId());
            int sort2 = getSortOrder(type2_2, template2.getType(), item2.getEnchantLevel(), template2.getItemId());

            return sort1 - sort2;
        }

        /**
         * 【計算排序權重】
         * 公式：分類優先級 × 10,000,000 + 類型獎勵 + 強化獎勵 + 物品ID
         * 
         * @param type2 物品主類型（1=武器, 2=防具, 0=其他）
         * @param type 物品子類型（細分類）
         * @param enchantLevel 附魔強化等級
         * @param itemId 物品 ID
         * @return 排序權重值（越小越優先）
         */
        private int getSortOrder(int type2, int type, int enchantLevel, int itemId) {
            // ==================== 【第一層】分類優先級 ====================
            int categoryOrder;

            if (type2 == 1) {
                // 武器
                categoryOrder = SortInventoryConfig.SORT_PRIORITY_WEAPON;
            } else if (type2 == 2) {
                // 防具
                categoryOrder = SortInventoryConfig.SORT_PRIORITY_ARMOR;
            } else if (type2 == 0) {
                // 消耗品細分
                if (type == 6 || type == 18) {
                    // 藥水
                    categoryOrder = SortInventoryConfig.SORT_PRIORITY_POTION;
                } else if (type == 7) {
                    // 食物
                    categoryOrder = SortInventoryConfig.SORT_PRIORITY_FOOD;
                } else if (type == 13) {
                    // 材料
                    categoryOrder = SortInventoryConfig.SORT_PRIORITY_MATERIAL;
                } else if (type == 14) {
                    // 其他消耗品
                    categoryOrder = SortInventoryConfig.SORT_PRIORITY_POTION;
                } else {
                    // 雜項
                    categoryOrder = SortInventoryConfig.SORT_PRIORITY_OTHER;
                }
            } else {
                categoryOrder = SortInventoryConfig.SORT_PRIORITY_OTHER;
            }

            // ==================== 【第二層】強化等級獎勵 ====================
            int enchantBonus = 0;
            if ((type2 == 1 || type2 == 2) && SortInventoryConfig.SORT_BY_ENCHANT_DESC) {
                enchantBonus = -enchantLevel * 100000;
            }

            // ==================== 【第三層】子類型獎勵 ====================
            int typeBonus = 0;
            if (SortInventoryConfig.SORT_BY_TYPE) {
                typeBonus = -type * 10000;
            }

            // ==================== 【最終排序值】 ====================
            return categoryOrder * 10000000 + typeBonus + enchantBonus + itemId;
        }
    }
}