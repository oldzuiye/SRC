package com.lineage.data.item_etcitem.hu;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;

import com.lineage.server.model.L1Party;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.server.serverpackets.S_GreenMessage;
import com.lineage.server.serverpackets.S_Message_YN;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.world.World;
import com.lineage.server.model.L1CastleLocation;
import com.lineage.server.timecontroller.server.ServerWarExecutor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lineage.data.executor.ItemExecutor;

public class Party_Teleport extends ItemExecutor {

    private static final Log _log = LogFactory.getLog(Party_Teleport.class);
    private int _remove;
    private String m;

    public static ItemExecutor get() {
        return new Party_Teleport();
    }

    private Party_Teleport() {
        _remove = 0;
        m = null;
    }

    @Override
    public void execute(int[] data, L1PcInstance pc, L1ItemInstance item) {
        try {
            if (pc.getParty() == null) {
                pc.sendPackets(new S_ServerMessage("\\fY你目前沒有隊伍，無法使用此道具"));
                return;
            }
            
            if (!pc.getParty().isLeader(pc)) {
                pc.sendPackets(new S_ServerMessage("\\fY只有隊長才能使用隊伍穿雲箭"));
                return;
            }

            boolean error = false;
            if (this.m != null) {
                String[] mapid = this.m.split(",");
                for (String mid : mapid) {
                    if (pc.getMapId() == Integer.parseInt(mid.trim())) {
                        error = true;
                        break;
                    }
                }
            }
            if (error) {
                pc.sendPackets(new S_ServerMessage("你發出隊伍召喚，但你當前地圖無法被召喚"));
                return;
            }

            boolean isInWarArea = false;
            int castleId = L1CastleLocation.getCastleIdByArea(pc);
            if (castleId != 0) {
                isInWarArea = true;
                if (ServerWarExecutor.get().isNowWar(castleId)) {
                    isInWarArea = false;
                }
            }
            if (isInWarArea) {
                pc.sendPackets(new S_ServerMessage("你在城堡內無法發動隊伍召喚"));
                return;
            }

            // ✅ 發送召喚邀請給隊伍成員
            L1Party party = pc.getParty();
            for (L1PcInstance member : party.partyUsers().values()) {
                if (member != null && member.getId() != pc.getId()) {
                    member.setTempID(pc.getId());
                    member.setCallClan(true);
                    member.sendPackets(new S_Message_YN(729));
                    member.sendPackets(new S_ServerMessage(166, "隊長 " + pc.getName() + " 使用隊伍召喚，你要接受嗎？"));
                }
            }

            // ✅ 世界公告
            final String mapName = this.getMapLocationName(pc.getMapId());
            final String announceMsg = "【" + pc.getName() + " 的隊伍】在 " + mapName + " 使用了隊伍穿雲箭";
            for (final L1PcInstance player : World.get().getAllPlayers()) {
                if (player != null) {
                    player.sendPackets(new S_GreenMessage(announceMsg));
                }
            }

            pc.sendPackets(new S_ServerMessage("\\fY請注意，穿雲箭已經對所有在線玩家發出訊息"));

            if (this._remove == 1) {
                pc.getInventory().removeItem(item, 1L);
            }

        } catch (Exception e) {
            _log.error("隊伍召喚執行錯誤: " + e.getLocalizedMessage(), e);
        }
    }


    @Override
    public void set_set(String[] set) {
        try {
            _remove = Integer.parseInt(set[1]);
            m = set[2];
        } catch (Exception ex) {
            _log.error("設置錯誤：" + ex.getLocalizedMessage(), ex);
        }
    }

    private String getMapLocationName(final int mapId) {
        String locationName = "未知地圖";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("maps/maps.csv"), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (Integer.parseInt(parts[0].trim()) == mapId) {
                    locationName = parts[1].trim();
                    break;
                }
            }
        } catch (IOException e) {
            _log.error("讀取地圖名稱時發生錯誤: " + e.getLocalizedMessage(), e);
        }
        return locationName;
    }
}
