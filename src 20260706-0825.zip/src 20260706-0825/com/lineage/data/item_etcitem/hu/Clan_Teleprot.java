package com.lineage.data.item_etcitem.hu;

import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.Iterator;
import com.lineage.server.model.L1Clan;
import com.lineage.server.serverpackets.S_GreenMessage;
import com.lineage.server.serverpackets.S_Message_YN;
import com.lineage.server.world.World;
import com.lineage.server.world.WorldClan;
import com.lineage.server.timecontroller.server.ServerWarExecutor;
import com.lineage.server.model.L1Character;
import com.lineage.server.model.L1CastleLocation;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Clan_Teleprot extends ItemExecutor
{
    private static final Log _log;
    private int _remove;
    private String m;
    
    static {
        _log = LogFactory.getLog((Class)Clan_Teleprot.class);
    }
    
    private Clan_Teleprot() {
        this._remove = 0;
        this.m = null;
    }
    
    public static ItemExecutor get() {
        return new Clan_Teleprot();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            if (pc.getClanid() == 0) {
                pc.sendPackets(new S_ServerMessage("\\fY無血盟狀態無法使用"));
                return;
            }
            boolean error = false;
            if (this.m != null) {
                final String map = this.m.replaceAll("", "");
                final String[] mapid = map.split(",");
                for (int i = 0; i < mapid.length; ++i) {
                    final int m1 = Integer.parseInt(mapid[i]);
                    if (pc.getMapId() == m1) {
                        error = true;
                        break;
                    }
                }
            }
            if (error) {
                pc.sendPackets(new S_ServerMessage("你發出穿雲箭，但你的所在地圖無法受邀，無法被召喚"));
                return;
            }
            boolean isInWarArea = false;
            final int castleId = L1CastleLocation.getCastleIdByArea(pc);
            if (castleId != 0) {
                isInWarArea = true;
                if (ServerWarExecutor.get().isNowWar(castleId)) {
                    isInWarArea = false;
                }
            }
            if (isInWarArea) {
                pc.sendPackets(new S_ServerMessage("你發出穿雲箭，但你的所在城堡旗子內，無法被召喚"));
                return;
            }
            final L1Clan clan = WorldClan.get().getClan(pc.getClanname());
            if (clan != null) {
                String[] allMembers;
                for (int length = (allMembers = clan.getAllMembers()).length, j = 0; j < length; ++j) {
                    final String member = allMembers[j];
                    final L1PcInstance clan_pc = World.get().getPlayer(member);
                    if (clan_pc != null && pc.getId() != clan_pc.getId()) {
                        clan_pc.setTempID(pc.getId());
                        clan_pc.setCallClan(true);
                        final String msg = String.valueOf(pc.getName());
                        clan_pc.sendPackets(new S_Message_YN(729));
                        clan_pc.sendPackets(new S_ServerMessage(166, "血盟成員發出穿雲箭，你要接受他的支援嗎？"));
                    }
                }
            }
            final String mapName = this.getMapLocationName(pc.getMapId());
            final String announceMsg = "【" + pc.getClanname() + " 血盟的 " + pc.getName() + "】在 " + mapName + "，使用了血盟穿雲箭";
            for (final L1PcInstance member2 : World.get().getAllPlayers()) {
                if (member2 != null) {
                    member2.sendPackets(new S_GreenMessage(announceMsg));
                }
            }
            pc.sendPackets(new S_ServerMessage("\\fY請注意，穿雲箭已經對所有在線玩家發出訊息"));
            if (this._remove == 1) {
                pc.getInventory().removeItem(item, 1L);
            }
        }
        catch (Exception e) {
            Clan_Teleprot._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    @Override
    public void set_set(final String[] set) {
        try {
            this._remove = Integer.parseInt(set[1]);
            this.m = set[2];
        }
        catch (Exception ex) {
            Clan_Teleprot._log.error((Object)("設置錯誤：" + ex.getLocalizedMessage()));
        }
    }
    
    private String getMapLocationName(final int mapId) {
        String locationName = "未知地圖";
        try {
            final BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("maps/maps.csv"), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                final String[] parts = line.split(",");
                final int id = Integer.parseInt(parts[0].trim());
                if (id == mapId) {
                    locationName = parts[1].trim();
                    break;
                }
            }
            br.close();
        }
        catch (IOException e) {
            Clan_Teleprot._log.error((Object)("讀取地圖名稱時發生錯誤: " + e.getLocalizedMessage()), (Throwable)e);
        }
        return locationName;
    }
}
