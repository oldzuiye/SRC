package com.lineage.data.item_etcitem.hu;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lineage.server.clientpackets.C_MoveChar;
import com.lineage.server.model.L1Location;
import com.lineage.server.model.L1Object;
import com.lineage.server.model.L1Teleport;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.thread.GeneralThreadPool;
import com.lineage.server.world.World;

public class AutoFollowController {

    private static final Log _log = LogFactory.getLog(AutoFollowController.class);
    private static final Map<Integer, FollowTask> TASKS = new ConcurrentHashMap<Integer, FollowTask>();

    private static final int TICK_MS = 400;
    private static final int STOP_DISTANCE = 1;
    private static final int MAX_DISTANCE = 20;
    private static final int STUCK_LIMIT = 4;
    private static final int TELEPORT_EVERY_TICK = 6; // 500ms * 6 = 3秒

    public static boolean isFollowing(final L1PcInstance pc) {
        return pc != null && TASKS.containsKey(pc.getId());
    }

    public static void stopFollow(final L1PcInstance pc, final String msg) {
        if (pc == null) return;
        final FollowTask task = TASKS.remove(pc.getId());
        if (task != null) task.cancel();
        pc.setFollowTargetId(0);
        if (msg != null && msg.length() > 0) {
            pc.sendPackets(new S_SystemMessage(msg));
        }
    }

    public static void startFollow(final L1PcInstance follower, final int targetObjId) {
        if (follower == null) return;

        stopFollow(follower, null);

        final L1Object obj = World.get().findObject(targetObjId);

        if (!(obj instanceof L1PcInstance)) {
            follower.sendPackets(new S_SystemMessage("只能跟隨玩家，不能跟隨 NPC 或怪物。"));
            return;
        }

        final L1PcInstance target = (L1PcInstance) obj;

        if (target.getId() == follower.getId()) {
            follower.sendPackets(new S_SystemMessage("不能跟隨自己。"));
            return;
        }
        if (target.getNetConnection() == null || target.getOnlineStatus() != 1) {
            follower.sendPackets(new S_SystemMessage("目標不是在線玩家。"));
            return;
        }
        if (target.isGhost() || target.isGmInvis()) {
            follower.sendPackets(new S_SystemMessage("目標目前無法被跟隨。"));
            return;
        }
        if (!follower.isInParty() || !target.isInParty() || follower.getParty() != target.getParty()) {
            follower.sendPackets(new S_SystemMessage("只能跟隨同隊伍玩家。"));
            return;
        }

        follower.setFollowTargetId(target.getId());

        final FollowTask task = new FollowTask(follower.getId(), target.getId());
        final ScheduledFuture<?> future = GeneralThreadPool.get().scheduleAtFixedRate(task, 0L, TICK_MS);
        task.setFuture(future);
        TASKS.put(follower.getId(), task);

        follower.sendPackets(new S_SystemMessage("已開始跟隨：" + target.getName()));
    }

    private static class FollowTask implements Runnable {
        private final int followerId;
        private final int targetId;
        private ScheduledFuture<?> future;
        private int stuckCount = 0;
        private int tickCount = 0;

        private FollowTask(final int followerId, final int targetId) {
            this.followerId = followerId;
            this.targetId = targetId;
        }

        private void setFuture(final ScheduledFuture<?> future) {
            this.future = future;
        }

        private void cancel() {
            try {
                if (future != null) future.cancel(false);
            } catch (Exception e) {
                _log.error(e.getLocalizedMessage(), e);
            }
        }

        @Override
        public void run() {
            try {
                tickCount++;

                final L1Object fo = World.get().findObject(followerId);
                final L1Object to = World.get().findObject(targetId);

                if (!(fo instanceof L1PcInstance) || !(to instanceof L1PcInstance)) {
                    safeStop("跟隨已取消（目標不存在）。");
                    return;
                }

                final L1PcInstance follower = (L1PcInstance) fo;
                final L1PcInstance target = (L1PcInstance) to;

                if (follower.isDead() || follower.isGhost() || follower.getNetConnection() == null) {
                    safeStop(null);
                    return;
                }
                if (target.isDead() || target.isGhost() || target.getNetConnection() == null) {
                    safeStop("跟隨已取消（目標離線或死亡）。");
                    return;
                }

                if (!follower.isInParty() || !target.isInParty() || follower.getParty() != target.getParty()) {
                    safeStop("跟隨已取消（不在同隊伍）。");
                    return;
                }

                if (follower.getMapId() != target.getMapId()) {
                    safeStop("跟隨已取消（不同地圖）。");
                    return;
                }

                final int dist = follower.getLocation().getTileLineDistance(target.getLocation());

                if (dist > MAX_DISTANCE) {
                    safeStop("跟隨已取消（距離過遠）。");
                    return;
                }

                if (dist <= STOP_DISTANCE) {
                    stuckCount = 0;
                    tickCount = 0;
                    return;
                }

                // 每 3 秒強制短傳置中
                if (tickCount >= TELEPORT_EVERY_TICK) {
                    doTeleport(follower, target);
                    tickCount = 0;
                    return;
                }

                // 距離拉太開直接短傳
                if (dist >= 5) {
                    doTeleport(follower, target);
                    tickCount = 0;
                    return;
                }

                final int heading = follower.targetDirection(target.getX(), target.getY());
                if (heading < 0 || heading > 7) {
                    return;
                }

                final int oldX = follower.getX();
                final int oldY = follower.getY();

                C_MoveChar.moveByHeading(follower, heading);

                if (follower.getX() == oldX && follower.getY() == oldY) {
                    stuckCount++;
                } else {
                    stuckCount = 0;
                }

                if (stuckCount >= STUCK_LIMIT) {
                    doTeleport(follower, target);
                    stuckCount = 0;
                    tickCount = 0;
                }

            } catch (Exception e) {
                _log.error(e.getLocalizedMessage(), e);
            }
        }

        private void doTeleport(final L1PcInstance follower, final L1PcInstance target) {
            try {
                final int heading = target.getHeading();
                final int tx = target.getX() - C_MoveChar.HEADING_TABLE_X[heading];
                final int ty = target.getY() - C_MoveChar.HEADING_TABLE_Y[heading];

                if (follower.getMap().isPassable(tx, ty, follower)) {
                    L1Teleport.teleport(follower, tx, ty, (short) target.getMapId(), follower.getHeading(), false);
                    return;
                }

                final L1Location loc = target.getLocation().randomLocation(1, 1, false);
                if (loc != null && loc.getMap() != null && loc.getMap().isPassable(loc.getX(), loc.getY(), follower)) {
                    L1Teleport.teleport(follower, loc.getX(), loc.getY(), (short) loc.getMapId(), follower.getHeading(), false);
                }
            } catch (Exception e) {
                _log.error(e.getLocalizedMessage(), e);
            }
        }

        private void safeStop(final String msg) {
            final L1Object fo = World.get().findObject(followerId);
            if (fo instanceof L1PcInstance) {
                AutoFollowController.stopFollow((L1PcInstance) fo, msg);
            } else {
                cancel();
            }
        }
    }
}