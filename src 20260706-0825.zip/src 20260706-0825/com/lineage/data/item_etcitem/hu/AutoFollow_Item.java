package com.lineage.data.item_etcitem.hu;

import com.lineage.data.executor.ItemExecutor;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.S_SystemMessage;

public class AutoFollow_Item extends ItemExecutor {

    public static ItemExecutor get() {
        return new AutoFollow_Item();
    }

    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            if (pc == null || item == null) {
                return;
            }

            if (AutoFollowController.isFollowing(pc)) {
                AutoFollowController.stopFollow(pc, "自動跟隨已關閉。");
                return;
            }

            if (data == null || data.length < 1) {
                pc.sendPackets(new S_SystemMessage("請先用滑鼠點選要跟隨的玩家。"));
                return;
            }

            final int targetObjId = data[0];
            if (targetObjId <= 0) {
                pc.sendPackets(new S_SystemMessage("目標無效。"));
                return;
            }

            AutoFollowController.startFollow(pc, targetObjId);

        } catch (Exception e) {
            pc.sendPackets(new S_ServerMessage("\\fR自動跟隨啟動失敗。"));
        }
    }
}