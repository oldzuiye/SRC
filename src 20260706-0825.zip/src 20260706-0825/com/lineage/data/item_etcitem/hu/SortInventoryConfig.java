package com.lineage.data.item_etcitem.hu;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 【背包整理配置系統】
 * 功能：讀取並管理背包整理的所有配置參數
 * 配置文件：config/sortinventory.properties
 */
public class SortInventoryConfig {

    private static final Log _log = LogFactory.getLog(SortInventoryConfig.class);

    // ==================== 【分類優先級】 ====================
    // 數字越小優先級越高，排序越靠前

    /** 武器優先級（預設 = 0，最高優先） */
    public static int SORT_PRIORITY_WEAPON = 0;

    /** 防具優先級（預設 = 1） */
    public static int SORT_PRIORITY_ARMOR = 1;

    /** 藥水優先級（預設 = 2） */
    public static int SORT_PRIORITY_POTION = 2;

    /** 食物優先級（預設 = 3） */
    public static int SORT_PRIORITY_FOOD = 3;

    /** 材料優先級（預設 = 4） */
    public static int SORT_PRIORITY_MATERIAL = 4;

    /** 其他優先級（預設 = 5，最低優先） */
    public static int SORT_PRIORITY_OTHER = 5;

    // ==================== 【功能開關】 ====================

    /** 是否按強化等級排序（高強化靠前） */
    public static boolean SORT_BY_ENCHANT_DESC = true;

    /** 是否按物品子類型排序 */
    public static boolean SORT_BY_TYPE = true;

    // ==================== 【默認值常量】 ====================
    private static final int DEFAULT_PRIORITY_WEAPON = 0;
    private static final int DEFAULT_PRIORITY_ARMOR = 1;
    private static final int DEFAULT_PRIORITY_POTION = 2;
    private static final int DEFAULT_PRIORITY_FOOD = 3;
    private static final int DEFAULT_PRIORITY_MATERIAL = 4;
    private static final int DEFAULT_PRIORITY_OTHER = 5;

    private static final boolean DEFAULT_SORT_BY_ENCHANT_DESC = true;
    private static final boolean DEFAULT_SORT_BY_TYPE = true;

    /**
     * 【加載配置】
     * 在啟動時調用，讀取 config/sortinventory.properties
     * 如果文件不存在或讀取失敗，使用默認配置
     */
    public static void loadConfig() {
        Properties props = new Properties();
        try {
            // 【嘗試】讀取配置文件
            props.load(new FileInputStream("config/sortinventory.properties"));
            loadConfig(props);
            _log.info("載入一鍵整理背包配置文件加載成功");
        } catch (IOException e) {
            // 【回退】文件不存在
            _log.info("一鍵整理背包配置文件未找到，使用默認配置");
            loadDefaultConfig();
        } catch (Exception e) {
            // 【回退】其他異常
            _log.error("一鍵整理背包配置加載失敗: " + e.getMessage(), e);
            loadDefaultConfig();
        }
    }

    /**
     * 【從屬性對象加載配置】
     * 
     * @param props Properties 對象
     */
    private static void loadConfig(Properties props) {
        try {
            // 【讀取】分類優先級
            SORT_PRIORITY_WEAPON = Integer.parseInt(
                parseValue(props, "Priority_Weapon", String.valueOf(DEFAULT_PRIORITY_WEAPON))
            );
            SORT_PRIORITY_ARMOR = Integer.parseInt(
                parseValue(props, "Priority_Armor", String.valueOf(DEFAULT_PRIORITY_ARMOR))
            );
            SORT_PRIORITY_POTION = Integer.parseInt(
                parseValue(props, "Priority_Potion", String.valueOf(DEFAULT_PRIORITY_POTION))
            );
            SORT_PRIORITY_FOOD = Integer.parseInt(
                parseValue(props, "Priority_Food", String.valueOf(DEFAULT_PRIORITY_FOOD))
            );
            SORT_PRIORITY_MATERIAL = Integer.parseInt(
                parseValue(props, "Priority_Material", String.valueOf(DEFAULT_PRIORITY_MATERIAL))
            );
            SORT_PRIORITY_OTHER = Integer.parseInt(
                parseValue(props, "Priority_Other", String.valueOf(DEFAULT_PRIORITY_OTHER))
            );

            // 【讀取】功能開關
            SORT_BY_ENCHANT_DESC = Boolean.parseBoolean(
                parseValue(props, "Sort_By_Enchant_Desc", String.valueOf(DEFAULT_SORT_BY_ENCHANT_DESC))
            );
            SORT_BY_TYPE = Boolean.parseBoolean(
                parseValue(props, "Sort_By_Type", String.valueOf(DEFAULT_SORT_BY_TYPE))
            );

            _log.info("載入一鍵整理背包配置加載完成: " +
                "武器=" + SORT_PRIORITY_WEAPON +
                ", 防具=" + SORT_PRIORITY_ARMOR +
                ", 藥水=" + SORT_PRIORITY_POTION +
                ", 食物=" + SORT_PRIORITY_FOOD +
                ", 材料=" + SORT_PRIORITY_MATERIAL +
                ", 其他=" + SORT_PRIORITY_OTHER
            );
        } catch (NumberFormatException e) {
            _log.error("一鍵整理背包配置參數格式錯誤: " + e.getMessage(), e);
            loadDefaultConfig();
        }
    }

    /**
     * 【加載默認配置】
     * 當文件不存在或解析失敗時使用
     */
    private static void loadDefaultConfig() {
        SORT_PRIORITY_WEAPON = DEFAULT_PRIORITY_WEAPON;
        SORT_PRIORITY_ARMOR = DEFAULT_PRIORITY_ARMOR;
        SORT_PRIORITY_POTION = DEFAULT_PRIORITY_POTION;
        SORT_PRIORITY_FOOD = DEFAULT_PRIORITY_FOOD;
        SORT_PRIORITY_MATERIAL = DEFAULT_PRIORITY_MATERIAL;
        SORT_PRIORITY_OTHER = DEFAULT_PRIORITY_OTHER;

        SORT_BY_ENCHANT_DESC = DEFAULT_SORT_BY_ENCHANT_DESC;
        SORT_BY_TYPE = DEFAULT_SORT_BY_TYPE;

        _log.info("一鍵整理背包已加載默認配置");
    }

    /**
     * 【安全讀取屬性】
     * 如果屬性不存在，返回默認值
     * 
     * @param props Properties 對象
     * @param key 屬性鍵
     * @param defaultValue 默認值
     * @return 屬性值或默認值
     */
    private static String parseValue(Properties props, String key, String defaultValue) {
        return props.getProperty(key, defaultValue);
    }
}