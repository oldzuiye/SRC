package com.lineage.data.item_etcitem.card;

import com.lineage.server.templates.L1ItemPower_name;
import com.lineage.server.datatables.lock.CharItemPowerReading;
import com.lineage.server.serverpackets.S_ItemName;
import com.lineage.server.serverpackets.S_ItemStatus;
import com.lineage.server.utils.Random;
import com.lineage.server.templates.L1ItemPower_text;
import com.lineage.server.datatables.ItemPowerTable;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class C3_Card_01 extends ItemExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)C3_Card_01.class);
    }
    
    public static ItemExecutor get() {
        return new C3_Card_01();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            final int targObjId = data[0];
            final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
            if (tgItem == null) {
                return;
            }
            if (tgItem.isEquipped()) {
                pc.sendPackets(new S_ServerMessage("\\fR你必須先解除物品裝備!"));
                return;
            }
            switch (tgItem.getItem().getUseType()) {
                case 1:
                case 2:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 25:
                case 43:
                case 44:
                case 45:
                case 47:
                case 48:
                case 49:
                case 51:
                case 72: {
                    final L1ItemPower_name powerdata = tgItem.get_powerdata();
                    if (powerdata != null) {
                        Object[] powers;
                        L1ItemPower_text power;
                        for (powers = ItemPowerTable.POWER_TEXT.values().toArray(), power = (L1ItemPower_text)powers[Random.getInt(powers.length)]; power.get_id() == powerdata.get_power_id1() || power.get_id() == powerdata.get_power_id2() || power.get_id() == powerdata.get_power_id3() || power.get_id() == powerdata.get_power_id4() || power.get_id() == 6612; power = (L1ItemPower_text)powers[Random.getInt(powers.length)]) {}
                        powerdata.set_power_id1(power.get_id());
                        pc.sendPackets(new S_ItemStatus(tgItem));
                        pc.sendPackets(new S_ItemName(tgItem));
                        CharItemPowerReading.get().updateItem(tgItem.getId(), tgItem.get_powerdata());
                        pc.getInventory().removeItem(item, 1L);
                        break;
                    }
                    pc.sendPackets(new S_ServerMessage("此物品沒有附魔欄位。"));
                    break;
                }
                default: {
                    pc.sendPackets(new S_ServerMessage(79));
                    break;
                }
            }
        }
        catch (Exception e) {
            C3_Card_01._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
