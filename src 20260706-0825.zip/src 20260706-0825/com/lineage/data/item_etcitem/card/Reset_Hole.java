package com.lineage.data.item_etcitem.card;

import com.lineage.server.templates.L1ItemPower_name;
import com.lineage.server.serverpackets.S_ItemName;
import com.lineage.server.serverpackets.S_ItemStatus;
import com.lineage.server.datatables.lock.CharItemPowerReading;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Reset_Hole extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Reset_Hole();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int targObjId = data[0];
        final L1ItemInstance tgItem = pc.getInventory().getItem(targObjId);
        if (tgItem == null) {
            return;
        }
        if (tgItem.isEquipped()) {
            pc.sendPackets(new S_ServerMessage("\\fR你必須先解除物品裝備!"));
            return;
        }
        L1ItemPower_name power = null;
        boolean update = false;
        switch (tgItem.getItem().getUseType()) {
            case 1:
            case 2:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 25:
            case 43:
            case 44:
            case 45:
            case 47:
            case 48:
            case 49:
            case 51:
            case 72: {
                if (tgItem.get_powerdata() != null) {
                    power = tgItem.get_powerdata();
                    update = true;
                    break;
                }
                pc.sendPackets(new S_ServerMessage("此物品沒有附魔欄位。"));
                break;
            }
        }
        if (power != null) {
            power.set_item_obj_id(tgItem.getId());
            power.set_power_id1(0);
            power.set_power_id2(0);
            power.set_power_id3(0);
            power.set_power_id4(0);
            tgItem.set_powerdata(power);
            if (update) {
                CharItemPowerReading.get().updateItem(tgItem.getId(), tgItem.get_powerdata());
                pc.getInventory().removeItem(item, 1L);
            }
            pc.sendPackets(new S_ItemStatus(tgItem));
            pc.sendPackets(new S_ItemName(tgItem));
        }
    }
}
