package com.lineage.data.item_etcitem;

import com.lineage.data.cmd.CreateNewItem;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class BloodyOrder extends ItemExecutor
{
    public static ItemExecutor get() {
        return new BloodyOrder();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        final int itemobj = data[0];
        final int itemId = item.getItemId();
        final L1ItemInstance tgItem = pc.getInventory().getItem(itemobj);
        if (tgItem == null) {
            return;
        }
        if (tgItem.isEquipped()) {
            pc.sendPackets(new S_ServerMessage("\\fR你必須先解除物品裝備!"));
            return;
        }
        final int tgItemId = tgItem.getItem().getItemId();
        if ((tgItemId >= 404100 && tgItemId <= 404109) || (tgItemId >= 404111 && tgItemId <= 404120) || (tgItemId >= 404122 && tgItemId <= 404131)) {
            if (itemId == 86201) {
                CreateNewItem.createNewItem(pc, 86203, 1L);
                pc.getInventory().removeItem(tgItem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
            else if (itemId == 86202) {
                CreateNewItem.createNewItem(pc, 86204, 1L);
                pc.getInventory().removeItem(tgItem, 1L);
                pc.getInventory().removeItem(item, 1L);
            }
        }
        else {
            pc.sendPackets(new S_ServerMessage(79));
        }
    }
}
