package com.lineage.data.item_etcitem;

import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.data.executor.ItemExecutor;

public class Experimental_Solvent extends ItemExecutor
{
    public static ItemExecutor get() {
        return new Experimental_Solvent();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (item == null) {
            return;
        }
        if (pc == null) {
            return;
        }
        final int time = 300;
        int skillId = 0;
        String stage = null;
        int gfxid = 0;
        switch (item.getItemId()) {
            case 300304: {
                skillId = 4026;
                stage = "紅光";
                gfxid = 189;
                break;
            }
            case 300305: {
                skillId = 4027;
                stage = "綠光";
                gfxid = 191;
                break;
            }
            case 300306: {
                skillId = 4028;
                stage = "藍光";
                gfxid = 190;
                break;
            }
        }
        if (pc.hasSkillEffect(skillId)) {
            pc.killSkillEffectTimer(skillId);
        }
        pc.sendPackets(new S_SkillSound(pc.getId(), gfxid));
        pc.setSkillEffect(skillId, time * 1000);
        pc.getInventory().removeItem(item, 1L);
        pc.sendPackets(new S_ServerMessage("5分鐘內可以攻擊  " + stage + "變異實驗體。"));
    }
}
