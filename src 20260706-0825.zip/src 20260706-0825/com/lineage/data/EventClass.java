package com.lineage.data;

import com.lineage.server.templates.L1Event;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import com.lineage.data.executor.EventExecutor;
import java.util.Map;
import org.apache.commons.logging.Log;

public class EventClass
{
    private static final Log _log;
    private static final Map<Integer, EventExecutor> _classList;
    private static EventClass _instance;
    
    static {
        _log = LogFactory.getLog((Class)EventClass.class);
        _classList = new HashMap<Integer, EventExecutor>();
    }
    
    public static EventClass get() {
        if (EventClass._instance == null) {
            EventClass._instance = new EventClass();
        }
        return EventClass._instance;
    }
    
    public void addList(final int eventid, final String className) {
        if (className.equals("0")) {
            return;
        }
        try {
            final StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("com.lineage.data.event.");
            stringBuilder.append(className);
            final Class<?> cls = Class.forName(stringBuilder.toString());
            final EventExecutor exe = (EventExecutor)cls.getMethod("get", (Class<?>[])new Class[0]).invoke(null, new Object[0]);
            EventClass._classList.put(new Integer(eventid), exe);
        }
        catch (ClassNotFoundException e) {
            final String error = "發生[Event(活動設置)檔案]錯誤, 檢查檔案是否存在:" + className + " EventId:" + eventid;
            EventClass._log.error((Object)error);
            DataError.isError(EventClass._log, error, e);
        }
        catch (IllegalArgumentException e2) {
            EventClass._log.error((Object)e2.getLocalizedMessage(), (Throwable)e2);
        }
        catch (IllegalAccessException e3) {
            EventClass._log.error((Object)e3.getLocalizedMessage(), (Throwable)e3);
        }
        catch (InvocationTargetException e4) {
            EventClass._log.error((Object)e4.getLocalizedMessage(), (Throwable)e4);
        }
        catch (SecurityException e5) {
            EventClass._log.error((Object)e5.getLocalizedMessage(), (Throwable)e5);
        }
        catch (NoSuchMethodException e6) {
            EventClass._log.error((Object)e6.getLocalizedMessage(), (Throwable)e6);
        }
    }
    
    public void startEvent(final L1Event event) {
        try {
            final EventExecutor exe = EventClass._classList.get(new Integer(event.get_eventid()));
            if (exe != null) {
                exe.execute(event);
            }
        }
        catch (Exception e) {
            EventClass._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
