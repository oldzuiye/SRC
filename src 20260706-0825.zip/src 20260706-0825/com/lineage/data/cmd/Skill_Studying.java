package com.lineage.data.cmd;

import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.templates.L1Skills;
import com.lineage.server.datatables.lock.CharSkillReading;
import com.lineage.server.datatables.SkillsTable;
import com.lineage.server.serverpackets.S_AddSkill;
import com.lineage.server.serverpackets.S_HPUpdate;
import com.lineage.server.serverpackets.S_DoActionGFX;
import com.lineage.server.serverpackets.S_SkillSound;
import com.lineage.server.model.L1Character;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1PcInstance;

public class Skill_Studying implements Skill_StudyingExecutor
{
    @Override
    public void magic(final L1PcInstance pc, final int skillId, final int magicLv, final int attribute, final int itemObj) {
        final int pclvl = pc.getLevel();
        boolean isUse = true;
        if (pc.isCrown()) {
            switch (magicLv) {
                case 1: {
                    if (pclvl >= 10) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 2: {
                    if (pclvl >= 20) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 21: {
                    if (pclvl >= 15) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 22: {
                    if (pclvl >= 30) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 23: {
                    if (pclvl >= 40) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 24: {
                    if (pclvl >= 45) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 25: {
                    if (pclvl >= 50) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 26: {
                    if (pclvl >= 55) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 27: {
                    if (pclvl >= 60) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isKnight()) {
            switch (magicLv) {
                case 1: {
                    if (pclvl >= 50) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 31: {
                    if (pclvl >= 50) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 32: {
                    if (pclvl >= 60) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isWizard()) {
            switch (magicLv) {
                case 1: {
                    if (pclvl >= 4) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 2: {
                    if (pclvl >= 8) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 3: {
                    if (pclvl >= 12) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 4: {
                    if (pclvl >= 16) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 5: {
                    if (pclvl >= 20) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 6: {
                    if (pclvl >= 24) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 7: {
                    if (pclvl >= 28) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 8: {
                    if (pclvl >= 32) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 9: {
                    if (pclvl >= 36) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 10: {
                    if (pclvl >= 40) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isElf()) {
            switch (magicLv) {
                case 1: {
                    if (pclvl >= 8) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 2: {
                    if (pclvl >= 16) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 3: {
                    if (pclvl >= 24) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 4: {
                    if (pclvl >= 32) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 5: {
                    if (pclvl >= 40) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 6: {
                    if (pclvl >= 48) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 11: {
                    if (pclvl >= 10) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 12: {
                    if (pclvl >= 20) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 13: {
                    if (pclvl >= 30) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 14: {
                    if (pclvl >= 40) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 15: {
                    if (pclvl >= 50) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isDarkelf()) {
            switch (magicLv) {
                case 1: {
                    if (pclvl >= 12) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 2: {
                    if (pclvl >= 24) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 41: {
                    if (pclvl >= 15) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 42: {
                    if (pclvl >= 30) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 43: {
                    if (pclvl >= 45) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 44: {
                    if (pclvl >= 60) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isDragonKnight()) {
            switch (magicLv) {
                case 51: {
                    if (pclvl >= 15) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 52: {
                    if (pclvl >= 30) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 53: {
                    if (pclvl >= 45) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isIllusionist()) {
            switch (magicLv) {
                case 61: {
                    if (pclvl >= 10) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 62: {
                    if (pclvl >= 20) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 63: {
                    if (pclvl >= 30) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 64: {
                    if (pclvl >= 40) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        else if (pc.isWarrior()) {
            switch (magicLv) {
                case 1: {
                    if (pclvl >= 50) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 71: {
                    if (pclvl >= 15) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 72: {
                    if (pclvl >= 30) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 73: {
                    if (pclvl >= 45) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 74: {
                    if (pclvl >= 50) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 75: {
                    if (pclvl >= 55) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 76: {
                    if (pclvl >= 60) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 77: {
                    if (pclvl >= 70) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 78: {
                    if (pclvl >= 75) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                case 79: {
                    if (pclvl >= 82) {
                        this.mapPosition(pc, skillId, attribute, itemObj);
                        break;
                    }
                    isUse = false;
                    break;
                }
                default: {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
            }
        }
        if (!isUse) {
            final S_ServerMessage msg = new S_ServerMessage(312);
            pc.sendPackets(msg);
        }
    }
    
    private void mapPosition(final L1PcInstance pc, final int skillId, final int attribute, final int itemObj) {
        final int x = pc.getX();
        final int y = pc.getY();
        final int m = pc.getMapId();
        switch (attribute) {
            case 0: {
                if ((x > 32880 && x < 32892 && y > 32646 && y < 32658 && m == 4) || (x > 32662 && x < 32674 && y > 32297 && y < 32309 && m == 4) || (x > 33135 && x < 33146 && y > 32232 && y < 32249 && m == 4) || (x > 33116 && x < 33128 && y > 32930 && y < 32942 && m == 4) || (x > 32791 && x < 32796 && y > 32842 && y < 32848 && m == 76)) {
                    this.spellBook(pc, skillId, itemObj);
                    break;
                }
                final S_ServerMessage msg = new S_ServerMessage(79);
                pc.sendPackets(msg);
                break;
            }
            case 1: {
                if ((x > 33116 && x < 33128 && y > 32930 && y < 32942 && m == 4) || (x > 33135 && x < 33146 && y > 32232 && y < 32249 && m == 4) || (x > 32791 && x < 32796 && y > 32842 && y < 32848 && m == 76)) {
                    this.spellBook(pc, skillId, itemObj);
                    break;
                }
                if ((x <= 32880 || x >= 32892 || y <= 32646 || y >= 32658 || m != 4) && (x <= 32662 || x >= 32674 || y <= 32297 || y >= 32309 || m != 4)) {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
                pc.getInventory().removeItem(pc.getInventory().getItem(itemObj), 1L);
                final short dmg = (short)(Math.random() * 50.0 + 30.0);
                pc.receiveDamage(pc, dmg, false, true);
                if (pc.isInvisble()) {
                    pc.delInvis();
                }
                final S_SkillSound sound = new S_SkillSound(pc.getId(), 11736);
                pc.sendPacketsX8(sound);
                final S_DoActionGFX pack = new S_DoActionGFX(pc.getId(), 2);
                pc.sendPacketsX8(pack);
                final S_HPUpdate newHp = new S_HPUpdate(pc.getCurrentHp(), pc.getMaxHp());
                pc.sendPackets(newHp);
                if (pc.isInParty()) {
                    pc.getParty().updateMiniHP(pc);
                    break;
                }
                break;
            }
            case 2: {
                if ((x > 32880 && x < 32892 && y > 32646 && y < 32658 && m == 4) || (x > 32662 && x < 32674 && y > 32297 && y < 32309 && m == 4)) {
                    this.spellBook(pc, skillId, itemObj);
                    break;
                }
                if ((x <= 33116 || x >= 33128 || y <= 32930 || y >= 32942 || m != 4) && (x <= 33135 || x >= 33146 || y <= 32232 || y >= 32249 || m != 4) && (x <= 32791 || x >= 32796 || y <= 32842 || y >= 32848 || m != 76)) {
                    final S_ServerMessage msg = new S_ServerMessage(79);
                    pc.sendPackets(msg);
                    break;
                }
                pc.getInventory().removeItem(pc.getInventory().getItem(itemObj), 1L);
                final short dmg = (short)(Math.random() * 50.0 + 30.0);
                pc.receiveDamage(pc, dmg, false, true);
                if (pc.isInvisble()) {
                    pc.delInvis();
                }
                final S_SkillSound sound = new S_SkillSound(pc.getId(), 11736);
                pc.sendPacketsX8(sound);
                final S_DoActionGFX pack = new S_DoActionGFX(pc.getId(), 2);
                pc.sendPacketsX8(pack);
                final S_HPUpdate newHp = new S_HPUpdate(pc.getCurrentHp(), pc.getMaxHp());
                pc.sendPackets(newHp);
                if (pc.isInParty()) {
                    pc.getParty().updateMiniHP(pc);
                    break;
                }
                break;
            }
            case 3: {
                if ((x > 33049 && x < 33061 && y > 32330 && y < 32343 && m == 4) || (x > 32788 && x < 32794 && y > 32847 && y < 32853 && m == 75)) {
                    this.spellBook(pc, skillId, itemObj);
                    break;
                }
                final S_ServerMessage msg = new S_ServerMessage(79);
                pc.sendPackets(msg);
                break;
            }
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9: {
                this.spellBook(pc, skillId, itemObj);
                break;
            }
        }
    }
    
    private void spellBook(final L1PcInstance pc, final int skillId, final int itemObj) {
        pc.getInventory().removeItem(pc.getInventory().getItem(itemObj), 1L);
        pc.sendPackets(new S_AddSkill(pc, skillId));
        final char c = 'ã';
        final S_SkillSound sound = new S_SkillSound(pc.getId(), 227);
        pc.sendPacketsX8(sound);
        final L1Skills skill = SkillsTable.get().getTemplate(skillId);
        final String skillName = skill.getName();
        CharSkillReading.get().spellMastery(pc.getId(), skillId, skillName, 0, 0);
        this.GiveSkillItem(pc, skillId);
    }
    
    private void GiveSkillItem(final L1PcInstance pc, final int skillId) {
        int itemid = 0;
        if (pc.isWarrior()) {
            switch (skillId) {
                case 225: {
                    itemid = 80058;
                    break;
                }
                case 226: {
                    itemid = 80059;
                    break;
                }
                case 228: {
                    itemid = 80060;
                    break;
                }
                case 229: {
                    itemid = 80061;
                    break;
                }
                case 230: {
                    itemid = 80062;
                    break;
                }
            }
        }
        else if (pc.isWizard()) {
            if (skillId == 80) {
                itemid = 80206;
            }
        }
        else if (pc.isIllusionist() && skillId == 218) {
            itemid = 80207;
        }
        if (itemid != 0) {
            final L1ItemInstance item = ItemTable.get().createItem(itemid);
            item.setIdentified(true);
            pc.getInventory().storeItem(item);
        }
    }
}
