package com.lineage.data.cmd;

import java.util.Random;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;

public abstract class EnchantExecutor
{
    public abstract void failureEnchant(final L1PcInstance p0, final L1ItemInstance p1);
    
    public abstract void failureEnchant2(final L1PcInstance p0, final L1ItemInstance p1);
    
    public abstract void successEnchant(final L1PcInstance p0, final L1ItemInstance p1, final int p2);
    
    public int randomELevel(final L1ItemInstance item, final int bless) {
        int level = 0;
        switch (bless) {
            case 0:
            case 128: {
                if (item.getBless() >= 3) {
                    break;
                }
                final Random random = new Random();

             // ✅ 修改開始：加入隱性偏移邏輯以降低高強化成功率
             int i = random.nextInt(100) + 1;

             // 如果裝備是防具，且強化等級大於等於 +3，降低成功機率
             if (item.getItem().getUseType() != 1 && item.getEnchantLevel() >= 3) {
                 i += 10; // 偏移亂數，讓 +2 和 +3 機率下降
                 if (i > 100) {
                     i = 100;
                 }
             }

             // 如果裝備是武器，且強化等級大於等於 +4，進一步降低成功機率
             if (item.getItem().getUseType() == 1 && item.getEnchantLevel() >= 4) {
                 i += 15; // 偏移更多，讓武器越高強越難
                 if (i > 100) {
                     i = 100;
                 }
             }
             // ✅ 修改結束

             if (item.getEnchantLevel() <= 2) {
                 if (i < 32) {
                     level = 1;
                     break;
                 }
                 if (i >= 33 && i <= 76) {
                     level = 2;
                     break;
                 }
                 if (i >= 77 && i <= 100) {
                     level = 3;
                     break;
                 }
                 break;
             } else {
                 if (item.getEnchantLevel() < 3 || item.getEnchantLevel() > 5) {
                     level = 1;
                     break;
                 }
                 if (i < 50) {
                     level = 2;
                     break;
                 }
                 level = 1;
                 break;
             }
            }
            case 1:
            case 129: {
                if (item.getBless() < 3) {
                    level = 1;
                    break;
                }
                break;
            }
            case 2:
            case 130: {
                if (item.getBless() < 3) {
                    level = -1;
                    break;
                }
                break;
            }
            case 3:
            case 131: {
                if (item.getBless() == 3) {
                    level = 1;
                    break;
                }
                break;
            }
        }
        return level;
    }
}
