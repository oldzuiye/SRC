package com.lineage.data.cmd;

import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.datatables.lock.CharSkillReading;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;

public class Skill_Check
{
    public static void check(final L1PcInstance pc, final L1ItemInstance item, final int skillid, final int magicLv, final int attribute) {
        if (CharSkillReading.get().spellCheck(pc.getId(), skillid)) {
            final S_ServerMessage msg = new S_ServerMessage(79);
            pc.sendPackets(msg);
        }
        else if (skillid != 0) {
            final Skill_StudyingExecutor addSkill = new Skill_Studying();
            addSkill.magic(pc, skillid, magicLv, attribute, item.getId());
        }
    }
}
