package com.lineage.data.cmd;

import com.lineage.server.model.Instance.L1PcInstance;

public interface Skill_StudyingExecutor
{
    void magic(final L1PcInstance p0, final int p1, final int p2, final int p3, final int p4);
}
