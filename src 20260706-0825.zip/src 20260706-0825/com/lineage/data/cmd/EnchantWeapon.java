package com.lineage.data.cmd;

import com.lineage.server.world.World;
import com.lineage.config.ConfigOther;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.datatables.lock.LogEnchantReading;
import com.lineage.config.ConfigRecord;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class EnchantWeapon extends EnchantExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)EnchantWeapon.class);
    }
    
    @Override
    public void failureEnchant(final L1PcInstance pc, final L1ItemInstance item) {
        if (item.getproctect()) {
            item.setEnchantLevel(item.getEnchantLevel() - 1);
            pc.getInventory().updateItem(item, 4);
            pc.getInventory().saveItem(item, 4);
            item.setproctect(false);
            pc.sendPackets(new S_ServerMessage(1310));
            return;
        }
        final StringBuilder s = new StringBuilder();
        if (ConfigRecord.LOGGING_BAN_ENCHANT) {
            LogEnchantReading.get().failureEnchant(pc, item);
        }
        if (!item.isIdentified()) {
            s.append(item.getName());
        }
        else {
            String pm = "";
            if (item.getEnchantLevel() > 0) {
                pm = "+";
            }
            s.append(String.valueOf(String.valueOf(pm)) + item.getEnchantLevel() + " " + item.getName());
        }
        pc.sendPackets(new S_ServerMessage(164, s.toString(), "$252"));
        pc.getInventory().removeItem(item, item.getCount());
        EnchantWeapon._log.info((Object)("人物:" + pc.getName() + "點爆物品(武器)" + item.getLogName() + " 物品OBJID:" + item.getId()));
    }
    
    @Override
    public void failureEnchant2(final L1PcInstance pc, final L1ItemInstance item) {
        if (item.getproctect()) {
            item.setproctect(false);
            pc.sendPackets(new S_SystemMessage("裝備保護的力量消失了。"));
        }
        final StringBuilder s = new StringBuilder();
        if (!item.isIdentified()) {
            s.append(item.getName());
        }
        else {
            String pm = "";
            if (item.getEnchantLevel() > 0) {
                pm = "+";
            }
            s.append(String.valueOf(String.valueOf(pm)) + item.getEnchantLevel() + " " + item.getName());
        }
        pc.sendPackets(new S_ServerMessage(160, s.toString(), "$252", "$248"));
        EnchantWeapon._log.info((Object)("人物:" + pc.getName() + "強化失敗(武器沒消失)" + item.getLogName() + " 物品OBJID:" + item.getId()));
    }
    
    @Override
    public void successEnchant(final L1PcInstance pc, final L1ItemInstance item, final int randomELevel) {
        if (item.getproctect()) {
            item.setproctect(false);
            pc.sendPackets(new S_SystemMessage("裝備保護的力量消失了。"));
        }
        final StringBuilder s = new StringBuilder();
        final StringBuilder sa = new StringBuilder();
        final StringBuilder sb = new StringBuilder();
        if (!item.isIdentified()) {
            s.append(item.getName());
        }
        else {
            s.append(item.getLogName());
        }
        switch (randomELevel) {
            case 0: {
                pc.sendPackets(new S_ServerMessage(160, s.toString(), "$252", "$248"));
                return;
            }
            case -1: {
                sa.append("$246");
                sb.append("$247");
                break;
            }
            case 1: {
                sa.append("$245");
                sb.append("$247");
                break;
            }
            case 2:
            case 3: {
                sa.append("$245");
                sb.append("$248");
                break;
            }
        }
        pc.sendPackets(new S_ServerMessage(161, s.toString(), sa.toString(), sb.toString()));
        final int oldEnchantLvl = item.getEnchantLevel();
        final int newEnchantLvl = oldEnchantLvl + randomELevel;
        if (ConfigOther.NEW_ENCHANT_LV && newEnchantLvl >= item.getItem().get_safeenchant() + ConfigOther.ENCHANT_WEAPON) {
            World.get().broadcastPacketToAll(new S_ServerMessage("\\aD玩家 -> [ " + pc.getName() + " ]"));
            World.get().broadcastPacketToAll(new S_ServerMessage("\\aD武器強化成功 -> [ " + s.toString() + " ]"));
            World.get().broadcastPacketToAll(new S_ServerMessage("\\aD強化等級 -> [ +" + newEnchantLvl + " ]"));
        }
        item.setEnchantLevel(newEnchantLvl);
        pc.getInventory().updateItem(item, 4);
        pc.getInventory().saveItem(item, 4);
        if (randomELevel == -1) {
            final int oldAttrEnchantLvl = item.getAttrEnchantLevel();
            if (oldAttrEnchantLvl >= 1) {
                final int newAttrEnchantLvl = oldAttrEnchantLvl + randomELevel;
                item.setAttrEnchantLevel(newAttrEnchantLvl);
                pc.getInventory().updateItem(item, 2048);
                pc.getInventory().saveItem(item, 2048);
            }
        }
    }
}
