package com.lineage.data.cmd;

import com.lineage.server.world.World;
import com.lineage.config.ConfigOther;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.datatables.lock.LogEnchantReading;
import com.lineage.config.ConfigRecord;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.S_PacketBox;
import com.lineage.server.serverpackets.S_OwnCharStatus;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SPMR;
import com.lineage.server.model.Instance.L1ItemPower;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class EnchantArmor extends EnchantExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)EnchantArmor.class);
    }
    
    @Override
    public void failureEnchant(final L1PcInstance pc, final L1ItemInstance item) {
        if (item.getproctect()) {
            final int itemid = item.getItemId();
            final int oldenchantlvl = item.getEnchantLevel();
            item.setEnchantLevel(item.getEnchantLevel() - 1);
            pc.getInventory().updateItem(item, 4);
            pc.getInventory().saveItem(item, 4);
            if (item.isEquipped()) {
                pc.addAc(1);
                final Integer mr = L1ItemPower.MR.get(itemid);
                if (mr != null) {
                    pc.addMr(-1 * mr);
                }
                final Integer sp = L1ItemPower.SP.get(itemid);
                if (sp != null) {
                    if (itemid == 20107 || itemid == 120107) {
                        if (oldenchantlvl >= 3) {
                            pc.addSp(-1 * sp);
                        }
                    }
                    else if (itemid == 300431) {
                        switch (oldenchantlvl) {
                            case 5:
                            case 7:
                            case 9: {
                                pc.addSp(-1 * sp);
                                break;
                            }
                        }
                    }
                    else {
                        pc.addSp(-1 * sp);
                    }
                }
                final Integer hp = L1ItemPower.HP.get(itemid);
                if (hp != null) {
                    if (itemid == 300429) {
                        switch (oldenchantlvl) {
                            case 5:
                            case 7:
                            case 9: {
                                pc.addMaxHp(-1 * hp);
                                break;
                            }
                        }
                    }
                    else {
                        pc.addMaxHp(-1 * hp);
                    }
                }
                final Integer hit = L1ItemPower.HIT.get(itemid);
                if (hit != null) {
                    if (itemid == 400051) {
                        if (oldenchantlvl >= 5) {
                            pc.addHitModifierByArmor(-1 * hit);
                        }
                    }
                    else {
                        pc.addHitModifierByArmor(-1 * hit);
                    }
                }
                final Integer dmgr = L1ItemPower.DMG_REDUCE.get(itemid);
                if (dmgr != null) {
                    if (itemid == 300430) {
                        switch (oldenchantlvl) {
                            case 5:
                            case 7:
                            case 9: {
                                pc.addDamageReductionByArmor(-1 * dmgr);
                                break;
                            }
                        }
                    }
                    else {
                        pc.addDamageReductionByArmor(-1 * dmgr);
                    }
                }
                pc.sendPackets(new S_SPMR(pc));
                pc.sendPackets(new S_OwnCharStatus(pc));
                pc.sendPackets(new S_PacketBox(132, pc.getEr()));
            }
            item.setproctect(false);
            pc.sendPackets(new S_ServerMessage(1310));
            return;
        }
        final StringBuilder s = new StringBuilder();
        if (ConfigRecord.LOGGING_BAN_ENCHANT) {
            LogEnchantReading.get().failureEnchant(pc, item);
        }
        if (!item.isIdentified()) {
            s.append(item.getName());
        }
        else {
            s.append(item.getLogName());
        }
        pc.sendPackets(new S_ServerMessage(164, s.toString(), "$252"));
        pc.getInventory().removeItem(item, item.getCount());
        EnchantArmor._log.info((Object)("人物:" + pc.getName() + "點爆物品" + item.getLogName() + " 物品OBJID:" + item.getId()));
    }
    
    @Override
    public void successEnchant(final L1PcInstance pc, final L1ItemInstance item, final int randomELevel) {
        if (item.getproctect()) {
            item.setproctect(false);
            pc.sendPackets(new S_SystemMessage("裝備保護的力量消失了。"));
        }
        final StringBuilder s = new StringBuilder();
        final StringBuilder sa = new StringBuilder();
        final StringBuilder sb = new StringBuilder();
        if (!item.isIdentified()) {
            s.append(item.getName());
        }
        else if (item.getEnchantLevel() > 0) {
            s.append("+" + item.getEnchantLevel() + " " + item.getName());
        }
        else if (item.getEnchantLevel() < 0) {
            s.append(String.valueOf(String.valueOf(item.getEnchantLevel())) + " " + item.getName());
        }
        else {
            s.append(item.getName());
        }
        switch (randomELevel) {
            case 0: {
                pc.sendPackets(new S_ServerMessage(160, s.toString(), "$252", "$248"));
                return;
            }
            case -1: {
                sa.append("$246");
                sb.append("$247");
                break;
            }
            case 1: {
                sa.append("$252");
                sb.append("$247");
                break;
            }
            case 2:
            case 3: {
                sa.append("$252");
                sb.append("$248");
                break;
            }
        }
        pc.sendPackets(new S_ServerMessage(161, s.toString(), sa.toString(), sb.toString()));
        final int oldEnchantLvl = item.getEnchantLevel();
        final int newEnchantLvl = oldEnchantLvl + randomELevel;
        item.setEnchantLevel(newEnchantLvl);
        pc.getInventory().updateItem(item, 4);
        pc.getInventory().saveItem(item, 4);
        if (ConfigOther.NEW_ENCHANT_LV && newEnchantLvl >= item.getItem().get_safeenchant() + ConfigOther.ENCHANT_ARMOR) {
            World.get().broadcastPacketToAll(new S_ServerMessage("\\aD玩家 -> [ " + pc.getName() + " ]"));
            World.get().broadcastPacketToAll(new S_ServerMessage("\\aD防具強化成功 -> [ " + s.toString() + " ]"));
            World.get().broadcastPacketToAll(new S_ServerMessage("\\aD強化等級 -> [ +" + newEnchantLvl + " ]"));
        }
        if (item.isEquipped()) {
            final int use_type = item.getItem().getUseType();
            final int itemid = item.getItemId();
            int EnchantLvl = item.getEnchantLevel();
            if (randomELevel == -1) {
                ++EnchantLvl;
            }
            switch (use_type) {
                case 2:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 25:
                case 47:
                case 72: {
                    pc.addAc(-randomELevel);
                    final Integer mr = L1ItemPower.MR.get(itemid);
                    if (mr != null) {
                        pc.addMr(randomELevel * mr);
                    }
                    final Integer sp = L1ItemPower.SP.get(itemid);
                    if (sp != null) {
                        if (itemid == 20107 || itemid == 120107) {
                            if (EnchantLvl >= 3) {
                                pc.addSp(randomELevel * sp);
                            }
                        }
                        else if (itemid == 300431) {
                            switch (EnchantLvl) {
                                case 5:
                                case 7:
                                case 9: {
                                    if (randomELevel >= 1 && randomELevel <= 3) {
                                        pc.addSp(1 * sp);
                                        break;
                                    }
                                    if (randomELevel == -1) {
                                        pc.addSp(-1 * sp);
                                        break;
                                    }
                                    break;
                                }
                                case 6: {
                                    if (randomELevel == 2) {
                                        pc.addSp(1 * sp);
                                        break;
                                    }
                                    break;
                                }
                            }
                        }
                        else {
                            pc.addSp(randomELevel * sp);
                        }
                    }
                    final Integer hp = L1ItemPower.HP.get(itemid);
                    if (hp != null) {
                        if (itemid == 300429) {
                            switch (EnchantLvl) {
                                case 5:
                                case 7:
                                case 9: {
                                    if (randomELevel >= 1 && randomELevel <= 3) {
                                        pc.addMaxHp(1 * hp);
                                        break;
                                    }
                                    if (randomELevel == -1) {
                                        pc.addMaxHp(-1 * hp);
                                        break;
                                    }
                                    break;
                                }
                                case 6: {
                                    if (randomELevel == 2) {
                                        pc.addMaxHp(1 * hp);
                                        break;
                                    }
                                    break;
                                }
                            }
                        }
                        else {
                            pc.addMaxHp(randomELevel * hp);
                        }
                    }
                    final Integer hit = L1ItemPower.HIT.get(itemid);
                    if (hit != null) {
                        if (itemid == 400051) {
                            if (EnchantLvl >= 5) {
                                pc.addHitModifierByArmor(randomELevel * hit);
                            }
                        }
                        else {
                            pc.addHitModifierByArmor(randomELevel * hit);
                        }
                    }
                    final Integer dmgr = L1ItemPower.DMG_REDUCE.get(itemid);
                    if (dmgr == null) {
                        break;
                    }
                    if (itemid == 300430) {
                        switch (EnchantLvl) {
                            case 5:
                            case 7:
                            case 9: {
                                if (randomELevel >= 1 && randomELevel <= 3) {
                                    pc.addDamageReductionByArmor(1 * dmgr);
                                    break;
                                }
                                if (randomELevel == -1) {
                                    pc.addDamageReductionByArmor(-1 * dmgr);
                                    break;
                                }
                                break;
                            }
                            case 6: {
                                if (randomELevel == 2) {
                                    pc.addDamageReductionByArmor(1 * dmgr);
                                    break;
                                }
                                break;
                            }
                        }
                        break;
                    }
                    pc.addDamageReductionByArmor(randomELevel * dmgr);
                    break;
                }
                case 23:
                case 24:
                case 37:
                case 40: {
                    if (item.getItem().get_greater() != 3) {
                        item.GreaterAtEnchant(pc, randomELevel);
                        break;
                    }
                    break;
                }
            }
            pc.sendPackets(new S_SPMR(pc));
            pc.sendPackets(new S_OwnCharStatus(pc));
            pc.sendPackets(new S_PacketBox(132, pc.getEr()));
        }
    }
    
    @Override
    public void failureEnchant2(final L1PcInstance paramL1PcInstance, final L1ItemInstance paramL1ItemInstance) {
    }
}
