package com.lineage.data.executor;

import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.server.templates.L1Quest;

public abstract class QuestExecutor
{
    public abstract void execute(final L1Quest p0);
    
    public abstract void startQuest(final L1PcInstance p0);
    
    public abstract void endQuest(final L1PcInstance p0);
    
    public abstract void showQuest(final L1PcInstance p0);
    
    public abstract void stopQuest(final L1PcInstance p0);
}
