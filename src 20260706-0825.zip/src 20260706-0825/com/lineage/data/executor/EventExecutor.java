package com.lineage.data.executor;

import com.lineage.server.templates.L1Event;

public abstract class EventExecutor
{
    public abstract void execute(final L1Event p0);
}
