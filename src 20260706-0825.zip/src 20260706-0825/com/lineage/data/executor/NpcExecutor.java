package com.lineage.data.executor;

import com.lineage.server.model.L1Character;
import com.lineage.server.model.Instance.L1NpcInstance;
import com.lineage.server.model.Instance.L1PcInstance;

public abstract class NpcExecutor
{
    public abstract int type();
    
    public void talk(final L1PcInstance pc, final L1NpcInstance npc) {
    }
    
    public void action(final L1PcInstance pc, final L1NpcInstance npc, final String cmd, final long amount) {
    }
    
    public void attack(final L1PcInstance pc, final L1NpcInstance npc) {
    }
    
    public L1PcInstance death(final L1Character lastAttacker, final L1NpcInstance npc) {
        return null;
    }
    
    public int workTime() {
        return 0;
    }
    
    public void work(final L1NpcInstance npc) {
    }
    
    public void spawn(final L1NpcInstance npc) {
    }
    
    public String[] get_set() {
        return null;
    }
    
    public void set_set(final String[] set) {
    }
}
