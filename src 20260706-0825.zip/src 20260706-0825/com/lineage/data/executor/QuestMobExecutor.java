package com.lineage.data.executor;

import com.lineage.server.templates.L1QuestUser;

public abstract class QuestMobExecutor
{
    public abstract void stopQuest(final L1QuestUser p0);
}
