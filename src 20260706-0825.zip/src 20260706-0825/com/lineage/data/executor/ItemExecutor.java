package com.lineage.data.executor;

import com.lineage.server.utils.BinaryOutputStream;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;

public abstract class ItemExecutor
{
    public abstract void execute(final int[] p0, final L1PcInstance p1, final L1ItemInstance p2);
    
    public String[] get_set() {
        return null;
    }
    
    public void set_set(final String[] set) {
    }
    
    public BinaryOutputStream itemStatus(final L1ItemInstance item) {
        return null;
    }
}
