package com.lineage.data.item_armor;

import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.ItemExecutor;

public class Hades_Cloak extends ItemExecutor
{
    private static final Log _log;
    private int _r;
    private int _dmg_min;
    private int _dmg_max;
    
    static {
        _log = LogFactory.getLog((Class)Hades_Cloak.class);
    }
    
    public static ItemExecutor get() {
        return new Hades_Cloak();
    }
    
    @Override
    public void execute(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        try {
            if (item == null) {
                return;
            }
            if (pc == null) {
                return;
            }
            switch (data[0]) {
                case 0: {
                    pc.set_hades_cloak(0, 0, 0);
                    break;
                }
                case 1: {
                    pc.set_hades_cloak(this._r, this._dmg_min, this._dmg_max);
                    break;
                }
            }
        }
        catch (Exception e) {
            Hades_Cloak._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    @Override
    public void set_set(final String[] set) {
        try {
            this._r = Integer.parseInt(set[1]);
        }
        catch (Exception ex) {}
        try {
            this._dmg_min = Integer.parseInt(set[2]);
        }
        catch (Exception ex2) {}
        try {
            this._dmg_max = Integer.parseInt(set[3]);
        }
        catch (Exception ex3) {}
    }
}
