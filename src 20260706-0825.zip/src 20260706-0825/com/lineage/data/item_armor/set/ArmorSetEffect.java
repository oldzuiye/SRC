package com.lineage.data.item_armor.set;

import com.lineage.server.model.Instance.L1PcInstance;

public interface ArmorSetEffect
{
    void giveEffect(final L1PcInstance p0);
    
    void cancelEffect(final L1PcInstance p0);
    
    int get_mode();
}
