package com.lineage.data.event;

import java.util.Iterator;
import com.lineage.server.serverpackets.S_OwnCharStatus;
import com.lineage.server.serverpackets.S_SPMR;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_PacketBox;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import com.lineage.server.templates.L1Event;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class CardSet extends EventExecutor
{
    private static final Log _log;
    public static boolean START;
    public static int USE_TIME;
    public static int USE_TIME2;
    
    static {
        _log = LogFactory.getLog((Class)CardSet.class);
        CardSet.START = false;
    }
    
    public static EventExecutor get() {
        return new CardSet();
    }
    
    @Override
    public void execute(final L1Event event) {
        try {
            CardSet.START = true;
            final String[] set = event.get_eventother().split(",");
            try {
                CardSet.USE_TIME = Integer.parseInt(set[0]);
            }
            catch (Exception e2) {
                CardSet.USE_TIME = 720;
                CardSet._log.error((Object)"未設定月卡使用期限(使用預設720小時)");
            }
            try {
                CardSet.USE_TIME2 = Integer.parseInt(set[1]);
            }
            catch (Exception e2) {
                CardSet.USE_TIME2 = 24;
                CardSet._log.error((Object)"未設定日卡使用期限(使用預設24小時)");
            }
        }
        catch (Exception e) {
            CardSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    public static void load_card_mode(final L1PcInstance pc) {
        try {
            for (final L1ItemInstance item : pc.getInventory().getItems()) {
                final String classname = item.getItem().getclassname();
                if (classname.startsWith("shop.VIP_Card_") && item.get_card_use() == 1 && item.isEquipped()) {
                    pc.sendPackets(new S_PacketBox(180, 1, 470));
                    int card_id = 0;
                    try {
                        final String cardmode = classname.substring(14);
                        card_id = Integer.parseInt(cardmode);
                    }
                    catch (Exception e2) {
                        final String cardmode2 = classname.substring(15);
                        card_id = Integer.parseInt(cardmode2);
                    }
                    if (card_id == 0) {
                        return;
                    }
                    switch (card_id) {
                        case 1: {
                            pc.set_expadd(20);
                            pc.addSp(1);
                            pc.addMaxHp(50);
                            pc.addMaxMp(25);
                            break;
                        }
                        case 2: {
                            pc.set_expadd(40);
                            pc.addSp(2);
                            pc.addMaxHp(100);
                            pc.addMaxMp(50);
                            pc.addDmgup(1);
                            pc.addBowDmgup(1);
                            break;
                        }
                        case 3: {
                            pc.set_expadd(60);
                            pc.addSp(3);
                            pc.addMaxHp(150);
                            pc.addMaxMp(75);
                            pc.addDmgup(3);
                            pc.addBowDmgup(3);
                            pc.addHitup(3);
                            pc.addBowHitup(3);
                            break;
                        }
                        case 4: {
                            pc.set_expadd(80);
                            pc.addSp(4);
                            pc.addMaxHp(200);
                            pc.addMaxMp(100);
                            pc.addDmgup(5);
                            pc.addBowDmgup(5);
                            pc.addHitup(5);
                            pc.addBowHitup(5);
                            pc.addDamageReductionByArmor(5);
                            break;
                        }
                        case 5: {
                            pc.set_expadd(100);
                            pc.addSp(6);
                            pc.addMaxHp(300);
                            pc.addMaxMp(180);
                            pc.addDmgup(8);
                            pc.addBowDmgup(8);
                            pc.addHitup(8);
                            pc.addBowHitup(8);
                            pc.addDamageReductionByArmor(8);
                            pc.add_up_hp_potion(25);
                            pc.add_uhp_number(25);
                            break;
                        }
                    }
                    pc.sendPackets(new S_SPMR(pc));
                    pc.sendPackets(new S_OwnCharStatus(pc));
                    pc.sendPackets(new S_PacketBox(132, pc.getEr()));
                }
            }
        }
        catch (Exception e) {
            CardSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    public static void set_card_mode(final L1PcInstance pc, final L1ItemInstance item) {
        if (!CardSet.START) {
            return;
        }
        try {
            final String classname = item.getItem().getclassname();
            if (!classname.startsWith("shop.VIP_Card_")) {
                return;
            }
            int card_id = 0;
            try {
                final String cardmode = classname.substring(14);
                card_id = Integer.parseInt(cardmode);
            }
            catch (Exception e2) {
                final String cardmode2 = classname.substring(15);
                card_id = Integer.parseInt(cardmode2);
            }
            if (card_id == 0) {
                return;
            }
            pc.sendPackets(new S_PacketBox(180, 1, 470));
            item.setEquipped(true);
            switch (card_id) {
                case 1: {
                    pc.set_expadd(20);
                    pc.addSp(1);
                    pc.addMaxHp(50);
                    pc.addMaxMp(25);
                    break;
                }
                case 2: {
                    pc.set_expadd(40);
                    pc.addSp(2);
                    pc.addMaxHp(100);
                    pc.addMaxMp(50);
                    pc.addDmgup(1);
                    pc.addBowDmgup(1);
                    break;
                }
                case 3: {
                    pc.set_expadd(60);
                    pc.addSp(3);
                    pc.addMaxHp(150);
                    pc.addMaxMp(75);
                    pc.addDmgup(3);
                    pc.addBowDmgup(3);
                    pc.addHitup(3);
                    pc.addBowHitup(3);
                    break;
                }
                case 4: {
                    pc.set_expadd(80);
                    pc.addSp(4);
                    pc.addMaxHp(200);
                    pc.addMaxMp(100);
                    pc.addDmgup(5);
                    pc.addBowDmgup(5);
                    pc.addHitup(5);
                    pc.addBowHitup(5);
                    pc.addDamageReductionByArmor(5);
                    break;
                }
                case 5: {
                    pc.set_expadd(100);
                    pc.addSp(6);
                    pc.addMaxHp(300);
                    pc.addMaxMp(180);
                    pc.addDmgup(8);
                    pc.addBowDmgup(8);
                    pc.addHitup(8);
                    pc.addBowHitup(8);
                    pc.addDamageReductionByArmor(8);
                    pc.add_up_hp_potion(25);
                    pc.add_uhp_number(25);
                    break;
                }
            }
            pc.sendPackets(new S_SPMR(pc));
            pc.sendPackets(new S_OwnCharStatus(pc));
            pc.sendPackets(new S_PacketBox(132, pc.getEr()));
        }
        catch (Exception e) {
            CardSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    public static void remove_card_mode(final L1PcInstance pc, final L1ItemInstance item) {
        if (!CardSet.START) {
            return;
        }
        try {
            final String classname = item.getItem().getclassname();
            if (!classname.startsWith("shop.VIP_Card_")) {
                return;
            }
            int card_id = 0;
            try {
                final String cardmode = classname.substring(14);
                card_id = Integer.parseInt(cardmode);
            }
            catch (Exception e2) {
                final String cardmode2 = classname.substring(15);
                card_id = Integer.parseInt(cardmode2);
            }
            if (card_id == 0) {
                return;
            }
            pc.sendPackets(new S_PacketBox(180, 0, 470));
            item.setEquipped(false);
            switch (card_id) {
                case 1: {
                    pc.set_expadd(-20);
                    pc.addSp(-1);
                    pc.addMaxHp(-50);
                    pc.addMaxMp(-25);
                    break;
                }
                case 2: {
                    pc.set_expadd(-40);
                    pc.addSp(-2);
                    pc.addMaxHp(-100);
                    pc.addMaxMp(-50);
                    pc.addDmgup(-1);
                    pc.addBowDmgup(-1);
                    break;
                }
                case 3: {
                    pc.set_expadd(-60);
                    pc.addSp(-3);
                    pc.addMaxHp(-150);
                    pc.addMaxMp(-75);
                    pc.addDmgup(-3);
                    pc.addBowDmgup(-3);
                    pc.addHitup(-3);
                    pc.addBowHitup(-3);
                    break;
                }
                case 4: {
                    pc.set_expadd(-80);
                    pc.addSp(-4);
                    pc.addMaxHp(-200);
                    pc.addMaxMp(-100);
                    pc.addDmgup(-5);
                    pc.addBowDmgup(-5);
                    pc.addHitup(-5);
                    pc.addBowHitup(-5);
                    pc.addDamageReductionByArmor(-5);
                    break;
                }
                case 5: {
                    pc.set_expadd(-100);
                    pc.addSp(-6);
                    pc.addMaxHp(-300);
                    pc.addMaxMp(-180);
                    pc.addDmgup(-8);
                    pc.addBowDmgup(-8);
                    pc.addHitup(-8);
                    pc.addBowHitup(-8);
                    pc.addDamageReductionByArmor(-8);
                    pc.add_up_hp_potion(-25);
                    pc.add_uhp_number(-25);
                    break;
                }
            }
            pc.sendPackets(new S_SPMR(pc));
            pc.sendPackets(new S_OwnCharStatus(pc));
            pc.sendPackets(new S_PacketBox(132, pc.getEr()));
        }
        catch (Exception e) {
            CardSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
