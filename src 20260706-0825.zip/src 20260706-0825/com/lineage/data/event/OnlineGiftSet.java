package com.lineage.data.event;

import com.lineage.server.world.World;
import com.lineage.server.thread.GeneralThreadPool;
import java.util.concurrent.ScheduledFuture;
import java.util.TimerTask;
import com.lineage.server.templates.L1Item;
import com.lineage.server.utils.PerformanceTimer;
import com.lineage.server.templates.L1Event;
import com.lineage.server.model.Instance.L1ItemInstance;
import java.util.Iterator;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.datatables.ItemTable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import com.lineage.server.model.Instance.L1PcInstance;
import java.util.ArrayList;
import java.util.Map;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class OnlineGiftSet extends EventExecutor {
    private static final Log _log;
    private static int _time;
    private static final Map<Integer, ArrayList<GetItemData>> _giftList;
    private static final Map<L1PcInstance, Integer> _getMap;

    static {
        _log = LogFactory.getLog((Class) OnlineGiftSet.class);
        OnlineGiftSet._time = 0;
        _giftList = new HashMap<>();
        _getMap = new ConcurrentHashMap<>();
    }

    public static EventExecutor get() {
        return new OnlineGiftSet();
    }

    public static void add(final L1PcInstance tgpc) {
        if (OnlineGiftSet._time == 0) {
            return;
        }
        _getMap.putIfAbsent(tgpc, OnlineGiftSet._time);
    }

    public static void remove(final L1PcInstance tgpc) {
        if (OnlineGiftSet._time == 0) {
            return;
        }
        if (tgpc == null || World.get().getPlayer(tgpc.getName()) == null || tgpc.getOnlineStatus() == 0) {
            _getMap.remove(tgpc);
        }
    }

    private static void getitem(final L1PcInstance tgpc) {
        try {
            if (!check(tgpc)) {
                return;
            }
            ArrayList<GetItemData> value = _giftList.get(3);
            if (tgpc.isPrivateShop()) {
                value = _giftList.getOrDefault(1, value);
            } else if (tgpc.isFishing()) {
                value = _giftList.getOrDefault(2, value);
            }
            if (value == null) {
                return;
            }
            for (final GetItemData iteminfo : value) {
                if (iteminfo == null) {
                    continue;
                }
                final L1ItemInstance item = ItemTable.get().createItem(iteminfo._getItemId);
                if (item == null) {
                    continue;
                }
                item.setCount(iteminfo._getAmount);
                if (tgpc.getInventory().checkAddItem(item, 1L) == 0) {
                    tgpc.getInventory().storeItem(item);
                    tgpc.sendPackets(new S_ServerMessage("滿足條件獲得連線獎勵物品: " + item.getLogName()));
                }
            }
        } catch (Exception e) {
            OnlineGiftSet._log.error("獎勵發送異常: ", e);
        }
    }

    public static boolean check(final L1PcInstance tgpc) {
        if (tgpc == null || tgpc.getOnlineStatus() == 0 || tgpc.getNetConnection() == null) {
            return false;
        }
        return true;
    }

    @Override
    public void execute(final L1Event event) {
        final PerformanceTimer timer = new PerformanceTimer();
        boolean isError = false;
        try {
            final String[] set = event.get_eventother().split(",");
            try {
                OnlineGiftSet._time = Integer.parseInt(set[0]);
                if (OnlineGiftSet._time <= 0) {
                    _log.error("設定給予獎勵的時間(分鐘)異常 - 將不啟用本項設置");
                    isError = true;
                }
            } catch (Exception e2) {
                _log.error("設定給予獎勵的時間(分鐘)異常 - 將不啟用本項設置");
                isError = true;
            }
            if (!isError) {
                for (int i = 1; i < set.length; ++i) {
                    final String[] setItem = set[i].split("#");
                    final GetItemData itemData = new GetItemData();
                    int type = Integer.parseInt(setItem[0]);
                    if (type != 1 && type != 2) {
                        type = 3;
                    }
                    itemData._getItemId = Integer.parseInt(setItem[1]);
                    final L1Item item = ItemTable.get().getTemplate(itemData._getItemId);
                    if (item == null || !item.isStackable()) {
                        _log.error("設定獎勵物品錯誤: " + itemData._getItemId);
                        continue;
                    }
                    itemData._getAmount = Math.max(1, Integer.parseInt(setItem[2]));
                    _giftList.computeIfAbsent(type, k -> new ArrayList<>()).add(itemData);
                }
            }
        } catch (Exception e) {
            _log.error("獎勵初始化異常: ", e);
            return;
        } finally {
            if (!isError) {
                final GetItemTimer getItemTimer = new GetItemTimer();
                getItemTimer.start();
                _log.info("載入獎勵成功: " + _giftList.size() + " (" + timer.get() + "ms)");
            } else {
                _time = 0;
                _giftList.clear();
            }
        }
    }

    private static class GetItemData {
        public int _getItemId;
        public int _getAmount;

        private GetItemData() {
            this._getItemId = 40308;
            this._getAmount = 1;
        }
    }

    private static class GetItemTimer extends TimerTask {
        private ScheduledFuture<?> _timer;

        public void start() {
            this._timer = GeneralThreadPool.get().scheduleAtFixedRate(this, 60000L, 60000L);
        }

        @Override
        public void run() {
            try {
                if (!_getMap.isEmpty()) {
                    for (final L1PcInstance tgpc : new ArrayList<>(_getMap.keySet())) {
                        Thread.sleep(1L);
                        if (tgpc == null || World.get().getPlayer(tgpc.getName()) == null || tgpc.getOnlineStatus() == 0) {
                            _getMap.remove(tgpc);
                            continue;
                        }
                        Integer time = _getMap.get(tgpc);
                        if (time == null || --time > 0) {
                            _getMap.put(tgpc, time);
                        } else {
                            getitem(tgpc);
                            _getMap.put(tgpc, _time + 1);
                        }
                    }
                }
            } catch (Exception e) {
                _log.error("獎勵計時異常，重啟計時器: ", e);
                if (this._timer != null && !this._timer.isCancelled()) {
                    GeneralThreadPool.get().cancel(this._timer, false);
                }
                new GetItemTimer().start();
            }
        }
    }
}
