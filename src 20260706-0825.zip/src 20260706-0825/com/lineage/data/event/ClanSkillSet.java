package com.lineage.data.event;

import com.lineage.server.timecontroller.event.ClanShowTimer;
import com.lineage.server.timecontroller.event.ClanSkillTimer;
import com.lineage.server.templates.L1Event;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class ClanSkillSet extends EventExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)ClanSkillSet.class);
    }
    
    public static EventExecutor get() {
        return new ClanSkillSet();
    }
    
    @Override
    public void execute(final L1Event event) {
        try {
            final ClanSkillTimer useTimer = new ClanSkillTimer();
            useTimer.start();
            final ClanShowTimer clanShowTimer = new ClanShowTimer();
            clanShowTimer.start();
        }
        catch (Exception e) {
            ClanSkillSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
