package com.lineage.data.event;

import com.lineage.server.world.World;
import com.lineage.server.thread.GeneralThreadPool;
import java.util.concurrent.ScheduledFuture;
import java.util.TimerTask;
import com.lineage.server.utils.PerformanceTimer;
import com.lineage.server.templates.L1Event;
import com.lineage.server.serverpackets.S_ServerMessage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import com.lineage.server.model.Instance.L1PcInstance;
import java.util.ArrayList;
import java.util.Map;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class OnlineExpSet extends EventExecutor {
    private static final Log _log;
    private static int _time;
    private static final Map<Integer, ArrayList<GetExpData>> _expList;
    private static final Map<L1PcInstance, Integer> _getMap;

    static {
        _log = LogFactory.getLog((Class) OnlineExpSet.class);
        OnlineExpSet._time = 0;
        _expList = new HashMap<>();
        _getMap = new ConcurrentHashMap<>();
    }

    public static EventExecutor get() {
        return new OnlineExpSet();
    }

    public static void add(final L1PcInstance tgpc) {
        if (_time == 0) return;
        _getMap.putIfAbsent(tgpc, _time);
    }

    public static void remove(final L1PcInstance tgpc) {
        if (_time == 0) return;
        if (tgpc == null || World.get().getPlayer(tgpc.getName()) == null || tgpc.getOnlineStatus() == 0) {
            _getMap.remove(tgpc);
        }
    }

    private static void giveExp(final L1PcInstance tgpc) {
        try {
            if (!check(tgpc)) return;

            ArrayList<GetExpData> value = _expList.get(3);
            if (tgpc.isPrivateShop()) {
                value = _expList.getOrDefault(1, value);
            } else if (tgpc.isFishing()) {
                value = _expList.getOrDefault(2, value);
            }

            if (value == null) return;

            for (final GetExpData expInfo : value) {
                if (expInfo == null) continue;
                tgpc.addExp(expInfo._expAmount);
                tgpc.sendPackets(new S_ServerMessage("滿足條件獲得經驗值獎勵: " + expInfo._expAmount));
            }
        } catch (Exception e) {
            _log.error("發放經驗值時發生錯誤: ", e);
        }
    }

    public static boolean check(final L1PcInstance tgpc) {
        if (tgpc == null || tgpc.getOnlineStatus() == 0 || tgpc.getNetConnection() == null || !tgpc.isSafetyZone()) {
            return false;
        }
        return true;
    }

    @Override
    public void execute(final L1Event event) {
        final PerformanceTimer timer = new PerformanceTimer();
        boolean isError = false;

        try {
            final String[] set = event.get_eventother().split(",");
            try {
                _time = Integer.parseInt(set[0]);
                if (_time <= 0) {
                    _log.error("設定獎勵時間(分鐘)異常 - 停用此設置");
                    isError = true;
                }
            } catch (Exception e) {
                _log.error("設定獎勵時間(分鐘)格式錯誤 - 停用此設置");
                isError = true;
            }

            if (!isError) {
                for (int i = 1; i < set.length; ++i) {
                    final String[] setExp = set[i].split("#");
                    final GetExpData expData = new GetExpData();
                    int type = Integer.parseInt(setExp[0]);
                    if (type != 1 && type != 2) {
                        type = 3;
                    }

                    expData._expAmount = Math.max(1, Integer.parseInt(setExp[1]));
                    _expList.computeIfAbsent(type, k -> new ArrayList<>()).add(expData);
                }
            }
        } catch (Exception e) {
            _log.error("初始化獎勵經驗發生錯誤: ", e);
            return;
        } finally {
            if (!isError) {
                new GetExpTimer().start();
                _log.info("載入經驗獎勵成功，共: " + _expList.size() + " 項 (" + timer.get() + "ms)");
            } else {
                _time = 0;
                _expList.clear();
            }
        }
    }

    private static class GetExpData {
        public int _expAmount;

        private GetExpData() {
            this._expAmount = 1;
        }
    }

    private static class GetExpTimer extends TimerTask {
        private ScheduledFuture<?> _timer;

        public void start() {
            this._timer = GeneralThreadPool.get().scheduleAtFixedRate(this, 60000L, 60000L);
        }

        @Override
        public void run() {
            try {
                if (!_getMap.isEmpty()) {
                    for (final L1PcInstance tgpc : new ArrayList<>(_getMap.keySet())) {
                        Thread.sleep(1L);
                        if (tgpc == null || World.get().getPlayer(tgpc.getName()) == null || tgpc.getOnlineStatus() == 0) {
                            _getMap.remove(tgpc);
                            continue;
                        }

                        Integer time = _getMap.get(tgpc);
                        if (time == null || --time > 0) {
                            _getMap.put(tgpc, time);
                        } else {
                            giveExp(tgpc);
                            _getMap.put(tgpc, _time + 1);
                        }
                    }
                }
            } catch (Exception e) {
                _log.error("經驗獎勵計時異常，重啟計時器: ", e);
                if (this._timer != null && !this._timer.isCancelled()) {
                    GeneralThreadPool.get().cancel(this._timer, false);
                }
                new GetExpTimer().start();
            }
        }
    }
}
