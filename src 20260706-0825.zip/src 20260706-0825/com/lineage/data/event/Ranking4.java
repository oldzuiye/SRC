package com.lineage.data.event;

import com.lineage.server.timecontroller.event.ranking.RankingClanTimer;
import com.lineage.server.timecontroller.event.ranking.RankingHeroTimer;
import com.lineage.server.timecontroller.event.ranking.RankingWealthTimer;
import com.lineage.server.timecontroller.event.ranking.RankingKillTimer;
import com.lineage.server.templates.L1Event;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class Ranking4 extends EventExecutor
{
    private static final Log _log;
    
    static {
        _log = LogFactory.getLog((Class)Ranking4.class);
    }
    
    public static EventExecutor get() {
        return new Ranking4();
    }
    
    @Override
    public void execute(final L1Event event) {
        try {
            final RankingKillTimer killTimer = new RankingKillTimer();
            killTimer.start();
            Thread.sleep(500L);
            final RankingWealthTimer wealthTimer = new RankingWealthTimer();
            wealthTimer.start();
            Thread.sleep(500L);
            final RankingHeroTimer heroTimer = new RankingHeroTimer();
            heroTimer.start();
            Thread.sleep(500L);
            final RankingClanTimer clanRTimer = new RankingClanTimer();
            clanRTimer.start();
        }
        catch (Exception e) {
            Ranking4._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
