package com.lineage.data.event;

import com.lineage.server.templates.L1Event;
import org.apache.commons.logging.LogFactory;
import java.util.HashMap;
import org.apache.commons.logging.Log;
import java.util.Map;
import com.lineage.data.executor.EventExecutor;

public class NetBarSet extends EventExecutor
{
    public static final Map<String, Integer> EXIPLIST;
    private static final Log _log;
    
    static {
        EXIPLIST = new HashMap<String, Integer>();
        _log = LogFactory.getLog((Class)NetBarSet.class);
    }
    
    public static EventExecutor get() {
        return new NetBarSet();
    }
    
    @Override
    public void execute(final L1Event event) {
        final String[] set = event.get_eventother().split(",");
        final String[] set2 = event.get_eventother2().split("#");
        if (set.length == set2.length) {
            for (int i = 0; i < set.length; ++i) {
                final String ipstring = set[i];
                NetBarSet.EXIPLIST.put(ipstring, Integer.valueOf(set2[i]));
            }
        }
        else {
            NetBarSet._log.warn((Object)"網咖IP登入設定錯誤");
        }
    }
}
