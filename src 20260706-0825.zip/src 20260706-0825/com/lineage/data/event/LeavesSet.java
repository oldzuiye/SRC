package com.lineage.data.event;

import com.lineage.server.timecontroller.event.LeavesTime;
import com.lineage.server.templates.L1Event;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class LeavesSet extends EventExecutor
{
    private static final Log _log;
    public static boolean START;
    public static int TIME;
    public static int EXP;
    public static int MAXEXP;
    
    static {
        _log = LogFactory.getLog((Class)LeavesSet.class);
        LeavesSet.START = false;
        LeavesSet.TIME = 0;
        LeavesSet.EXP = 0;
        LeavesSet.MAXEXP = 0;
    }
    
    public static EventExecutor get() {
        return new LeavesSet();
    }
    
    @Override
    public void execute(final L1Event event) {
        try {
            LeavesSet.START = true;
            final String[] set = event.get_eventother().split(",");
            try {
                LeavesSet.TIME = Integer.parseInt(set[0]);
            }
            catch (Exception e2) {
                LeavesSet.TIME = 15;
                LeavesSet._log.error((Object)"未設定時間(使用預設15分鐘)");
            }
            try {
                LeavesSet.EXP = Integer.parseInt(set[1]);
            }
            catch (Exception e2) {
                LeavesSet.EXP = 4000;
                LeavesSet._log.error((Object)"未設定增加的經驗質(使用預設4000)");
            }
            try {
                LeavesSet.MAXEXP = Integer.parseInt(set[2]);
            }
            catch (Exception e2) {
                LeavesSet.MAXEXP = LeavesSet.EXP * 250;
                LeavesSet._log.error((Object)"未設定允許最大的經驗質(使用預設EXP*250)");
            }
            final LeavesTime leavesTime = new LeavesTime();
            leavesTime.start();
        }
        catch (Exception e) {
            LeavesSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
