package com.lineage.data.event;

import com.lineage.server.datatables.lock.CharItemPowerReading;
import com.lineage.server.datatables.ItemPowerTable;
import com.lineage.server.templates.L1Event;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import com.lineage.data.executor.EventExecutor;

public class PowerItemSet extends EventExecutor
{
    private static final Log _log;
    public static boolean START;
    
    static {
        _log = LogFactory.getLog((Class)PowerItemSet.class);
        PowerItemSet.START = false;
    }
    
    public static EventExecutor get() {
        return new PowerItemSet();
    }
    
    @Override
    public void execute(final L1Event event) {
        try {
            PowerItemSet.START = true;
            ItemPowerTable.get().load();
            CharItemPowerReading.get().load();
        }
        catch (Exception e) {
            PowerItemSet._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
