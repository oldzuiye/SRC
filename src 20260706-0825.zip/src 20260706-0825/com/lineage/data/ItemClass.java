package com.lineage.data;

import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.model.Instance.L1PcInstance;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import com.lineage.data.executor.ItemExecutor;
import java.util.Map;
import org.apache.commons.logging.Log;

public class ItemClass
{
    private static final Log _log;
    private static final Map<Integer, ItemExecutor> _classList;
    private static ItemClass _instance;
    
    static {
        _log = LogFactory.getLog((Class)ItemClass.class);
        _classList = new HashMap<Integer, ItemExecutor>();
    }
    
    public static ItemClass get() {
        if (ItemClass._instance == null) {
            ItemClass._instance = new ItemClass();
        }
        return ItemClass._instance;
    }
    
    public void addList(final int itemid, final String className, final int mode) {
        if (className.equals("0")) {
            return;
        }
        try {
            String newclass = className;
            String[] set = null;
            if (className.indexOf(" ") != -1) {
                set = className.split(" ");
                newclass = set[0];
            }
            final StringBuilder stringBuilder = new StringBuilder();
            switch (mode) {
                case 0: {
                    stringBuilder.append("com.lineage.data.item_etcitem.");
                    break;
                }
                case 1: {
                    stringBuilder.append("com.lineage.data.item_weapon.");
                    break;
                }
                case 2: {
                    stringBuilder.append("com.lineage.data.item_armor.");
                    break;
                }
            }
            stringBuilder.append(newclass);
            final Class<?> cls = Class.forName(stringBuilder.toString());
            final ItemExecutor exe = (ItemExecutor)cls.getMethod("get", (Class<?>[])new Class[0]).invoke(null, new Object[0]);
            if (set != null) {
                exe.set_set(set);
            }
            ItemClass._classList.put(new Integer(itemid), exe);
        }
        catch (ClassNotFoundException e) {
            final String error = "發生[道具檔案]錯誤, 檢查檔案是否存在:" + className + " ItemId:" + itemid;
            ItemClass._log.error((Object)error);
            DataError.isError(ItemClass._log, error, e);
        }
        catch (IllegalArgumentException e2) {
            ItemClass._log.error((Object)e2.getLocalizedMessage(), (Throwable)e2);
        }
        catch (IllegalAccessException e3) {
            ItemClass._log.error((Object)e3.getLocalizedMessage(), (Throwable)e3);
        }
        catch (InvocationTargetException e4) {
            ItemClass._log.error((Object)e4.getLocalizedMessage(), (Throwable)e4);
        }
        catch (SecurityException e5) {
            ItemClass._log.error((Object)e5.getLocalizedMessage(), (Throwable)e5);
        }
        catch (NoSuchMethodException e6) {
            ItemClass._log.error((Object)e6.getLocalizedMessage(), (Throwable)e6);
        }
    }
    
    public void item(final int[] data, final L1PcInstance pc, final L1ItemInstance item) {
        if (pc == null) {
            return;
        }
        if (item == null) {
            return;
        }
        try {
            final ItemExecutor exe = ItemClass._classList.get(new Integer(item.getItemId()));
            if (exe != null) {
                exe.execute(data, pc, item);
            }
        }
        catch (Exception e) {
            ItemClass._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    public void item_weapon(final boolean equipped, final L1PcInstance pc, final L1ItemInstance item) {
        if (pc == null) {
            return;
        }
        if (item == null) {
            return;
        }
        try {
            final ItemExecutor exe = ItemClass._classList.get(new Integer(item.getItemId()));
            if (exe != null) {
                final int[] data = { equipped };
                exe.execute(data, pc, item);
            }
        }
        catch (Exception e) {
            ItemClass._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
    
    public void item_armor(final boolean equipped, final L1PcInstance pc, final L1ItemInstance item) {
        if (pc == null) {
            return;
        }
        if (item == null) {
            return;
        }
        try {
            final ItemExecutor exe = ItemClass._classList.get(new Integer(item.getItemId()));
            if (exe != null) {
                final int[] data = { equipped };
                exe.execute(data, pc, item);
            }
        }
        catch (Exception e) {
            ItemClass._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
        }
    }
}
