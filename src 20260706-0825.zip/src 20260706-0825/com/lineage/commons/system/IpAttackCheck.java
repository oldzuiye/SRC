package com.lineage.commons.system;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lineage.config.ConfigIpCheck;
import com.lineage.echo.ClientExecutor;
import com.lineage.server.datatables.lock.IpReading;

public class IpAttackCheck {

    private static final Log _log = LogFactory.getLog(IpAttackCheck.class);

    public static final Map<ClientExecutor, String> SOCKETLIST = new ConcurrentHashMap<ClientExecutor, String>();
    private static final HashMap<String, IpTemp> _ipList = new HashMap<String, IpTemp>();

    private static IpAttackCheck _instance;

    public static IpAttackCheck get() {
        if (_instance == null) {
            _instance = new IpAttackCheck();
        }
        return _instance;
    }

    private IpAttackCheck() {
        _ipList.clear();
    }

    public synchronized boolean check(final String key) {
        try {
            final long nowtime = System.currentTimeMillis();
            IpTemp value = _ipList.get(key);

            if (value == null) {
                value = new IpTemp();
                value._time = nowtime;
                value._count = 1;
                _ipList.put(key, value);
            } else if (nowtime - value._time <= ConfigIpCheck.TIMEMILLIS) {
                value._count++;
                if (value._count >= ConfigIpCheck.COUNT) {
                    this.kick(key);
                    if (ConfigIpCheck.SETDB) {
                        IpReading.get().add(key, "IP類似攻擊行為");
                        System.out.println("IP類似攻擊行為: " + key);
                    }
                    return false;
                }
            } else {
                value._time = nowtime;
                value._count = 1;
            }

        } catch (Exception e) {
            _log.error(e.getLocalizedMessage(), e);
        }
        return true;
    }

    private void kick(final String key) {
        try {
            for (final Map.Entry<ClientExecutor, String> entry : SOCKETLIST.entrySet()) {
                final ClientExecutor socket = entry.getKey();
                final String ip = entry.getValue();
                if (ip != null && ip.equals(key) && socket != null) {
                    socket.close();
                }
            }
        } catch (Exception e) {
            _log.error(e.getLocalizedMessage(), e);
        }
    }

    private static class IpTemp {
        long _time;
        int _count;
    }
}