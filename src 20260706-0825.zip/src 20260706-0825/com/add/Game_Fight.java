package com.add;

import com.lineage.server.model.Instance.L1DoorInstance;
import com.lineage.server.datatables.DoorSpawnTable;
import com.lineage.server.serverpackets.S_BlueMessage;
import com.lineage.server.model.L1Inventory;
import com.lineage.server.world.World;
import java.util.Iterator;
import com.lineage.server.templates.L1Item;
import com.lineage.server.model.L1Teleport;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.thread.GeneralThreadPool;
import com.lineage.server.utils.collections.Lists;
import com.lineage.server.model.Instance.L1PcInstance;
import java.util.List;

public class Game_Fight
{
    private List<L1PcInstance> playerListA;
    private List<L1PcInstance> playerListB;
    private List<L1PcInstance> playerListC;
    private List<L1PcInstance> playerListD;
    private static Game_Fight _instance;
    public static final int STATUS_NONE = 0;
    public static final int STATUS_READY = 1;
    public static final int STATUS_PLAYING = 2;
    public static final int STATUS_CLEANING = 4;
    private int _FightStatus;
    
    public Game_Fight() {
        this.playerListA = Lists.<L1PcInstance>newList();
        this.playerListB = Lists.<L1PcInstance>newList();
        this.playerListC = Lists.<L1PcInstance>newList();
        this.playerListD = Lists.<L1PcInstance>newList();
        this._FightStatus = 0;
    }
    
    public static Game_Fight getInstance() {
        if (Game_Fight._instance == null) {
            Game_Fight._instance = new Game_Fight();
        }
        return Game_Fight._instance;
    }
    
    public void addPlayerList(final L1PcInstance pc) {
        if (!this.playerListA.contains(pc)) {
            this.playerListA.add(pc);
        }
        if (!this.playerListB.contains(pc)) {
            this.playerListB.add(pc);
        }
    }
    
    public void addPlayerListA(final L1PcInstance pc) {
        if (!this.playerListA.contains(pc)) {
            this.playerListA.add(pc);
            pc.getInventory().consumeItem(L1Config._2038, L1Config._2039);
            this.sendMessage("藍隊人數 " + this.playerListA.size() + " 人，紅隊人數 " + this.playerListB.size() + " 人");
        }
        if (this.getMembersCountA() == 1 && this.getFightStatus() == 0) {
            GeneralThreadPool.get().execute(new runFight((runFight)null));
        }
    }
    
    public void addPlayerListB(final L1PcInstance pc) {
        if (!this.playerListB.contains(pc)) {
            this.playerListB.add(pc);
            this.sendMessage("藍隊人數 " + this.playerListA.size() + " 人，紅隊人數 " + this.playerListB.size() + " 人");
            pc.getInventory().consumeItem(L1Config._2038, L1Config._2039);
        }
        if (this.getMembersCountB() == 1 && this.getFightStatus() == 0) {
            GeneralThreadPool.get().execute(new runFight((runFight)null));
        }
    }
    
    public void addPlayerListC(final L1PcInstance pc) {
        if (!this.playerListC.contains(pc)) {
            this.playerListC.add(pc);
        }
    }
    
    public void addPlayerListD(final L1PcInstance pc) {
        if (!this.playerListD.contains(pc)) {
            this.playerListD.add(pc);
        }
    }
    
    public void removePlayerList(final L1PcInstance pc) {
        if (this.playerListA.contains(pc)) {
            this.playerListA.remove(pc);
            pc.setATeam(false);
        }
        if (this.playerListB.contains(pc)) {
            this.playerListB.remove(pc);
            pc.setBTeam(false);
        }
    }
    
    public String enterA(final L1PcInstance pc) {
        if (pc.getLevel() <= L1Config._2031) {
            pc.sendPackets(new S_SystemMessage("等級必須" + L1Config._2031 + "級以上，才可參加隊伍對決。"));
            return "";
        }
        if (getInstance().getFightStatus() == 4) {
            pc.sendPackets(new S_SystemMessage("目前隊伍對決場地正在清潔中，請稍候。"));
            return "";
        }
        if (getInstance().getFightStatus() == 2) {
            pc.sendPackets(new S_SystemMessage("目前隊伍對決已經開始，請等待下一場。"));
            return "";
        }
        if (this.playerListA.size() >= L1Config._2034) {
            pc.sendPackets(new S_SystemMessage("隊伍對決藍隊人數已經額滿，請等待下一場。"));
            return "";
        }
        if (!pc.getInventory().checkItem(L1Config._2038, L1Config._2039)) {
            pc.sendPackets(new S_ServerMessage(189));
            return "";
        }
        if (!this.playerListB.contains(pc)) {
            this.addPlayerListA(pc);
            pc.setATeam(true);
            final L1Item item = ItemTable.get().getTemplate(L1Config._2038);
            pc.sendPackets(new S_SystemMessage("參加隊伍對決藍隊扣除報名費:" + item.getName() + "(" + L1Config._2039 + ")。"));
            final L1Item prize = ItemTable.get().getTemplate(L1Config._2040);
            pc.sendPackets(new S_SystemMessage("隊伍對決優勝可獲得:" + prize.getName() + "(" + L1Config._2041 + ")。"));
            L1Teleport.teleport(pc, 32867, 32598, (short)515, pc.getHeading(), true);
        }
        return "";
    }
    
    public String enterB(final L1PcInstance pc) {
        if (pc.getLevel() <= L1Config._2031) {
            pc.sendPackets(new S_SystemMessage("等級必須52級以上，才可參加隊伍對決。"));
            return "";
        }
        if (getInstance().getFightStatus() == 4) {
            pc.sendPackets(new S_SystemMessage("目前隊伍對決場地正在清潔中，請稍候。"));
            return "";
        }
        if (getInstance().getFightStatus() == 2) {
            pc.sendPackets(new S_SystemMessage("目前隊伍對決已經開始，請等待下一場。"));
            return "";
        }
        if (this.playerListB.size() >= L1Config._2034) {
            pc.sendPackets(new S_SystemMessage("隊伍對決紅隊人數已經額滿，請等待下一場。"));
            return "";
        }
        if (!pc.getInventory().checkItem(L1Config._2038, L1Config._2039)) {
            pc.sendPackets(new S_ServerMessage(189));
            return "";
        }
        if (!this.playerListA.contains(pc)) {
            this.addPlayerListB(pc);
            pc.setBTeam(true);
            final L1Item item = ItemTable.get().getTemplate(L1Config._2038);
            pc.sendPackets(new S_SystemMessage("參加隊伍對決紅隊扣除報名費:" + item.getName() + "(" + L1Config._2039 + ")。"));
            final L1Item prize = ItemTable.get().getTemplate(L1Config._2040);
            pc.sendPackets(new S_SystemMessage("隊伍對決優勝可獲得:" + prize.getName() + "(" + L1Config._2041 + ")。"));
            L1Teleport.teleport(pc, 32862, 32679, (short)515, pc.getHeading(), true);
        }
        return "";
    }
    
    public String LookATeam(final L1PcInstance pc) {
        for (final L1PcInstance tg : this.playerListA) {
            final String name = String.valueOf(tg.getName());
            final String level = String.valueOf(tg.getLevel());
            pc.sendPackets(new S_SystemMessage("【藍隊玩家】: " + name + " 【等級】: " + level));
        }
        return "";
    }
    
    public String LookBTeam(final L1PcInstance pc) {
        for (final L1PcInstance tg : this.playerListB) {
            final String name = String.valueOf(tg.getName());
            final String level = String.valueOf(tg.getLevel());
            pc.sendPackets(new S_SystemMessage("【紅隊玩家】: " + name + " 【等級】: " + level));
        }
        return "";
    }
    
    private boolean checkPlayerCount() {
        if (this.getMembersCountA() != this.getMembersCountB()) {
            this.setFightStatus(4);
            this.sendMessage("因兩方隊伍人數不相等，為公平起見，隊伍對決強制結束");
            for (final L1PcInstance pc : this.playerListA) {
                pc.setATeam(false);
                pc.getInventory().storeItem(L1Config._2038, L1Config._2039);
                final L1Item item = ItemTable.get().getTemplate(L1Config._2038);
                pc.sendPackets(new S_SystemMessage("隊伍對決退還報名費:" + item.getName() + "(" + L1Config._2039 + ")。"));
                L1Teleport.teleport(pc, 33442, 32797, (short)4, pc.getHeading(), true);
            }
            for (final L1PcInstance pc : this.playerListB) {
                pc.setBTeam(false);
                pc.getInventory().storeItem(L1Config._2038, L1Config._2039);
                final L1Item item = ItemTable.get().getTemplate(L1Config._2038);
                pc.sendPackets(new S_SystemMessage("隊伍對決退還報名費:" + item.getName() + "(" + L1Config._2039 + ")。"));
                L1Teleport.teleport(pc, 33442, 32797, (short)4, pc.getHeading(), true);
            }
            this.clearMembers();
            return false;
        }
        if (this.getMembersCountA() < L1Config._2033 || this.getMembersCountB() < L1Config._2033) {
            this.setFightStatus(4);
            this.sendMessage("因一方隊伍人數不達最低限制，隊伍對決強制結束");
            for (final L1PcInstance pc : this.playerListA) {
                pc.setATeam(false);
                pc.getInventory().storeItem(L1Config._2038, L1Config._2039);
                final L1Item item = ItemTable.get().getTemplate(L1Config._2038);
                pc.sendPackets(new S_SystemMessage("隊伍對決退還報名費:" + item.getName() + "(" + L1Config._2039 + ")。"));
                L1Teleport.teleport(pc, 33442, 32797, (short)4, pc.getHeading(), true);
            }
            for (final L1PcInstance pc : this.playerListB) {
                pc.setBTeam(false);
                pc.getInventory().storeItem(L1Config._2038, L1Config._2039);
                final L1Item item = ItemTable.get().getTemplate(L1Config._2038);
                pc.sendPackets(new S_SystemMessage("隊伍對決退還報名費:" + item.getName() + "(" + L1Config._2039 + ")。"));
                L1Teleport.teleport(pc, 33442, 32797, (short)4, pc.getHeading(), true);
            }
            this.clearMembers();
            return false;
        }
        return true;
    }
    
    private void WinTeam() {
        for (final L1PcInstance pc : this.playerListA) {
            if (pc != null && !pc.isDead() && !pc.isGhost() && pc.getMapId() == 515) {
                this.addPlayerListC(pc);
            }
        }
        for (final L1PcInstance pc : this.playerListB) {
            if (pc != null && !pc.isDead() && !pc.isGhost() && pc.getMapId() == 515) {
                this.addPlayerListD(pc);
            }
        }
        if (this.playerListC.size() == this.playerListD.size()) {
            this.sendMessage("雙方平手");
            for (final L1PcInstance pc : this.playerListA) {
                final L1Item prize = ItemTable.get().getTemplate(L1Config._2040);
                pc.sendPackets(new S_SystemMessage("雙方平手，無人獲得" + prize.getName() + "(" + L1Config._2041 + ")。"));
            }
        }
        else if (this.playerListC.size() > this.playerListD.size()) {
            for (final L1PcInstance pc : this.playerListA) {
                final L1Item prize = ItemTable.get().getTemplate(L1Config._2040);
                this.sendMessage("恭喜【藍隊】獲得隊伍對決優勝，獲得:" + prize.getName() + "(" + L1Config._2041 + ")");
                pc.sendPackets(new S_SystemMessage("恭喜【藍隊】獲得隊伍對決優勝，獲得:" + prize.getName() + "(" + L1Config._2041 + ")。"));
                pc.getInventory().storeItem(L1Config._2040, L1Config._2041);
            }
        }
        else if (this.playerListD.size() > this.playerListC.size()) {
            for (final L1PcInstance pc : this.playerListB) {
                final L1Item prize = ItemTable.get().getTemplate(L1Config._2040);
                this.sendMessage("恭喜【紅隊】獲得隊伍對決優勝，獲得:" + prize.getName() + "(" + L1Config._2041 + ")");
                pc.sendPackets(new S_SystemMessage("恭喜【紅隊】獲得隊伍對決優勝，獲得:" + prize.getName() + "(" + L1Config._2041 + ")。"));
                pc.getInventory().storeItem(L1Config._2040, L1Config._2041);
            }
        }
    }
    
    private void endFight() {
        this.setFightStatus(4);
        this.sendMessage("隊伍對決結束， 下一場將在" + L1Config._2037 / 60 / 1000 + "分鐘後開始");
        for (final L1PcInstance pc : this.playerListA) {
            pc.setATeam(false);
            L1Teleport.teleport(pc, 33442, 32797, (short)4, pc.getHeading(), true);
        }
        for (final L1PcInstance pc : this.playerListB) {
            pc.setBTeam(false);
            L1Teleport.teleport(pc, 33442, 32797, (short)4, pc.getHeading(), true);
        }
        this.clearMembers();
        this.clearColosseum();
    }
    
    private void clearColosseum() {
        for (final Object obj : World.get().getVisibleObjects(515).values()) {
            if (obj instanceof L1Inventory) {
                final L1Inventory inventory = (L1Inventory)obj;
                inventory.clearItems();
            }
        }
    }
    
    private void sendMessage(final String msg) {
        for (final L1PcInstance pc : this.playerListA) {
            if (pc.getMapId() == 515) {
                pc.sendPackets(new S_BlueMessage(166, "\\f3" + msg));
            }
        }
        for (final L1PcInstance pc : this.playerListB) {
            if (pc.getMapId() == 515) {
                pc.sendPackets(new S_BlueMessage(166, "\\f3" + msg));
            }
        }
    }
    
    public void checkFightGame(final L1PcInstance pc) {
        if (pc.getMapId() == 515) {
            this.removePlayerList(pc);
        }
    }
    
    private void setDoorClose(final boolean isClose) {
        final L1DoorInstance[] list = DoorSpawnTable.get().getDoorList();
        L1DoorInstance[] array;
        for (int length = (array = list).length, i = 0; i < length; ++i) {
            final L1DoorInstance door = array[i];
            if (door.getMapId() == 515) {
                if (isClose) {
                    door.close();
                }
                else {
                    door.open();
                }
            }
        }
    }
    
    private void setFightStatus(final int i) {
        this._FightStatus = i;
    }
    
    private int getFightStatus() {
        return this._FightStatus;
    }
    
    private void clearMembers() {
        this.playerListA.clear();
        this.playerListB.clear();
        this.playerListC.clear();
        this.playerListD.clear();
        this.setDoorClose(true);
    }
    
    private int getMembersCountA() {
        return this.playerListA.size();
    }
    
    private int getMembersCountB() {
        return this.playerListB.size();
    }
    
    private class runFight implements Runnable
    {
        @Override
        public void run() {
            try {
                Game_Fight.this.setFightStatus(1);
                Thread.sleep(L1Config._2035);
                Game_Fight.this.sendMessage("隊伍對決即將在10秒後開始，目前參加人數 藍隊: " + Game_Fight.this.playerListA.size() + "人 紅隊: " + Game_Fight.this.playerListB.size() + "人");
                Thread.sleep(5000L);
                Game_Fight.this.sendMessage("隊伍對決即將在5秒後開始，目前參加人數 藍隊: " + Game_Fight.this.playerListA.size() + "人 紅隊: " + Game_Fight.this.playerListB.size() + "人");
                Thread.sleep(1000L);
                Game_Fight.this.sendMessage("隊伍對決即將在4秒後開始，目前參加人數 藍隊: " + Game_Fight.this.playerListA.size() + "人 紅隊: " + Game_Fight.this.playerListB.size() + "人");
                Thread.sleep(1000L);
                Game_Fight.this.sendMessage("隊伍對決即將在3秒後開始，目前參加人數 藍隊: " + Game_Fight.this.playerListA.size() + "人 紅隊: " + Game_Fight.this.playerListB.size() + "人");
                Thread.sleep(1000L);
                Game_Fight.this.sendMessage("隊伍對決即將在2秒後開始，目前參加人數 藍隊: " + Game_Fight.this.playerListA.size() + "人 紅隊: " + Game_Fight.this.playerListB.size() + "人");
                Thread.sleep(1000L);
                Game_Fight.this.sendMessage("隊伍對決即將在1秒後開始，目前參加人數 藍隊: " + Game_Fight.this.playerListA.size() + "人 紅隊: " + Game_Fight.this.playerListB.size() + "人");
                Thread.sleep(1000L);
                Game_Fight.this.setDoorClose(false);
                if (Game_Fight.this.checkPlayerCount()) {
                    Game_Fight.this.setFightStatus(2);
                    Game_Fight.this.sendMessage("隊伍對決開始，請在" + L1Config._2036 / 1000 / 60 + "分鐘內將對手打敗");
                    Thread.sleep(L1Config._2036 / 3);
                    Game_Fight.this.sendMessage("隊伍對決將在" + L1Config._2036 / 3 * 2 / 1000 / 60 + "分鐘後結束");
                    Thread.sleep(L1Config._2036 / 3);
                    Game_Fight.this.sendMessage("隊伍對決將在" + L1Config._2036 / 3 / 1000 / 60 + "分鐘後結束");
                    Thread.sleep(L1Config._2036 / 3);
                    Game_Fight.this.sendMessage("隊伍對決即將結束與公佈優勝隊伍");
                    Thread.sleep(5000L);
                    Game_Fight.this.WinTeam();
                    Thread.sleep(5000L);
                    Game_Fight.this.sendMessage("隊伍對決將在10秒後關閉");
                    Thread.sleep(5000L);
                    Game_Fight.this.sendMessage("隊伍對決將在5秒後關閉");
                    Thread.sleep(1000L);
                    Game_Fight.this.sendMessage("隊伍對決將在4秒後關閉");
                    Thread.sleep(1000L);
                    Game_Fight.this.sendMessage("隊伍對決將在3秒後關閉");
                    Thread.sleep(1000L);
                    Game_Fight.this.sendMessage("隊伍對決將在2秒後關閉");
                    Thread.sleep(1000L);
                    Game_Fight.this.sendMessage("隊伍對決將在1秒後關閉");
                    Thread.sleep(1000L);
                    Game_Fight.this.endFight();
                }
                Thread.sleep(L1Config._2037);
                Game_Fight.this.setFightStatus(0);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
