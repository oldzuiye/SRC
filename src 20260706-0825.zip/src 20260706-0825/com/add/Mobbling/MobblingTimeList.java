package com.add.Mobbling;

import com.add.L1Config;
import com.lineage.server.model.Instance.L1NpcInstance;

public class MobblingTimeList
{
    private L1NpcInstance _npcMob1;
    private L1NpcInstance _npcMob2;
    private L1NpcInstance _npcMob3;
    private L1NpcInstance _npcMob4;
    private L1NpcInstance _npcMob5;
    private L1NpcInstance _npcMob6;
    private L1NpcInstance _npcMob7;
    private L1NpcInstance _npcMob8;
    private L1NpcInstance _npcMob9;
    private L1NpcInstance _npcMob10;
    private int _npcChip1A;
    private int _npcChip2A;
    private int _npcChip3A;
    private int _npcChip4A;
    private int _npcChip5A;
    private int _npcChip6A;
    private int _npcChip7A;
    private int _npcChip8A;
    private int _npcChip9A;
    private int _npcChip10A;
    private double _npcRate1A;
    private double _npcRate2A;
    private double _npcRate3A;
    private double _npcRate4A;
    private double _npcRate5A;
    private double _npcRate6A;
    private double _npcRate7A;
    private double _npcRate8A;
    private double _npcRate9A;
    private double _npcRate10A;
    boolean _isStart;
    boolean _isWaiting;
    boolean _isBuy;
    private int _MobId;
    private static MobblingTimeList _instance;
    
    public MobblingTimeList() {
        this._npcMob1 = null;
        this._npcMob2 = null;
        this._npcMob3 = null;
        this._npcMob4 = null;
        this._npcMob5 = null;
        this._npcMob6 = null;
        this._npcMob7 = null;
        this._npcMob8 = null;
        this._npcMob9 = null;
        this._npcMob10 = null;
        this._npcChip1A = 0;
        this._npcChip2A = 0;
        this._npcChip3A = 0;
        this._npcChip4A = 0;
        this._npcChip5A = 0;
        this._npcChip6A = 0;
        this._npcChip7A = 0;
        this._npcChip8A = 0;
        this._npcChip9A = 0;
        this._npcChip10A = 0;
        this._npcRate1A = 2.0;
        this._npcRate2A = 2.0;
        this._npcRate3A = 2.0;
        this._npcRate4A = 2.0;
        this._npcRate5A = 2.0;
        this._npcRate6A = 2.0;
        this._npcRate7A = 2.0;
        this._npcRate8A = 2.0;
        this._npcRate9A = 2.0;
        this._npcRate10A = 2.0;
        this._isStart = false;
        this._isWaiting = false;
        this._isBuy = false;
        this._MobId = 0;
    }
    
    public static MobblingTimeList Mob() {
        if (MobblingTimeList._instance == null) {
            MobblingTimeList._instance = new MobblingTimeList();
        }
        return MobblingTimeList._instance;
    }
    
    public void clear() {
        try {
            this._npcMob1.deleteMe();
            this._npcMob2.deleteMe();
            this._npcMob3.deleteMe();
            this._npcMob4.deleteMe();
            this._npcMob5.deleteMe();
            this._npcMob6.deleteMe();
            this._npcMob7.deleteMe();
            this._npcMob8.deleteMe();
            this._npcMob9.deleteMe();
            this._npcMob10.deleteMe();
            this._npcMob1 = null;
            this._npcMob2 = null;
            this._npcMob3 = null;
            this._npcMob4 = null;
            this._npcMob5 = null;
            this._npcMob6 = null;
            this._npcMob7 = null;
            this._npcMob8 = null;
            this._npcMob9 = null;
            this._npcMob10 = null;
            this._npcChip1A = 0;
            this._npcChip2A = 0;
            this._npcChip3A = 0;
            this._npcChip4A = 0;
            this._npcChip5A = 0;
            this._npcChip6A = 0;
            this._npcChip7A = 0;
            this._npcChip8A = 0;
            this._npcChip9A = 0;
            this._npcChip10A = 0;
            this._npcRate1A = 2.0;
            this._npcRate2A = 2.0;
            this._npcRate3A = 2.0;
            this._npcRate4A = 2.0;
            this._npcRate5A = 2.0;
            this._npcRate6A = 2.0;
            this._npcRate7A = 2.0;
            this._npcRate8A = 2.0;
            this._npcRate9A = 2.0;
            this._npcRate10A = 2.0;
            this._isStart = false;
            this._isBuy = false;
            this._isWaiting = false;
            this._MobId = 0;
        }
        catch (Exception e) {
            e.getLocalizedMessage();
        }
    }
    
    public boolean get_isStart() {
        return this._isStart;
    }
    
    public void set_isStart(final boolean b) {
        this._isStart = b;
    }
    
    public boolean get_isBuy() {
        return this._isBuy;
    }
    
    public void set_isBuy(final boolean b) {
        this._isBuy = b;
    }
    
    public boolean get_isWaiting() {
        return this._isWaiting;
    }
    
    public void set_isWaiting(final boolean b) {
        this._isWaiting = b;
    }
    
    public int get_MobId() {
        return this._MobId;
    }
    
    public void set_MobId(final int i) {
        this._MobId = i;
    }
    
    public L1NpcInstance get_npcMob1() {
        return this._npcMob1;
    }
    
    public void set_npcMob1(final L1NpcInstance npc) {
        this._npcMob1 = npc;
    }
    
    public L1NpcInstance get_npcMob2() {
        return this._npcMob2;
    }
    
    public void set_npcMob2(final L1NpcInstance npc) {
        this._npcMob2 = npc;
    }
    
    public L1NpcInstance get_npcMob3() {
        return this._npcMob3;
    }
    
    public void set_npcMob3(final L1NpcInstance npc) {
        this._npcMob3 = npc;
    }
    
    public L1NpcInstance get_npcMob4() {
        return this._npcMob4;
    }
    
    public void set_npcMob4(final L1NpcInstance npc) {
        this._npcMob4 = npc;
    }
    
    public L1NpcInstance get_npcMob5() {
        return this._npcMob5;
    }
    
    public void set_npcMob5(final L1NpcInstance npc) {
        this._npcMob5 = npc;
    }
    
    public L1NpcInstance get_npcMob6() {
        return this._npcMob6;
    }
    
    public void set_npcMob6(final L1NpcInstance npc) {
        this._npcMob6 = npc;
    }
    
    public L1NpcInstance get_npcMob7() {
        return this._npcMob7;
    }
    
    public void set_npcMob7(final L1NpcInstance npc) {
        this._npcMob7 = npc;
    }
    
    public L1NpcInstance get_npcMob8() {
        return this._npcMob8;
    }
    
    public void set_npcMob8(final L1NpcInstance npc) {
        this._npcMob8 = npc;
    }
    
    public L1NpcInstance get_npcMob9() {
        return this._npcMob9;
    }
    
    public void set_npcMob9(final L1NpcInstance npc) {
        this._npcMob9 = npc;
    }
    
    public L1NpcInstance get_npcMob10() {
        return this._npcMob10;
    }
    
    public void set_npcMob10(final L1NpcInstance npc) {
        this._npcMob10 = npc;
    }
    
    public int get_npcChip1A() {
        return this._npcChip1A;
    }
    
    public void add_npcChip1A(final int i) {
        this._npcChip1A += i;
    }
    
    public int get_npcChip2A() {
        return this._npcChip2A;
    }
    
    public void add_npcChip2A(final int i) {
        this._npcChip2A += i;
    }
    
    public int get_npcChip3A() {
        return this._npcChip3A;
    }
    
    public void add_npcChip3A(final int i) {
        this._npcChip3A += i;
    }
    
    public int get_npcChip4A() {
        return this._npcChip4A;
    }
    
    public void add_npcChip4A(final int i) {
        this._npcChip4A += i;
    }
    
    public int get_npcChip5A() {
        return this._npcChip5A;
    }
    
    public void add_npcChip5A(final int i) {
        this._npcChip5A += i;
    }
    
    public int get_npcChip6A() {
        return this._npcChip6A;
    }
    
    public void add_npcChip6A(final int i) {
        this._npcChip6A += i;
    }
    
    public int get_npcChip7A() {
        return this._npcChip7A;
    }
    
    public void add_npcChip7A(final int i) {
        this._npcChip7A += i;
    }
    
    public int get_npcChip8A() {
        return this._npcChip8A;
    }
    
    public void add_npcChip8A(final int i) {
        this._npcChip8A += i;
    }
    
    public int get_npcChip9A() {
        return this._npcChip9A;
    }
    
    public void add_npcChip9A(final int i) {
        this._npcChip9A += i;
    }
    
    public int get_npcChip10A() {
        return this._npcChip10A;
    }
    
    public void add_npcChip10A(final int i) {
        this._npcChip10A += i;
    }
    
    public double get_npcRate1A() {
        return this._npcRate1A;
    }
    
    public double get_npcRate2A() {
        return this._npcRate2A;
    }
    
    public double get_npcRate3A() {
        return this._npcRate3A;
    }
    
    public double get_npcRate4A() {
        return this._npcRate4A;
    }
    
    public double get_npcRate5A() {
        return this._npcRate5A;
    }
    
    public double get_npcRate6A() {
        return this._npcRate6A;
    }
    
    public double get_npcRate7A() {
        return this._npcRate7A;
    }
    
    public double get_npcRate8A() {
        return this._npcRate8A;
    }
    
    public double get_npcRate9A() {
        return this._npcRate9A;
    }
    
    public double get_npcRate10A() {
        return this._npcRate10A;
    }
    
    public void computationRate() {
        final int totalprice = this.get_npcChip1A() + this.get_npcChip2A() + this.get_npcChip3A() + this.get_npcChip4A() + this.get_npcChip5A() + this.get_npcChip6A() + this.get_npcChip7A() + this.get_npcChip8A() + this.get_npcChip9A() + this.get_npcChip10A();
        final int commission = L1Config._2152 / 100;
        final int aftertp = totalprice * (1 - commission);
        if (aftertp != 0 && this.get_npcChip1A() != 0) {
            this._npcRate1A = aftertp / this.get_npcChip1A();
            if (this._npcRate1A > 100.0) {
                this._npcRate1A = 100.0;
            }
            if (this._npcRate1A < 2.0) {
                this._npcRate1A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip2A() != 0) {
            this._npcRate2A = aftertp / this.get_npcChip2A();
            if (this._npcRate2A > 100.0) {
                this._npcRate2A = 100.0;
            }
            if (this._npcRate2A < 2.0) {
                this._npcRate2A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip3A() != 0) {
            this._npcRate3A = aftertp / this.get_npcChip3A();
            if (this._npcRate3A > 100.0) {
                this._npcRate3A = 100.0;
            }
            if (this._npcRate3A < 2.0) {
                this._npcRate3A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip4A() != 0) {
            this._npcRate4A = aftertp / this.get_npcChip4A();
            if (this._npcRate4A > 100.0) {
                this._npcRate4A = 100.0;
            }
            if (this._npcRate4A < 2.0) {
                this._npcRate4A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip5A() != 0) {
            this._npcRate5A = aftertp / this.get_npcChip5A();
            if (this._npcRate5A > 100.0) {
                this._npcRate5A = 100.0;
            }
            if (this._npcRate5A < 2.0) {
                this._npcRate5A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip6A() != 0) {
            this._npcRate6A = aftertp / this.get_npcChip6A();
            if (this._npcRate6A > 100.0) {
                this._npcRate6A = 100.0;
            }
            if (this._npcRate6A < 2.0) {
                this._npcRate6A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip7A() != 0) {
            this._npcRate7A = aftertp / this.get_npcChip7A();
            if (this._npcRate7A > 100.0) {
                this._npcRate7A = 100.0;
            }
            if (this._npcRate7A < 2.0) {
                this._npcRate7A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip8A() != 0) {
            this._npcRate8A = aftertp / this.get_npcChip8A();
            if (this._npcRate8A > 100.0) {
                this._npcRate8A = 100.0;
            }
            if (this._npcRate8A < 2.0) {
                this._npcRate8A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip9A() != 0) {
            this._npcRate9A = aftertp / this.get_npcChip9A();
            if (this._npcRate9A > 100.0) {
                this._npcRate9A = 100.0;
            }
            if (this._npcRate9A < 2.0) {
                this._npcRate9A = 2.0;
            }
        }
        if (aftertp != 0 && this.get_npcChip10A() != 0) {
            this._npcRate10A = aftertp / this.get_npcChip10A();
            if (this._npcRate10A > 100.0) {
                this._npcRate10A = 100.0;
            }
            if (this._npcRate10A < 2.0) {
                this._npcRate10A = 2.0;
            }
        }
    }
}
