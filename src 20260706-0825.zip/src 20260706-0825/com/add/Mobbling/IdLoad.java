package com.add.Mobbling;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.Statement;
import com.lineage.server.utils.SQLUtil;
import com.lineage.DatabaseFactory;
import com.lineage.server.IdFactory;

public class IdLoad
{
    private static IdLoad _instance;
    private final IdFactory _loadId;
    
    public static IdLoad getInstance() {
        if (IdLoad._instance == null) {
            IdLoad._instance = new IdLoad();
        }
        return IdLoad._instance;
    }
    
    private IdLoad() {
        this._loadId = IdFactory.getId();
        this.loadState();
    }
    
    private void loadState() {
        this.loadMobChid();
        this.loadBigHotChid();
    }
    
    private void loadMobChid() {
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cn = DatabaseFactory.get().getConnection();
            ps = cn.prepareStatement("SELECT * FROM `race_mobbling`");
            rs = ps.executeQuery();
            while (rs.next()) {
                final int i = rs.getInt("id");
                this._loadId.addMobId(i);
            }
            ps.execute();
        }
        catch (Exception e) {
            e.printStackTrace();
            return;
        }
        finally {
            SQLUtil.close(ps);
            SQLUtil.close(cn);
        }
        SQLUtil.close(ps);
        SQLUtil.close(cn);
    }
    
    private void loadBigHotChid() {
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cn = DatabaseFactory.get().getConnection();
            ps = cn.prepareStatement("SELECT * FROM `race_bighotbling`");
            rs = ps.executeQuery();
            while (rs.next()) {
                final int i = rs.getInt("id");
                this._loadId.addBigHotId(i);
            }
            ps.execute();
        }
        catch (Exception e) {
            e.printStackTrace();
            return;
        }
        finally {
            SQLUtil.close(ps);
            SQLUtil.close(cn);
        }
        SQLUtil.close(ps);
        SQLUtil.close(cn);
    }
}
