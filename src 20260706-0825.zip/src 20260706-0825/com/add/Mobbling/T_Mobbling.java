package com.add.Mobbling;

import com.lineage.server.model.TimeInform;
import com.lineage.server.thread.GeneralThreadPool;
import java.util.Timer;
import java.util.TimerTask;

public class T_Mobbling extends TimerTask
{
    private static T_Mobbling _instance;
    private Timer _timeHandler;
    private boolean _isStart;
    
    public static T_Mobbling getStart() {
        if (T_Mobbling._instance == null) {
            T_Mobbling._instance = new T_Mobbling();
        }
        return T_Mobbling._instance;
    }
    
    private T_Mobbling() {
        this._timeHandler = new Timer(true);
        this._isStart = false;
        this._timeHandler.schedule(this, 5000L, 10000L);
        GeneralThreadPool.get().execute(this);
    }
    
    @Override
    public void run() {
        final String mTime = TimeInform.time().getNow_YMDHMS(3);
        final int mm = Integer.parseInt(mTime);
        switch (mm) {
            case 1:
            case 11:
            case 21:
            case 31:
            case 41:
            case 51: {
                if (this._isStart) {
                    return;
                }
                final MobblingTime Mob = new MobblingTime();
                Mob.startMobbling();
                this._isStart = true;
                break;
            }
            case 0:
            case 10:
            case 20:
            case 30:
            case 40:
            case 50: {
                if (!this._isStart) {
                    return;
                }
                this._isStart = false;
                final MobblingTime Mob2 = new MobblingTime();
                Mob2.clear();
                Mob2.setMobbling(false);
                break;
            }
        }
    }
    
    public void startT_Mobbling() {
        getStart();
    }
}
