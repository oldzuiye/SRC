package com.add.Mobbling;

import java.util.concurrent.locks.ReentrantLock;

public class MobblingLock
{
    private static MobblingLock _instance;
    private final MobblingStorage _MobSt;
    private final ReentrantLock _lock;
    
    public static MobblingLock create() {
        if (MobblingLock._instance == null) {
            MobblingLock._instance = new MobblingLock();
        }
        return MobblingLock._instance;
    }
    
    public MobblingLock() {
        this._MobSt = new MySqlMobblingStorage();
        this._lock = new ReentrantLock(true);
    }
    
    public void load() {
        this._MobSt.load();
    }
    
    public void create(final int id, final int npcid, final double rate, final int totalPrice) {
        this._lock.lock();
        try {
            this._MobSt.create(id, npcid, rate, totalPrice);
        }
        finally {
            this._lock.unlock();
        }
        this._lock.unlock();
    }
    
    public L1Mobbling[] getMobblingList() {
        return this._MobSt.getMobblingList();
    }
    
    public L1Mobbling getMobbling(final int id) {
        return this._MobSt.getMobbling(id);
    }
}
