package com.add.Mobbling;

import java.util.Iterator;
import com.lineage.server.model.L1Object;
import com.add.L1Config;
import com.lineage.server.model.Instance.L1NpcInstance;
import com.lineage.server.world.World;
import com.lineage.server.model.Instance.L1ItemInstance;
import java.util.ArrayList;
import com.lineage.server.serverpackets.ServerBasePacket;

public class S_ShopBuyListMob extends ServerBasePacket
{
    public S_ShopBuyListMob(final int objid, final ArrayList<L1ItemInstance> list) {
        final L1Object object = World.get().findObject(objid);
        if (!(object instanceof L1NpcInstance)) {
            return;
        }
        this.writeC(65);
        this.writeD(objid);
        this.writeH(list.size());
        for (final L1ItemInstance item : list) {
            this.writeD(item.getId());
            final int MobId = item.getGamNo();
            final L1Mobbling MobInfo = MobblingLock.create().getMobbling(MobId);
            if (MobInfo != null) {
                if (MobInfo.get_npcid() != item.getGamNpcId()) {
                    continue;
                }
                this.writeD((int)(L1Config._2153 * MobInfo.get_rate()));
            }
        }
        this.writeH(7);
    }
    
    @Override
    public byte[] getContent() {
        return this.getBytes();
    }
    
    @Override
    public String getType() {
        return "[S] S_ShopBuyList";
    }
}
