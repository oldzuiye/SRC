package com.add.Mobbling;

import java.util.Iterator;
import com.lineage.server.model.L1PcInventory;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.add.L1Config;
import java.util.Collection;
import com.lineage.server.model.Instance.L1ItemInstance;
import java.util.ArrayList;
import com.lineage.server.model.Instance.L1PcInstance;

public class L1MobSpList
{
    private final L1PcInstance _pc;
    private static MobblingTimeList _Mob;
    private final ArrayList<int[]> _MobList;
    private final ArrayList<L1ItemInstance> _MobSellList;
    
    static {
        L1MobSpList._Mob = MobblingTimeList.Mob();
    }
    
    public L1MobSpList(final L1PcInstance pc) {
        this._MobList = new ArrayList<int[]>();
        this._MobSellList = new ArrayList<L1ItemInstance>();
        this._pc = pc;
    }
    
    public void clear() {
        this._MobList.clear();
        this._MobSellList.clear();
    }
    
    public void set_copyMob(final ArrayList<int[]> invList) {
        this.clear();
        this._MobList.addAll(invList);
    }
    
    public ArrayList<int[]> get_MobList() {
        return this._MobList;
    }
    
    public void addMobItem(final int order, final int count) {
        final int[] MobItem = this._MobList.get(order);
        final int price = L1Config._2153 * count;
        this.checkMobShopItem(MobItem, count, price);
    }
    
    private void checkMobShopItem(final int[] MobItem, final int amount, final int totalPrice) {
        int price = 0;
        L1ItemInstance priceItem = null;
        priceItem = this._pc.getInventory().findItemId(L1Config._2156);
        if (priceItem != null) {
            price = (int)priceItem.getCount();
        }
        if (totalPrice > price) {
            this._pc.sendPackets(new S_ServerMessage(936));
        }
        else {
            this._pc.getInventory().removeItem(priceItem, totalPrice);
            final L1PcInventory inv = this._pc.getInventory();
            final int npcMob1 = MobblingTimeList.Mob().get_npcMob1().getNpcId();
            final int npcMob2 = MobblingTimeList.Mob().get_npcMob2().getNpcId();
            final int npcMob3 = MobblingTimeList.Mob().get_npcMob3().getNpcId();
            final int npcMob4 = MobblingTimeList.Mob().get_npcMob4().getNpcId();
            final int npcMob5 = MobblingTimeList.Mob().get_npcMob5().getNpcId();
            final int npcMob6 = MobblingTimeList.Mob().get_npcMob6().getNpcId();
            final int npcMob7 = MobblingTimeList.Mob().get_npcMob7().getNpcId();
            final int npcMob8 = MobblingTimeList.Mob().get_npcMob8().getNpcId();
            final int npcMob9 = MobblingTimeList.Mob().get_npcMob9().getNpcId();
            final int npcMob10 = MobblingTimeList.Mob().get_npcMob10().getNpcId();
            final int itemId = L1Config._2155;
            final int MobNo = MobItem[1];
            final int MobNpcId = MobItem[0];
            if (L1MobSpList._Mob.get_isStart()) {
                return;
            }
            if (L1MobSpList._Mob.get_MobId() != MobNo) {
                return;
            }
            if (MobNpcId == npcMob1) {
                MobblingTimeList.Mob().add_npcChip1A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob2) {
                MobblingTimeList.Mob().add_npcChip2A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob3) {
                MobblingTimeList.Mob().add_npcChip3A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob4) {
                MobblingTimeList.Mob().add_npcChip4A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob5) {
                MobblingTimeList.Mob().add_npcChip5A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob6) {
                MobblingTimeList.Mob().add_npcChip6A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob7) {
                MobblingTimeList.Mob().add_npcChip7A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob8) {
                MobblingTimeList.Mob().add_npcChip8A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob9) {
                MobblingTimeList.Mob().add_npcChip9A(amount * L1Config._2153);
            }
            if (MobNpcId == npcMob10) {
                MobblingTimeList.Mob().add_npcChip10A(amount * L1Config._2153);
            }
            final L1ItemInstance item = ItemTable.get().createItem(itemId);
            item.setCount(amount);
            item.setIdentified(true);
            item.setGamNo(MobNo);
            item.setGamNpcId(MobNpcId);
            inv.storeItem(item);
            this._pc.sendPackets(new S_ServerMessage(403, item.getLogName()));
        }
    }
    
    public void checkMobShop() {
        this.clear();
    }
    
    public void set_copySellMob(final ArrayList<L1ItemInstance> invList) {
        this.clear();
        this._MobSellList.addAll(invList);
    }
    
    public ArrayList<L1ItemInstance> get_MobSellList() {
        return this._MobSellList;
    }
    
    public void addSellMobItem(final int objid, final int count) {
        boolean isOk = false;
        final L1ItemInstance MobItem = this._pc.getInventory().getItem(objid);
        for (final L1ItemInstance chItem : this._MobSellList) {
            if (chItem == MobItem) {
                isOk = true;
            }
        }
        if (!isOk) {
            return;
        }
        final int MobId = MobItem.getGamNo();
        int i = 0;
        final L1Mobbling MobInfo = MobblingLock.create().getMobbling(MobId);
        if (MobInfo != null && MobInfo.get_npcid() == MobItem.getGamNpcId()) {
            i = (int)(L1Config._2153 * MobInfo.get_rate()) * count;
        }
        this.checkMobSellItem(MobItem, count, i);
    }
    
    private void checkMobSellItem(final L1ItemInstance MobItem, final int count, final int amount) {
        if (MobItem == null) {
            return;
        }
        this._pc.getInventory().removeItem(MobItem, count);
        final L1PcInventory inv = this._pc.getInventory();
        L1ItemInstance item = null;
        item = ItemTable.get().createItem(L1Config._2156);
        item.setCount(amount);
        inv.storeItem(item);
        this._pc.sendPackets(new S_ServerMessage(403, item.getLogName()));
    }
    
    public void checkMobSell() {
        this.clear();
    }
}
