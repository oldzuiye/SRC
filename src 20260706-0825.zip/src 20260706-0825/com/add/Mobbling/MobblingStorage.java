package com.add.Mobbling;

public interface MobblingStorage
{
    void create(final int p0, final int p1, final double p2, final int p3);
    
    void load();
    
    L1Mobbling[] getMobblingList();
    
    L1Mobbling getMobbling(final int p0);
}
