package com.add.Mobbling;

import com.lineage.server.model.Instance.L1MonsterInstance;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.model.Instance.L1PcInstance;
import java.lang.reflect.Constructor;
import com.lineage.server.templates.L1Npc;
import com.lineage.server.datatables.NpcTable;
import com.lineage.server.utils.Random;
import com.lineage.server.IdFactory;
import java.util.Iterator;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_NpcChatPacket;
import com.add.L1Config;
import com.lineage.server.model.L1Object;
import com.lineage.server.world.World;
import com.lineage.server.thread.GeneralThreadPool;
import org.apache.commons.logging.LogFactory;
import com.lineage.server.model.Instance.L1NpcInstance;
import java.util.Timer;
import org.apache.commons.logging.Log;
import java.util.TimerTask;

public class MobblingTime extends TimerTask
{
    private static final Log _log;
    private Timer _timeHandler;
    private L1NpcInstance _victoryNpc;
    private boolean _isOver;
    private int _startTime1;
    private MobblingTimeList _Mob;
    private double _npcRateA;
    private int _npcChipA;
    private static boolean _Mobbling;
    
    static {
        _log = LogFactory.getLog((Class)MobblingTime.class);
        MobblingTime._Mobbling = false;
    }
    
    public MobblingTime() {
        this._timeHandler = new Timer(true);
        this._victoryNpc = null;
        this._isOver = false;
        this._startTime1 = 0;
        this._Mob = MobblingTimeList.Mob();
    }
    
    public int get_npcChipA() {
        return this._npcChipA;
    }
    
    public double get_npcRateA() {
        return this._npcRateA;
    }
    
    public void startMobbling() {
        this._timeHandler.schedule(this, 500L, 500L);
        GeneralThreadPool.get().execute(this);
        this.nowStart();
    }
    
    @Override
    public void run() {
        if (this._isOver) {
            try {
                Thread.sleep(20000L);
                this.clear();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        switch (++this._startTime1) {
            case 2: {
                this.toAllTimeM("5");
                break;
            }
            case 120: {
                this.toAllTimeM("4");
                break;
            }
            case 240: {
                this.toAllTimeM("3");
                break;
            }
            case 360: {
                this.toAllTimeM("2");
                break;
            }
            case 480: {
                this.toAllTimeM("1");
                break;
            }
            case 590: {
                this.toAllTimeS("5");
                break;
            }
            case 592: {
                this.toAllTimeS("4");
                break;
            }
            case 594: {
                this.toAllTimeS("3");
                break;
            }
            case 596: {
                this.toAllTimeS("2");
                break;
            }
            case 598: {
                this.toAllTimeS("1");
                break;
            }
            case 600: {
                this.checkMobbling();
                this.start();
                break;
            }
            case 612: {
                this.toRate(1);
                break;
            }
            case 614: {
                this.toRate(2);
                break;
            }
            case 616: {
                this.toRate(3);
                break;
            }
            case 618: {
                this.toRate(4);
                break;
            }
            case 620: {
                this.toRate(5);
                break;
            }
            case 622: {
                this.toRate(6);
                break;
            }
            case 624: {
                this.toRate(7);
                break;
            }
            case 626: {
                this.toRate(8);
                break;
            }
            case 628: {
                this.toRate(9);
                break;
            }
            case 630: {
                this.toRate(10);
                break;
            }
        }
    }
    
    private void toRate(final int type) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2154) {
                continue;
            }
            double npcRateA = 0.0;
            String npcName = null;
            switch (type) {
                case 1: {
                    npcRateA = this._Mob.get_npcRate1A();
                    npcName = this._Mob.get_npcMob1().getNameId();
                    break;
                }
                case 2: {
                    npcRateA = this._Mob.get_npcRate2A();
                    npcName = this._Mob.get_npcMob2().getNameId();
                    break;
                }
                case 3: {
                    npcRateA = this._Mob.get_npcRate3A();
                    npcName = this._Mob.get_npcMob3().getNameId();
                    break;
                }
                case 4: {
                    npcRateA = this._Mob.get_npcRate4A();
                    npcName = this._Mob.get_npcMob4().getNameId();
                    break;
                }
                case 5: {
                    npcRateA = this._Mob.get_npcRate5A();
                    npcName = this._Mob.get_npcMob5().getNameId();
                    break;
                }
                case 6: {
                    npcRateA = this._Mob.get_npcRate6A();
                    npcName = this._Mob.get_npcMob6().getNameId();
                    break;
                }
                case 7: {
                    npcRateA = this._Mob.get_npcRate7A();
                    npcName = this._Mob.get_npcMob7().getNameId();
                    break;
                }
                case 8: {
                    npcRateA = this._Mob.get_npcRate8A();
                    npcName = this._Mob.get_npcMob8().getNameId();
                    break;
                }
                case 9: {
                    npcRateA = this._Mob.get_npcRate9A();
                    npcName = this._Mob.get_npcMob9().getNameId();
                    break;
                }
                case 10: {
                    npcRateA = this._Mob.get_npcRate10A();
                    npcName = this._Mob.get_npcMob10().getNameId();
                    break;
                }
            }
            String si = String.valueOf(npcRateA);
            final int re = si.indexOf(".");
            if (re != -1) {
                si = si.substring(0, re + 2);
            }
            final String toUser = String.valueOf(npcName) + " $402 " + si + "$367";
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
        }
    }
    
    private void toAllTimeM(final String info) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2154) {
                continue;
            }
            final String toUser = "$376 " + info + " $377";
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
        }
    }
    
    private void toAllTimeS(final String info) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2154) {
                continue;
            }
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, info, 2));
        }
    }
    
    private void start() {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2154) {
                continue;
            }
            this._Mob.computationRate();
            final String toUser = "$364";
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
        }
        this._Mob.set_isStart(true);
        this._Mob.set_isBuy(false);
    }
    
    public void clear() {
        if (this.cancel()) {
            this._timeHandler.purge();
        }
        this._victoryNpc = null;
        this._startTime1 = 0;
        this._isOver = false;
        this._Mob.clear();
    }
    
    private void checkMobbling() {
        final L1NpcInstance npcMob1 = this._Mob.get_npcMob1();
        final L1NpcInstance npcMob2 = this._Mob.get_npcMob2();
        final L1NpcInstance npcMob3 = this._Mob.get_npcMob3();
        final L1NpcInstance npcMob4 = this._Mob.get_npcMob4();
        final L1NpcInstance npcMob5 = this._Mob.get_npcMob5();
        final L1NpcInstance npcMob6 = this._Mob.get_npcMob6();
        final L1NpcInstance npcMob7 = this._Mob.get_npcMob7();
        final L1NpcInstance npcMob8 = this._Mob.get_npcMob8();
        final L1NpcInstance npcMob9 = this._Mob.get_npcMob9();
        final L1NpcInstance npcMob10 = this._Mob.get_npcMob10();
        if (npcMob1 == null || npcMob2 == null || npcMob3 == null || npcMob4 == null || npcMob5 == null || npcMob6 == null || npcMob7 == null || npcMob8 == null || npcMob9 == null || npcMob10 == null) {
            return;
        }
        this.setMobbling(true);
        final StartGame startGame = new StartGame();
        startGame.begin(10000);
    }
    
    private void nowStart() {
        final int MobId = IdFactory.get().nextMobId();
        this._Mob.set_MobId(MobId);
        final int[] npcid = { 990000, 990001, 990002, 990003, 990004, 990005, 990006, 990007, 990008, 990009, 990010, 990011, 990012, 990013, 990014, 990015, 990016, 990017, 990018, 990019, 990020, 990021, 990022, 990023, 990024, 990025, 990026, 990027, 990028 };
        final int npcid2 = npcid[Random.getInt(npcid.length)];
        this.spawnMobblingNpc(1, npcid2);
        int npcid3;
        for (npcid3 = npcid[Random.getInt(npcid.length)]; npcid3 == npcid2; npcid3 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(2, npcid3);
        int npcid4;
        for (npcid4 = npcid[Random.getInt(npcid.length)]; npcid4 == npcid2 || npcid4 == npcid3; npcid4 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(3, npcid4);
        int npcid5;
        for (npcid5 = npcid[Random.getInt(npcid.length)]; npcid5 == npcid2 || npcid5 == npcid3 || npcid5 == npcid4; npcid5 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(4, npcid5);
        int npcid6;
        for (npcid6 = npcid[Random.getInt(npcid.length)]; npcid6 == npcid2 || npcid6 == npcid3 || npcid6 == npcid4 || npcid6 == npcid5; npcid6 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(5, npcid6);
        int npcid7;
        for (npcid7 = npcid[Random.getInt(npcid.length)]; npcid7 == npcid2 || npcid7 == npcid3 || npcid7 == npcid4 || npcid7 == npcid5 || npcid7 == npcid6; npcid7 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(6, npcid7);
        int npcid8;
        for (npcid8 = npcid[Random.getInt(npcid.length)]; npcid8 == npcid2 || npcid8 == npcid3 || npcid8 == npcid4 || npcid8 == npcid5 || npcid8 == npcid6 || npcid8 == npcid7; npcid8 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(7, npcid8);
        int npcid9;
        for (npcid9 = npcid[Random.getInt(npcid.length)]; npcid9 == npcid2 || npcid9 == npcid3 || npcid9 == npcid4 || npcid9 == npcid5 || npcid9 == npcid6 || npcid9 == npcid7 || npcid9 == npcid8; npcid9 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(8, npcid9);
        int npcid10;
        for (npcid10 = npcid[Random.getInt(npcid.length)]; npcid10 == npcid2 || npcid10 == npcid3 || npcid10 == npcid4 || npcid10 == npcid5 || npcid10 == npcid6 || npcid10 == npcid7 || npcid10 == npcid8 || npcid10 == npcid9; npcid10 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(9, npcid10);
        int npcid11;
        for (npcid11 = npcid[Random.getInt(npcid.length)]; npcid11 == npcid2 || npcid11 == npcid3 || npcid11 == npcid4 || npcid11 == npcid5 || npcid11 == npcid6 || npcid11 == npcid7 || npcid11 == npcid8 || npcid11 == npcid9 || npcid11 == npcid10; npcid11 = npcid[Random.getInt(npcid.length)]) {}
        this.spawnMobblingNpc(10, npcid11);
        this._Mob.set_isWaiting(true);
        this._Mob.set_isBuy(true);
    }
    
    private void spawnMobblingNpc(final int type, final int npcid) {
        int x = 32699;
        int y = 32896;
        switch (type) {
            case 1: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 2: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 3: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 4: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 5: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 6: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 7: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 8: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 9: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
            case 10: {
                x = 32699 + Random.getInt(11) - 5;
                y = 32896 + Random.getInt(11) - 5;
                break;
            }
        }
        try {
            final L1Npc l1npc = NpcTable.get().getTemplate(npcid);
            if (l1npc == null) {
                return;
            }
            try {
                final String s = l1npc.getImpl();
                final Constructor<?> constructor = Class.forName("com.lineage.server.model.Instance." + s + "Instance").getConstructors()[0];
                final Object[] aobj = { l1npc };
                final L1NpcInstance npc = (L1NpcInstance)constructor.newInstance(aobj);
                npc.setId(IdFactory.get().nextId());
                npc.setMap((short)93);
                npc.setX(x);
                npc.setY(y);
                npc.setHomeX(npc.getX());
                npc.setHomeY(npc.getY());
                npc.setHeading(6);
                World.get().storeObject(npc);
                World.get().addVisibleObject(npc);
                npc.onNpcAI();
                npc.turnOnOffLight();
                npc.stopHpRegeneration();
                npc.stopMpRegeneration();
                switch (type) {
                    case 1: {
                        this._Mob.set_npcMob1(npc);
                        break;
                    }
                    case 2: {
                        this._Mob.set_npcMob2(npc);
                        break;
                    }
                    case 3: {
                        this._Mob.set_npcMob3(npc);
                        break;
                    }
                    case 4: {
                        this._Mob.set_npcMob4(npc);
                        break;
                    }
                    case 5: {
                        this._Mob.set_npcMob5(npc);
                        break;
                    }
                    case 6: {
                        this._Mob.set_npcMob6(npc);
                        break;
                    }
                    case 7: {
                        this._Mob.set_npcMob7(npc);
                        break;
                    }
                    case 8: {
                        this._Mob.set_npcMob8(npc);
                        break;
                    }
                    case 9: {
                        this._Mob.set_npcMob9(npc);
                        break;
                    }
                    case 10: {
                        this._Mob.set_npcMob10(npc);
                        break;
                    }
                }
            }
            catch (Exception e) {
                e.getLocalizedMessage();
            }
        }
        catch (Exception ex) {}
    }
    
    public void setMobbling(final boolean Mobbling) {
        MobblingTime._Mobbling = Mobbling;
    }
    
    public static boolean getMobbling() {
        return MobblingTime._Mobbling;
    }
    
    private void checkVictory() {
        final int MobId = this._Mob.get_MobId();
        if (this._victoryNpc != null) {
            this.isOver();
            this._Mob.set_isStart(false);
            this.setMobbling(false);
            for (final L1PcInstance listner : World.get().getAllPlayers()) {
                if (listner.isShowWorldChat()) {
                    listner.sendPackets(new S_ServerMessage(166, "怪物對戰: $375 (" + String.valueOf(MobId) + ") $366 " + this._victoryNpc.getNameId() + "$367" + "賠率:" + this.get_npcRateA() + "下注金額:" + this.get_npcChipA()));
                }
            }
            MobblingTime._log.info((Object)("怪物對戰: 第 (" + String.valueOf(MobId) + ") 場比賽的優勝者是" + this._victoryNpc.getNameId() + "。" + "賠率:" + this.get_npcRateA() + "下注金額:" + this.get_npcChipA()));
        }
    }
    
    private int MobCount(final short mapId) {
        int MobCount = 0;
        for (final Object obj : World.get().getVisibleObjects(mapId).values()) {
            if (obj instanceof L1MonsterInstance) {
                final L1MonsterInstance mob = (L1MonsterInstance)obj;
                if (mob == null || mob.isDead() || mob.getCurrentHp() <= 0) {
                    continue;
                }
                ++MobCount;
            }
        }
        return MobCount;
    }
    
    private void isOver() {
        final L1NpcInstance npcMob1 = this._Mob.get_npcMob1();
        final L1NpcInstance npcMob2 = this._Mob.get_npcMob2();
        final L1NpcInstance npcMob3 = this._Mob.get_npcMob3();
        final L1NpcInstance npcMob4 = this._Mob.get_npcMob4();
        final L1NpcInstance npcMob5 = this._Mob.get_npcMob5();
        final L1NpcInstance npcMob6 = this._Mob.get_npcMob6();
        final L1NpcInstance npcMob7 = this._Mob.get_npcMob7();
        final L1NpcInstance npcMob8 = this._Mob.get_npcMob8();
        final L1NpcInstance npcMob9 = this._Mob.get_npcMob9();
        final L1NpcInstance npcMob10 = this._Mob.get_npcMob10();
        if (this._victoryNpc == npcMob1) {
            this._npcRateA = this._Mob.get_npcRate1A();
            this._npcChipA = this._Mob.get_npcChip1A();
        }
        else if (this._victoryNpc == npcMob2) {
            this._npcRateA = this._Mob.get_npcRate2A();
            this._npcChipA = this._Mob.get_npcChip2A();
        }
        else if (this._victoryNpc == npcMob3) {
            this._npcRateA = this._Mob.get_npcRate3A();
            this._npcChipA = this._Mob.get_npcChip3A();
        }
        else if (this._victoryNpc == npcMob4) {
            this._npcRateA = this._Mob.get_npcRate4A();
            this._npcChipA = this._Mob.get_npcChip4A();
        }
        else if (this._victoryNpc == npcMob5) {
            this._npcRateA = this._Mob.get_npcRate5A();
            this._npcChipA = this._Mob.get_npcChip5A();
        }
        else if (this._victoryNpc == npcMob6) {
            this._npcRateA = this._Mob.get_npcRate6A();
            this._npcChipA = this._Mob.get_npcChip6A();
        }
        else if (this._victoryNpc == npcMob7) {
            this._npcRateA = this._Mob.get_npcRate7A();
            this._npcChipA = this._Mob.get_npcChip7A();
        }
        else if (this._victoryNpc == npcMob8) {
            this._npcRateA = this._Mob.get_npcRate8A();
            this._npcChipA = this._Mob.get_npcChip8A();
        }
        else if (this._victoryNpc == npcMob9) {
            this._npcRateA = this._Mob.get_npcRate9A();
            this._npcChipA = this._Mob.get_npcChip9A();
        }
        else if (this._victoryNpc == npcMob10) {
            this._npcRateA = this._Mob.get_npcRate10A();
            this._npcChipA = this._Mob.get_npcChip10A();
        }
        final int a1 = this._Mob.get_npcChip1A();
        final int a2 = this._Mob.get_npcChip2A();
        final int a3 = this._Mob.get_npcChip3A();
        final int a4 = this._Mob.get_npcChip4A();
        final int a5 = this._Mob.get_npcChip5A();
        final int a6 = this._Mob.get_npcChip6A();
        final int a7 = this._Mob.get_npcChip7A();
        final int a8 = this._Mob.get_npcChip8A();
        final int a9 = this._Mob.get_npcChip9A();
        final int a10 = this._Mob.get_npcChip10A();
        final int npcId = this._victoryNpc.getNpcId();
        final int totalPrice = a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10;
        MobblingLock.create().create(this._Mob.get_MobId(), npcId, this._npcRateA, totalPrice);
        this._isOver = true;
    }
    
    static /* synthetic */ void access$3(final MobblingTime mobblingTime, final L1NpcInstance victoryNpc) {
        mobblingTime._victoryNpc = victoryNpc;
    }
    
    private class StartGame extends TimerTask
    {
        @Override
        public void run() {
            final L1NpcInstance _npcMob1 = MobblingTime.this._Mob.get_npcMob1();
            final L1NpcInstance _npcMob2 = MobblingTime.this._Mob.get_npcMob2();
            final L1NpcInstance _npcMob3 = MobblingTime.this._Mob.get_npcMob3();
            final L1NpcInstance _npcMob4 = MobblingTime.this._Mob.get_npcMob4();
            final L1NpcInstance _npcMob5 = MobblingTime.this._Mob.get_npcMob5();
            final L1NpcInstance _npcMob6 = MobblingTime.this._Mob.get_npcMob6();
            final L1NpcInstance _npcMob7 = MobblingTime.this._Mob.get_npcMob7();
            final L1NpcInstance _npcMob8 = MobblingTime.this._Mob.get_npcMob8();
            final L1NpcInstance _npcMob9 = MobblingTime.this._Mob.get_npcMob9();
            final L1NpcInstance _npcMob10 = MobblingTime.this._Mob.get_npcMob10();
            try {
                if (!_npcMob1.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob1);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob2.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob2);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob3.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob3);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob4.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob4);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob5.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob5);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob6.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob6);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob7.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob7);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob8.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob8);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob9.isDead()) {
                    if (MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                        MobblingTime.access$3(MobblingTime.this, _npcMob9);
                        MobblingTime.this.checkVictory();
                    }
                }
                else if (!_npcMob10.isDead() && MobblingTime.this.MobCount((short)93) == 1 && MobblingTime.this._victoryNpc == null) {
                    MobblingTime.access$3(MobblingTime.this, _npcMob10);
                    MobblingTime.this.checkVictory();
                }
            }
            catch (Exception e) {
                e.getLocalizedMessage();
            }
            if (MobblingTime.getMobbling()) {
                final StartGame startGame = new StartGame();
                startGame.begin(10000);
            }
        }
        
        public void begin(final int time) {
            final Timer timer = new Timer();
            timer.schedule(this, time);
        }
    }
}
