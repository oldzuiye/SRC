package com.add.Mobbling;

public class L1Mobbling
{
    private int _id;
    private int _npcid;
    private double _rate;
    private int _moneyNo;
    
    public void set_id(final int i) {
        this._id = i;
    }
    
    public void set_npcid(final int i) {
        this._npcid = i;
    }
    
    public void set_rate(final double i) {
        this._rate = i;
    }
    
    public void set_moneyNo(final int i) {
        this._moneyNo = i;
    }
    
    public int get_id() {
        return this._id;
    }
    
    public int get_npcid() {
        return this._npcid;
    }
    
    public double get_rate() {
        return this._rate;
    }
    
    public int get_moneyNo() {
        return this._moneyNo;
    }
}
