package com.add.Mobbling;

import java.io.IOException;
import com.lineage.server.templates.L1Npc;
import com.lineage.server.templates.L1Item;
import com.lineage.server.model.Instance.L1ItemStatus;
import com.lineage.server.datatables.NpcTable;
import com.add.L1Config;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.model.Instance.L1ItemInstance;
import java.util.ArrayList;
import com.lineage.server.serverpackets.ServerBasePacket;

public class S_ShopSellListMob extends ServerBasePacket
{
    private static MobblingTimeList _Mob;
    
    static {
        S_ShopSellListMob._Mob = MobblingTimeList.Mob();
    }
    
    public S_ShopSellListMob(final int objId, final ArrayList<int[]> Mobs) {
        this.writeC(70);
        this.writeD(objId);
        this.writeH(Mobs.size());
        final L1ItemInstance dummy = new L1ItemInstance();
        if (S_ShopSellListMob._Mob.get_isStart()) {
            return;
        }
        for (int i = 0; i < Mobs.size(); ++i) {
            final int[] info = Mobs.get(i);
            final L1Item item = ItemTable.get().getTemplate(L1Config._2155);
            final int price = L1Config._2153;
            final L1Npc npc = NpcTable.get().getTemplate(info[0]);
            this.writeD(i);
            this.writeH(item.getGfxId());
            this.writeD(price);
            this.writeS(String.valueOf(npc.get_nameid()) + "(" + info[1] + "-" + info[0] + ")");
            dummy.setItem(item);
            final L1ItemStatus itemInfo = new L1ItemStatus(item);
            final byte[] status = itemInfo.getStatusBytes(true).getBytes();
            this.writeC(status.length);
            byte[] array;
            for (int length = (array = status).length, j = 0; j < length; ++j) {
                final byte b = array[j];
                this.writeC(b);
            }
        }
        this.writeH(7);
    }
    
    @Override
    public byte[] getContent() throws IOException {
        return this._bao.toByteArray();
    }
}
