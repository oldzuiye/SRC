package com.add.Mobbling;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.Statement;
import com.lineage.server.utils.SQLUtil;
import com.lineage.server.model.TimeInform;
import com.lineage.DatabaseFactory;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class MySqlMobblingStorage implements MobblingStorage
{
    private final Map<Integer, L1Mobbling> _Mobbling;
    
    public MySqlMobblingStorage() {
        this._Mobbling = new ConcurrentHashMap<Integer, L1Mobbling>();
    }
    
    @Override
    public void create(final int id, final int npcid, final double rate, final int totalPrice) {
        Connection con = null;
        PreparedStatement pstm = null;
        try {
            final L1Mobbling Mob = new L1Mobbling();
            Mob.set_id(id);
            Mob.set_npcid(npcid);
            Mob.set_rate(rate);
            this._Mobbling.put(id, Mob);
            con = DatabaseFactory.get().getConnection();
            final String sqlstr = "INSERT INTO `race_mobbling` SET `id`=?,`npcid`=?,`rate`=?,`time`=?,`totalPrice`=?";
            pstm = con.prepareStatement(sqlstr);
            pstm.setInt(1, Mob.get_id());
            pstm.setInt(2, Mob.get_npcid());
            pstm.setDouble(3, Mob.get_rate());
            final String time = TimeInform.time().getNowTime_Standard();
            pstm.setString(4, time);
            pstm.setInt(5, totalPrice);
            pstm.execute();
        }
        catch (Exception e) {
            e.getLocalizedMessage();
            return;
        }
        finally {
            SQLUtil.close(pstm);
            SQLUtil.close(con);
        }
        SQLUtil.close(pstm);
        SQLUtil.close(con);
    }
    
    @Override
    public void load() {
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        L1Mobbling Mob = null;
        try {
            con = DatabaseFactory.get().getConnection();
            final String sqlstr = "SELECT * FROM `race_Mobbling`";
            pstm = con.prepareStatement(sqlstr);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Mob = new L1Mobbling();
                final int id = rs.getInt("id");
                Mob.set_id(id);
                Mob.set_npcid(rs.getInt("npcid"));
                Mob.set_rate(rs.getDouble("rate"));
                this._Mobbling.put(id, Mob);
            }
        }
        catch (SQLException e) {
            e.getLocalizedMessage();
            return;
        }
        finally {
            SQLUtil.close(rs);
            SQLUtil.close(pstm);
            SQLUtil.close(con);
        }
        SQLUtil.close(rs);
        SQLUtil.close(pstm);
        SQLUtil.close(con);
    }
    
    @Override
    public L1Mobbling[] getMobblingList() {
        return this._Mobbling.values().<L1Mobbling>toArray(new L1Mobbling[this._Mobbling.size()]);
    }
    
    @Override
    public L1Mobbling getMobbling(final int id) {
        return this._Mobbling.get(id);
    }
}
