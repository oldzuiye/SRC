package com.add.system;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.Statement;
import com.lineage.server.utils.SQLUtil;
import java.sql.SQLException;
import com.lineage.DatabaseFactory;
import com.lineage.server.utils.PerformanceTimer;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import java.util.Map;
import org.apache.commons.logging.Log;

public class L1FireSmithCrystalTable
{
    private static final Log _log;
    private static L1FireSmithCrystalTable _instance;
    private final Map<Integer, L1FireCrystal> _FireCrystalIndex;
    
    static {
        _log = LogFactory.getLog((Class)L1FireSmithCrystalTable.class);
    }
    
    public L1FireSmithCrystalTable() {
        this._FireCrystalIndex = new HashMap<Integer, L1FireCrystal>();
    }
    
    public static L1FireSmithCrystalTable get() {
        if (L1FireSmithCrystalTable._instance == null) {
            L1FireSmithCrystalTable._instance = new L1FireSmithCrystalTable();
        }
        return L1FireSmithCrystalTable._instance;
    }
    
    public void load() {
        final PerformanceTimer timer = new PerformanceTimer();
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Label_0362: {
            try {
                con = DatabaseFactory.get().getConnection();
                pstm = con.prepareStatement("SELECT * FROM system_firesmith_crystal");
                rs = pstm.executeQuery();
                while (rs.next()) {
                    final int itemid = rs.getInt("itemid");
                    final int enchant_lv0 = rs.getInt("enchant_lv0");
                    final int enchant_lv2 = rs.getInt("enchant_lv1");
                    final int enchant_lv3 = rs.getInt("enchant_lv2");
                    final int enchant_lv4 = rs.getInt("enchant_lv3");
                    final int enchant_lv5 = rs.getInt("enchant_lv4");
                    final int enchant_lv6 = rs.getInt("enchant_lv5");
                    final int enchant_lv7 = rs.getInt("enchant_lv6");
                    final int enchant_lv8 = rs.getInt("enchant_lv7");
                    final int enchant_lv9 = rs.getInt("enchant_lv8");
                    final int enchant_lv10 = rs.getInt("enchant_lv9");
                    final int enchant_lv11 = rs.getInt("enchant_lv10");
                    final int enchant_lv12 = rs.getInt("enchant_lv11");
                    final int enchant_lv13 = rs.getInt("enchant_lv12");
                    final int enchant_lv14 = rs.getInt("enchant_lv13");
                    final int enchant_lv15 = rs.getInt("enchant_lv14");
                    final L1FireCrystal fireCrystal = new L1FireCrystal(itemid, enchant_lv0, enchant_lv2, enchant_lv3, enchant_lv4, enchant_lv5, enchant_lv6, enchant_lv7, enchant_lv8, enchant_lv9, enchant_lv10, enchant_lv11, enchant_lv12, enchant_lv13, enchant_lv14, enchant_lv15);
                    this._FireCrystalIndex.put(itemid, fireCrystal);
                }
            }
            catch (SQLException e) {
                L1FireSmithCrystalTable._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
                break Label_0362;
            }
            finally {
                SQLUtil.close(rs);
                SQLUtil.close(pstm);
                SQLUtil.close(con);
            }
            SQLUtil.close(rs);
            SQLUtil.close(pstm);
            SQLUtil.close(con);
        }
        L1FireSmithCrystalTable._log.info((Object)("載入火神融煉道具資料數量: " + this._FireCrystalIndex.size() + "(" + timer.get() + "ms)"));
    }
    
    public L1FireCrystal getTemplate(final int itemid) {
        return this._FireCrystalIndex.get(itemid);
    }
}
