package com.add.system;

import com.lineage.server.serverpackets.S_SystemMessage;
import java.util.Random;
import com.lineage.server.serverpackets.S_ItemCount;
import com.lineage.data.cmd.CreateNewItem;
import com.lineage.server.serverpackets.S_BoxMessage;
import com.lineage.server.serverpackets.S_CloseList;
import com.lineage.server.serverpackets.S_ServerMessage;
import java.util.Map;
import com.lineage.server.templates.L1Item;
import com.lineage.server.world.World;
import com.lineage.server.model.Instance.L1ItemInstance;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_NPCTalkReturn;
import java.util.HashMap;
import com.lineage.server.datatables.ItemTable;
import com.lineage.server.model.Instance.L1NpcInstance;
import com.lineage.server.model.Instance.L1PcInstance;

public class L1Blend
{
    private int _npcid;
    private String _action;
    private String _note;
    private int _checkLevel;
    private int _checkClass;
    private int _rnd;
    private int _hpConsume;
    private int _mpConsume;
    private boolean _inputaddrnd;
    private int _addchanceitem;
    private int _addchance;
    private int _additemmaxcount;
    private int[] _materials;
    private int[] _materials_count;
    private int[] _materials_enchants;
    private int _new_item;
    private int _new_item_counts;
    private int _new_Enchantlvl_SW;
    private int _new_item_Enchantlvl;
    private int _new_item_Bless;
    private int _residue_item;
    private int _residue_count;
    private int _residue_enchant;
    private int _replacement_count;
    private boolean _inputamount;
    private boolean _all_in_once;
    private int _bonus_item;
    private int _bonus_item_count;
    private int _bonus_item_enchant;
    private String _sucesshtml;
    private String _failhtml;
    private int UseAddChanceItemCount;
    private int AddChance;
    private int _announceSuccess;

    
    public L1Blend() {
        this.UseAddChanceItemCount = 0;
        this.AddChance = 0;
    }
    
    public int get_npcid() {
        return this._npcid;
    }
    
    public void set_npcid(final int npcid) {
        this._npcid = npcid;
    }
    
    public String get_action() {
        return this._action;
    }
    
    public void set_action(final String action) {
        this._action = action;
    }
    
    public String get_note() {
        return this._note;
    }
    
    public void set_note(final String note) {
        this._note = note;
    }
    
    public int getCheckLevel() {
        return this._checkLevel;
    }
    
    public void setCheckLevel(final int checkLevel) {
        this._checkLevel = checkLevel;
    }
    
    public int getCheckClass() {
        return this._checkClass;
    }
    
    public void setCheckClass(final int checkClass) {
        this._checkClass = checkClass;
    }
    
    public int getRandom() {
        return this._rnd;
    }
    
    public void setRandom(final int rnd) {
        this._rnd = rnd;
    }
    
    public int getHpConsume() {
        return this._hpConsume;
    }
    
    public void setHpConsume(final int hpConsume) {
        this._hpConsume = hpConsume;
    }
    
    public int getMpConsume() {
        return this._mpConsume;
    }
    
    public void setMpConsume(final int mpConsume) {
        this._mpConsume = mpConsume;
    }
    
    public boolean is_inputaddrnd() {
        return this._inputaddrnd;
    }
    
    public void set_inputaddrnd(final boolean _inputaddrnd) {
        this._inputaddrnd = _inputaddrnd;
    }
    
    public int get_addchanceitem() {
        return this._addchanceitem;
    }
    
    public void set_addchanceitem(final int _addchanceitem) {
        this._addchanceitem = _addchanceitem;
    }
    
    public int get_addchance() {
        return this._addchance;
    }
    
    public void set_addchance(final int _addchance) {
        this._addchance = _addchance;
    }
    
    public int get_additemmaxcount() {
        return this._additemmaxcount;
    }
    
    public void set_additemmaxcount(final int _additemmaxcount) {
        this._additemmaxcount = _additemmaxcount;
    }
    
    public final int[] getMaterials() {
        return this._materials;
    }
    
    public void setMaterials(final int[] needids) {
        this._materials = needids;
    }
    
    public final int[] getMaterials_count() {
        return this._materials_count;
    }
    
    public final void setMaterials_count(final int[] needcounts) {
        this._materials_count = needcounts;
    }
    
    public final int[] get_materials_enchants() {
        return this._materials_enchants;
    }
    
    public final void set_materials_enchants(final int[] needenchants) {
        this._materials_enchants = needenchants;
    }
    
    public int getNew_item() {
        return this._new_item;
    }
    
    public void setNew_item(final int new_item) {
        this._new_item = new_item;
    }
    
    public int getNew_item_counts() {
        return this._new_item_counts;
    }
    
    public void setNew_item_counts(final int new_item_counts) {
        this._new_item_counts = new_item_counts;
    }
    
    public int getNew_Enchantlvl_SW() {
        return this._new_Enchantlvl_SW;
    }
    
    public void setNew_Enchantlvl_SW(final int new_Enchantlvl_SW) {
        this._new_Enchantlvl_SW = new_Enchantlvl_SW;
    }
    
    public int getNew_item_Enchantlvl() {
        return this._new_item_Enchantlvl;
    }
    
    public void setNew_item_Enchantlvl(final int new_item_Enchantlvl) {
        this._new_item_Enchantlvl = new_item_Enchantlvl;
    }
    
    public int getNew_item_Bless() {
        return this._new_item_Bless;
    }
    
    public void setNew_item_Bless(final int new_item_bless) {
        this._new_item_Bless = new_item_bless;
    }
    
    public int getResidue_Item() {
        return this._residue_item;
    }
    
    public void setResidue_Item(final int residueitem) {
        this._residue_item = residueitem;
    }
    
    public int getResidue_Count() {
        return this._residue_count;
    }
    
    public void setResidue_Count(final int residuecount) {
        this._residue_count = residuecount;
    }
    
    public int getResidue_Enchant() {
        return this._residue_enchant;
    }
    
    public void setResidue_Enchant(final int residuecount) {
        this._residue_enchant = residuecount;
    }
    
    public int getReplacement_count() {
        return this._replacement_count;
    }
    
    public void setReplacement_count(final int replacement_count) {
        this._replacement_count = replacement_count;
    }
    
    public boolean isInputAmount() {
        return this._inputamount;
    }
    
    public void setInputAmount(final boolean flag) {
        this._inputamount = flag;
    }
    
    public boolean isAll_In_Once() {
        return this._all_in_once;
    }
    
    public void setAll_In_Once(final boolean flag) {
        this._all_in_once = flag;
    }
    
    public int getBonus_item() {
        return this._bonus_item;
    }
    
    public void setBonus_item(final int bonusitem) {
        this._bonus_item = bonusitem;
    }
    
    public int getBonus_item_count() {
        return this._bonus_item_count;
    }
    
    public void setBonus_item_count(final int bonusitemcount) {
        this._bonus_item_count = bonusitemcount;
    }
    
    public int getBonus_item_enchant() {
        return this._bonus_item_enchant;
    }
    
    public void setBonus_item_enchant(final int bonusitemenchant) {
        this._bonus_item_enchant = bonusitemenchant;
    }
    
    public String get_sucesshtml() {
        return this._sucesshtml;
    }
    
    public void set_sucesshtml(final String sucesshtml) {
        this._sucesshtml = sucesshtml;
    }
    
    public String get_failhtml() {
        return this._failhtml;
    }
    
    public void set_failhtml(final String failhtml) {
        this._failhtml = failhtml;
    }
    
    public void ShowCraftHtml(final L1PcInstance pc, final L1NpcInstance npc, final L1Blend ItemBlend) {
        String msg0 = "";
        String msg2 = "";
        String msg3 = "";
        String msg4 = "";
        String msg5 = "";
        String msg6 = "";
        String msg7 = "";
        final L1ItemInstance Newitem = ItemTable.get().createItem(ItemBlend.getNew_item());
        if (Newitem != null) {
            Newitem.setCount(ItemBlend.getNew_item_counts());
            Newitem.setEnchantLevel(ItemBlend.getNew_item_Enchantlvl());
            Newitem.setIdentified(true);
            msg0 = new StringBuilder().append(Newitem.getLogName()).toString();
        }
        final L1ItemInstance Bonusitem = ItemTable.get().createItem(ItemBlend.getBonus_item());
        if (Bonusitem != null) {
            Bonusitem.setCount(ItemBlend.getBonus_item_count());
            Bonusitem.setEnchantLevel(ItemBlend.getBonus_item_enchant());
            Bonusitem.setIdentified(true);
            msg2 = "製造成功時額外獲得: " + Bonusitem.getLogName();
        }
        if (ItemBlend.getCheckLevel() != 0) {
            msg3 = " " + ItemBlend.getCheckLevel() + "級以上。 ";
        }
        else {
            msg3 = " 無限制 ";
        }
        if (ItemBlend.getCheckClass() == 1) {
            msg4 = " 王族";
        }
        else if (ItemBlend.getCheckClass() == 2) {
            msg4 = " 騎士";
        }
        else if (ItemBlend.getCheckClass() == 3) {
            msg4 = " 法師";
        }
        else if (ItemBlend.getCheckClass() == 4) {
            msg4 = " 妖精";
        }
        else if (ItemBlend.getCheckClass() == 5) {
            msg4 = " 黑妖";
        }
        else if (ItemBlend.getCheckClass() == 6) {
            msg4 = " 龍騎";
        }
        else if (ItemBlend.getCheckClass() == 7) {
            msg4 = " 幻術";
        }
        else if (ItemBlend.getCheckClass() == 8) {
            msg4 = " 戰士";
        }
        else if (ItemBlend.getCheckClass() == 0) {
            msg4 = " 所有職業";
        }
        if (ItemBlend.getRandom() != -1) {
            msg5 = " " + ItemBlend.getRandom() + " %";
        }
        this.UseAddChanceItemCount = this.CheckForAddChanceItemCount(pc, ItemBlend);
        if (this.UseAddChanceItemCount > 0) {
            this.AddChance = this.UseAddChanceItemCount * ItemBlend.get_addchance();
            final L1Item addrnditem = ItemTable.get().getTemplate(ItemBlend.get_addchanceitem());
            msg6 = String.valueOf(addrnditem.getName()) + "增加成功機率: " + this.AddChance + " %";
        }
        final int[] Materials = ItemBlend.getMaterials();
        final int[] counts = ItemBlend.getMaterials_count();
        final int[] enchants = ItemBlend.get_materials_enchants();
        String[] itemdatas = null;
        if (Materials != null) {
            itemdatas = new String[Materials.length];
            for (int i = 0; i < Materials.length; ++i) {
                final L1ItemInstance temp = ItemTable.get().createItem(Materials[i]);
                temp.setEnchantLevel(enchants[i]);
                temp.setIdentified(true);
                final int replacementcount = ItemBlend.getReplacement_count();
                if (temp.getItemId() == 80028 && replacementcount != 0) {
                    msg7 = "可用(" + replacementcount + ")個火神痕跡替代火神契約";
                }
                itemdatas[i] = String.valueOf(temp.getLogName()) + " (" + counts[i] + ") 個";
            }
        }
        final String[] msgs = { msg0, msg2, msg3, msg4, msg5, msg6, msg7 };
        final Map<Integer, String> msgstable = new HashMap<Integer, String>();
        for (int j = 0; j < msgs.length; ++j) {
            msgstable.put(j, msgs[j]);
        }
        for (int j = 0; j < itemdatas.length; ++j) {
            msgstable.put(j + 7, itemdatas[j]);
        }
        final String[] msgs2 = new String[msgstable.size()];
        for (int k = 0; k < msgstable.size(); ++k) {
            msgs2[k] = msgstable.get(k);
        }
        pc.sendPackets(new S_NPCTalkReturn(npc.getId(), "ItemBlend", msgs2));
    }
    
    private boolean CheckForReplacement(final L1PcInstance pc, final L1Blend ItemBlend) {
        boolean replace = false;
        final int replacement = 80322;
        final int replacementcount = ItemBlend.getReplacement_count();
        if (replacementcount != 0 && pc.getInventory().checkItem(replacement, replacementcount)) {
            replace = true;
        }
        return replace;
    }
    
    private int CheckForAddChanceItemCount(final L1PcInstance pc, final L1Blend ItemBlend) {
        int useCount = 0;
        final int addRndItemid = ItemBlend.get_addchanceitem();
        if (addRndItemid != 0) {
            final L1ItemInstance addchanceitem = pc.getInventory().findItemId(addRndItemid);
            if (addchanceitem != null && ItemBlend.is_inputaddrnd()) {
                useCount = (int)addchanceitem.getCount();
                if (useCount > ItemBlend.get_additemmaxcount()) {
                    useCount = ItemBlend.get_additemmaxcount();
                }
            }
        }
        return useCount;
    }
    
    public void CheckCraftItem(final L1PcInstance pc, final L1NpcInstance npc, final L1Blend ItemBlend, final int amount, final boolean checked) {
        final int[] Materials = ItemBlend.getMaterials();
        final int[] Materials_counts = ItemBlend.getMaterials_count();
        final int[] enchants = ItemBlend.get_materials_enchants();
        if (checked || !ItemBlend.isInputAmount()) {
            boolean isok = true;
            final int New_itemid = ItemBlend.getNew_item();
            final int New_item_counts = ItemBlend.getNew_item_counts();
            final L1ItemInstance newitem = ItemTable.get().createItem(New_itemid);
            if (New_itemid == 56148 && (pc.getInventory().findItemId(56147) != null || pc.getInventory().findItemId(56148) != null)) {
                pc.sendPackets(new S_ServerMessage("身上已有妲蒂斯的魔力。"));
                isok = false;
            }
            if (New_itemid == 56147 && pc.getInventory().findItemId(56147) != null) {
                pc.sendPackets(new S_ServerMessage("身上已有妲蒂斯的魔力。"));
                isok = false;
            }
            if (pc.getInventory().checkAddItem(newitem, New_item_counts) != 0) {
                isok = false;
            }
            if (ItemBlend.getCheckLevel() != 0 && pc.getLevel() < ItemBlend.getCheckLevel()) {
                pc.sendPackets(new S_ServerMessage("等級必須為" + ItemBlend.getCheckLevel() + "以上。"));
                isok = false;
            }
            if (ItemBlend.getCheckClass() != 0) {
                byte class_id = 0;
                String Classmsg = "";
                if (pc.isCrown()) {
                    class_id = 1;
                }
                else if (pc.isKnight()) {
                    class_id = 2;
                }
                else if (pc.isWizard()) {
                    class_id = 3;
                }
                else if (pc.isElf()) {
                    class_id = 4;
                }
                else if (pc.isDarkelf()) {
                    class_id = 5;
                }
                else if (pc.isDragonKnight()) {
                    class_id = 6;
                }
                else if (pc.isIllusionist()) {
                    class_id = 7;
                }
                else if (pc.isWarrior()) {
                    class_id = 8;
                }
                switch (ItemBlend.getCheckClass()) {
                    case 1: {
                        Classmsg = "王族";
                        break;
                    }
                    case 2: {
                        Classmsg = "騎士";
                        break;
                    }
                    case 3: {
                        Classmsg = "法師";
                        break;
                    }
                    case 4: {
                        Classmsg = "妖精";
                        break;
                    }
                    case 5: {
                        Classmsg = "黑妖";
                        break;
                    }
                    case 6: {
                        Classmsg = "龍騎";
                        break;
                    }
                    case 7: {
                        Classmsg = "幻術";
                        break;
                    }
                    case 8: {
                        Classmsg = "戰士";
                        break;
                    }
                }
                if (ItemBlend.getCheckClass() != class_id) {
                    pc.sendPackets(new S_ServerMessage(166, "職業必須是", Classmsg, "才能製造此道具"));
                    isok = false;
                }
            }
            if (ItemBlend.getHpConsume() != 0 || ItemBlend.getMpConsume() != 0) {
                if (pc.getCurrentHp() < ItemBlend.getHpConsume()) {
                    pc.sendPackets(new S_ServerMessage(166, "$1083", "必須有 (" + ItemBlend.getHpConsume() + ") ", "才能使用此道具", "以上"));
                    isok = false;
                }
                if (pc.getCurrentMp() < ItemBlend.getMpConsume()) {
                    pc.sendPackets(new S_ServerMessage(166, "$1084", "必須有 (" + ItemBlend.getMpConsume() + ") ", "才能使用此道具", "以上"));
                    isok = false;
                }
            }
            boolean enough = false;
            if (isok) {
                int num = 0;
                for (int i = 0; i < Materials.length; ++i) {
                    if (Materials[i] != 0 && Materials_counts[i] != 0) {
                        if (Materials[i] == 80028 && !pc.getInventory().checkItem(Materials[i], Materials_counts[i]) && this.CheckForReplacement(pc, ItemBlend)) {
                            ++num;
                        }
                        else if (!pc.getInventory().checkEnchantItem(Materials[i], enchants[i], Materials_counts[i])) {
                            final L1ItemInstance temp = ItemTable.get().createItem(Materials[i]);
                            temp.setEnchantLevel(enchants[i]);
                            temp.setIdentified(true);
                            final long owncounts = pc.getInventory().countItemsWithEnchant(temp.getItemId(), enchants[i]);
                            pc.sendPackets(new S_ServerMessage(337, String.valueOf(temp.getLogName()) + "(" + (Materials_counts[i] - owncounts) + ")"));
                            isok = false;
                        }
                        else {
                            ++num;
                        }
                    }
                }
                if (num == Materials.length) {
                    enough = true;
                }
            }
            if (isok && enough) {
                final int[] newcounts = new int[Materials_counts.length];
                for (int i = 0; i < Materials_counts.length; ++i) {
                    newcounts[i] = Materials_counts[i] * amount;
                }
                if (this.UseAddChanceItemCount > 0 && amount == 1) {
                    pc.getInventory().consumeItem(ItemBlend.get_addchanceitem(), this.UseAddChanceItemCount);
                }
                for (int i = 0; i < Materials.length; ++i) {
                    if (Materials[i] == 80028 && this.CheckForReplacement(pc, ItemBlend) && amount == 1) {
                        final int replacementcount = ItemBlend.getReplacement_count();
                        pc.getInventory().consumeItem(80322, replacementcount);
                    }
                    else {
                        pc.getInventory().consumeEnchantItem(Materials[i], enchants[i], newcounts[i]);
                    }
                }
                if (ItemBlend.getHpConsume() > 0) {
                    pc.setCurrentHp(pc.getCurrentHp() - ItemBlend.getHpConsume());
                }
                if (ItemBlend.getMpConsume() > 0) {
                    pc.setCurrentMp(pc.getCurrentMp() - ItemBlend.getMpConsume());
                }
                this.CraftItem(pc, npc, ItemBlend, amount);
                final String sucesshtml = ItemBlend.get_sucesshtml();
                final int DBrnd = ItemBlend.getRandom();
                if (sucesshtml != null && amount == 1 && DBrnd == 100) {
                    pc.sendPackets(new S_NPCTalkReturn(pc.getId(), sucesshtml));
                }
            }
            else {
                final String failhtml = ItemBlend.get_failhtml();
                final int DBrnd2 = ItemBlend.getRandom();
                if (failhtml != null && amount == 1 && DBrnd2 == 100) {
                    pc.sendPackets(new S_NPCTalkReturn(pc.getId(), failhtml));
                }
                else {
                    pc.sendPackets(new S_CloseList(pc.getId()));
                }
            }
            return;
        }
        final long xcount = CreateNewItem.checkNewItem(pc, Materials, Materials_counts);
        if (xcount >= 1L) {
            pc.sendPackets(new S_ItemCount(npc.getId(), (int)xcount, null));
            return;
        }
        pc.sendPackets(new S_CloseList(pc.getId()));
    }
    
    private void CraftItem(final L1PcInstance pc, final L1NpcInstance npc, final L1Blend ItemBlend, final int amount) {
        final Random _random = new Random();
        final int DBrnd = ItemBlend.getRandom();
        final int TotalChance = (DBrnd + this.AddChance) * 10;

        final int New_itemid = ItemBlend.getNew_item();
        final int New_item_counts = ItemBlend.getNew_item_counts();
        final int ItemBless = ItemBlend.getNew_item_Bless();
        final int Bonus_itemid = ItemBlend.getBonus_item();
        final int Bonusitem_count = ItemBlend.getBonus_item_count();
        final int Bonusitem_enchant = ItemBlend.getBonus_item_enchant();
        final int ItemLV_SW = ItemBlend.getNew_Enchantlvl_SW();
        final int ItemLV = ItemBlend.getNew_item_Enchantlvl();
        final int ResdueItemid = ItemBlend.getResidue_Item();
        final int ResdueCount = ItemBlend.getResidue_Count();
        final int ResdueEnchant = ItemBlend.getResidue_Enchant();
        final String npcName = npc.getNpcTemplate().get_name();

        int newamount = amount;
        int newcounts = New_item_counts;
        if (ItemBlend.isAll_In_Once()) {
            newamount = 1;
            newcounts = New_item_counts * amount;
        }

        for (int i = 0; i < newamount; ++i) {
            if (_random.nextInt(1000) < TotalChance) {
                final L1ItemInstance newitem = ItemTable.get().createItem(New_itemid);
                if (newitem != null && pc.getInventory().checkAddItem(newitem, newcounts) == 0) {

                    if (newitem.isStackable()) {
                        if (ItemLV_SW == 0) {
                            newitem.setEnchantLevel(ItemLV);
                        } else {
                            newitem.setEnchantLevel(_random.nextInt(ItemLV) + 1);
                        }
                        newitem.setBless(ItemBless);
                        newitem.setIdentified(true);
                        newitem.setCount(newcounts);
                        pc.getInventory().storeItem(newitem);
                        pc.sendPackets(new S_ServerMessage(143, npcName, newitem.getLogName()));

                        // ★ 廣播堆疊物品
                        if (ItemBlend.getAnnounceSuccess() == 1) {
                            String playerName = pc.getName();
                            String method = npcName;
                            String itemName = newitem.getLogName();
                            World.get().broadcastPacketToAll(new S_BoxMessage("\\aE玩家 -> [ " + playerName + " ] "));
                            World.get().broadcastPacketToAll(new S_BoxMessage("\\aE經由 -> [ " + method + " ] "));
                            World.get().broadcastPacketToAll(new S_BoxMessage("\\aE獲得 -> [ " + itemName + " ] "));
                        }

                    } else {
                        // 非堆疊物品，每個 item 都要個別建立與處理
                        for (int c = 0; c < newcounts; ++c) {
                            final L1ItemInstance newitem2 = ItemTable.get().createItem(New_itemid);
                            if (ItemLV_SW == 0) {
                                newitem2.setEnchantLevel(ItemLV);
                            } else {
                                newitem2.setEnchantLevel(_random.nextInt(ItemLV) + 1);
                            }
                            newitem2.setBless(ItemBless);
                            newitem2.setIdentified(true);
                            newitem2.setCount(1L);
                            pc.getInventory().storeItem(newitem2);
                            pc.sendPackets(new S_ServerMessage(143, npcName, newitem2.getLogName()));

                            // ★ 廣播非堆疊
                            if (ItemBlend.getAnnounceSuccess() == 1) {
                                String playerName = pc.getName();
                                String method = npcName;
                                String itemName = newitem2.getLogName();
                                World.get().broadcastPacketToAll(new S_BoxMessage("\\aE玩家 -> [ " + playerName + " ] "));
                                World.get().broadcastPacketToAll(new S_BoxMessage("\\aE經由 -> [ " + method + " ] "));
                                World.get().broadcastPacketToAll(new S_BoxMessage("\\aE獲得 -> [ " + itemName + " ] "));
                            }
                        }
                    }

                    // ★ 成功獲得 Bonus Item
                    final L1ItemInstance bonusitem = ItemTable.get().createItem(Bonus_itemid);
                    if (bonusitem != null && pc.getInventory().checkAddItem(bonusitem, Bonusitem_count) == 0) {
                        if (bonusitem.isStackable()) {
                            bonusitem.setEnchantLevel(Bonusitem_enchant);
                            bonusitem.setIdentified(true);
                            bonusitem.setCount(Bonusitem_count);
                            pc.getInventory().storeItem(bonusitem);
                            pc.sendPackets(new S_ServerMessage(143, npcName, bonusitem.getLogName()));
                        } else {
                            for (int c2 = 0; c2 < Bonusitem_count; ++c2) {
                                final L1ItemInstance bonusitem2 = ItemTable.get().createItem(Bonus_itemid);
                                bonusitem2.setEnchantLevel(Bonusitem_enchant);
                                bonusitem2.setIdentified(true);
                                bonusitem2.setCount(1L);
                                pc.getInventory().storeItem(bonusitem2);
                                pc.sendPackets(new S_ServerMessage(143, npcName, bonusitem2.getLogName()));
                            }
                        }
                    }

                }
            } else {
                // ★ 製作失敗：給殘料
                final L1ItemInstance residueitem = ItemTable.get().createItem(ResdueItemid);
                if (residueitem != null && ResdueCount > 0) {
                    if (pc.getInventory().checkAddItem(residueitem, ResdueCount) == 0) {
                        residueitem.setEnchantLevel(ResdueEnchant);
                        residueitem.setIdentified(true);
                        residueitem.setCount(ResdueCount);
                        pc.getInventory().storeItem(residueitem);
                        pc.sendPackets(new S_ServerMessage(143, npcName, residueitem.getLogName()));
                        pc.sendPackets(new S_SystemMessage("道具製造失敗了。"));
                    }
                } else {
                    pc.sendPackets(new S_SystemMessage("道具製造失敗了。"));
                }
            }
        }

        pc.sendPackets(new S_CloseList(pc.getId()));
    }

    public int getAnnounceSuccess() {
        return this._announceSuccess;
    }

    public void setAnnounceSuccess(int announceSuccess) {
        this._announceSuccess = announceSuccess;
    }
}
