package com.add;

import com.lineage.server.serverpackets.S_BlueMessage;
import com.lineage.server.model.L1Object;
import com.lineage.server.model.L1Inventory;
import com.lineage.server.model.Instance.L1MonsterInstance;
import com.lineage.server.world.World;
import com.lineage.server.templates.L1Item;
import com.lineage.server.datatables.ItemTable;
import java.util.Iterator;
import java.util.List;
import com.lineage.server.model.L1War;
import com.lineage.server.world.WorldWar;
import com.lineage.server.thread.GeneralThreadPool;
import com.lineage.server.model.L1Clan;
import java.util.logging.Level;
import com.lineage.server.model.L1Teleport;
import com.lineage.server.serverpackets.S_ServerMessage;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SystemMessage;
import java.util.logging.Logger;
import com.lineage.server.model.Instance.L1PcInstance;
import java.util.ArrayList;

public class Game_ZhuduiPK
{
    private final ArrayList<L1PcInstance> _members;
    private static Game_ZhuduiPK _instance;
    private static Logger _log;
    private static String enemyClanName;
    private static String clanName;
    public static final int STATUS_NONE = 0;
    public static final int STATUS_READY = 1;
    public static final int STATUS_PLAYING = 2;
    public static final int STATUS_CLEANING = 4;
    private int _ZhuduiPKStatus;
    
    static {
        Game_ZhuduiPK._log = Logger.getLogger(Game_ZhuduiPK.class.getName());
        Game_ZhuduiPK.enemyClanName = "";
        Game_ZhuduiPK.clanName = "";
    }
    
    public Game_ZhuduiPK() {
        this._members = new ArrayList<L1PcInstance>();
        this._ZhuduiPKStatus = 0;
    }
    
    public static Game_ZhuduiPK getInstance() {
        if (Game_ZhuduiPK._instance == null) {
            Game_ZhuduiPK._instance = new Game_ZhuduiPK();
        }
        return Game_ZhuduiPK._instance;
    }
    
    public String enterZhuduiPK(final L1PcInstance pc) {
        if (getInstance().getZhuduiPKStatus() == 4) {
            pc.sendPackets(new S_SystemMessage("血盟PK大賽正在籌備中。"));
            return "";
        }
        if (getInstance().getZhuduiPKStatus() == 2) {
            pc.sendPackets(new S_ServerMessage(1182));
            if (!pc.getClan().getClanName().equals(Game_ZhuduiPK.enemyClanName) && !pc.getClan().getClanName().equals(Game_ZhuduiPK.clanName)) {
                pc.sendPackets(new S_SystemMessage("只有交戰雙方成員才可以進入。"));
            }
            else {
                pc.getInventory().consumeItem(L1Config._2054, L1Config._2055);
                L1Teleport.teleport(pc, 32700, 32895, (short)802, pc.getHeading(), true);
            }
            return "";
        }
        if (this.getMembersCount() >= 2) {
            pc.sendPackets(new S_SystemMessage("血盟PK大賽已經到達飽和的狀態了。"));
            return "";
        }
        if (pc.getClassId() != 1 && pc.getClassId() != 0) {
            pc.sendPackets(new S_SystemMessage("請讓你們王子或者公主來報名。"));
            return "";
        }
        if (!pc.getInventory().checkItem(L1Config._2054, L1Config._2055) && !this.isMember(pc)) {
            pc.sendPackets(new S_SystemMessage("入場所需物品不足。"));
            return "";
        }
        L1Teleport.teleport(pc, 32700, 32895, (short)802, pc.getHeading(), true);
        this.addMember(pc);
        return "";
    }
    
    public void callPartyPlayers(final L1PcInstance pc) {
        final L1Clan party = pc.getClan();
        if (party != null) {
            final int x = pc.getX();
            final int y = pc.getY() + 2;
            final short map = pc.getMapId();
            final L1PcInstance[] players = party.getOnlineClanMember();
            L1PcInstance[] array;
            for (int length = (array = players).length, i = 0; i < length; ++i) {
                final L1PcInstance pc2 = array[i];
                try {
                    if (!pc2.getParty().isLeader(pc2)) {
                        L1Teleport.teleport(pc2, x, y, map, 5, true);
                        pc2.sendPackets(new S_SystemMessage("您被傳喚到盟主身邊。"));
                    }
                }
                catch (Exception e) {
                    Game_ZhuduiPK._log.log(Level.SEVERE, "", e);
                }
            }
        }
    }
    
    private void addMember(final L1PcInstance pc) {
        if (!this._members.contains(pc)) {
            this._members.add(pc);
            pc.getInventory().consumeItem(L1Config._2054, L1Config._2055);
            this.callPartyPlayers(pc);
        }
        if (this.getMembersCount() == 1 && this.getZhuduiPKStatus() == 0) {
            Game_ZhuduiPK.enemyClanName = pc.getClanname();
        }
        else {
            Game_ZhuduiPK.clanName = pc.getClanname();
            GeneralThreadPool.get().execute(new runZhuduiPK((runZhuduiPK)null));
        }
    }
    
    private void starWar() {
        boolean inWar = false;
        final List<L1War> warList = WorldWar.get().getWarList();
        for (final L1War war : warList) {
            inWar = war.checkClanInSameWar(Game_ZhuduiPK.clanName, Game_ZhuduiPK.enemyClanName);
        }
        if (!inWar) {
            final L1War war = new L1War();
            war.handleCommands(3, Game_ZhuduiPK.clanName, Game_ZhuduiPK.enemyClanName);
        }
    }
    
    private boolean checkPlayerCount() {
        if (this.getMembersCount() <= 1) {
            this.setZhuduiPKStatus(4);
            this.sendMessage("血盟不足 2隊，所以強制關閉遊戲");
            L1PcInstance[] membersArray;
            for (int length = (membersArray = this.getMembersArray()).length, i = 0; i < length; ++i) {
                final L1PcInstance pc = membersArray[i];
                pc.getInventory().storeItem(L1Config._2054, L1Config._2055);
                final L1Item item = ItemTable.get().getTemplate(L1Config._2054);
                pc.sendPackets(new S_SystemMessage("血盟PK大賽退還:" + item.getName() + "(" + L1Config._2055 + ")。"));
            }
            this.clearMembers();
            return false;
        }
        return true;
    }
    
    private void endZhuduiPK() {
        this.setZhuduiPKStatus(4);
        this.sendMessage("血盟PK大賽已經結束，請下次再來");
        this.clearMembers();
    }
    
    private void clearColosseum() {
        for (final Object obj : World.get().getVisibleObjects(802).values()) {
            if (obj instanceof L1MonsterInstance) {
                final L1MonsterInstance mob = (L1MonsterInstance)obj;
                if (mob.isDead()) {
                    continue;
                }
                mob.setDead(true);
                mob.setStatus(8);
                mob.setCurrentHpDirect(0);
                mob.deleteMe();
            }
            else if (obj instanceof L1Inventory) {
                final L1Inventory inventory = (L1Inventory)obj;
                inventory.clearItems();
            }
            else {
                if (!(obj instanceof L1PcInstance)) {
                    continue;
                }
                final L1PcInstance l1PcInstance = (L1PcInstance)obj;
                L1Teleport.teleport(l1PcInstance, 32581, 32929, (short)0, l1PcInstance.getHeading(), true);
            }
        }
    }
    
    private void sendMessage(final String msg) {
        L1PcInstance[] membersArray;
        for (int length = (membersArray = this.getMembersArray()).length, i = 0; i < length; ++i) {
            final L1PcInstance pc = membersArray[i];
            if (pc.getMapId() == 802) {
                pc.sendPackets(new S_BlueMessage(166, "\\f3" + msg));
            }
        }
    }
    
    private void setZhuduiPKStatus(final int i) {
        this._ZhuduiPKStatus = i;
    }
    
    private int getZhuduiPKStatus() {
        return this._ZhuduiPKStatus;
    }
    
    private void clearMembers() {
        this._members.clear();
        this.clearColosseum();
    }
    
    private boolean isMember(final L1PcInstance pc) {
        return this._members.contains(pc);
    }
    
    private L1PcInstance[] getMembersArray() {
        return this._members.<L1PcInstance>toArray(new L1PcInstance[this._members.size()]);
    }
    
    private int getMembersCount() {
        return this._members.size();
    }
    
    private class runZhuduiPK implements Runnable
    {
        @Override
        public void run() {
            try {
                Game_ZhuduiPK.this.setZhuduiPKStatus(1);
                Game_ZhuduiPK.this.sendMessage(String.valueOf(L1Config._2051 + 10) + "秒後開始遊戲");
                Thread.sleep(L1Config._2051);
                Game_ZhuduiPK.this.sendMessage("倒數10秒");
                Thread.sleep(5000L);
                Game_ZhuduiPK.this.sendMessage("倒數5秒");
                Thread.sleep(1000L);
                Game_ZhuduiPK.this.sendMessage("4秒");
                Thread.sleep(1000L);
                Game_ZhuduiPK.this.sendMessage("3秒");
                Thread.sleep(1000L);
                Game_ZhuduiPK.this.sendMessage("2秒");
                Thread.sleep(1000L);
                Game_ZhuduiPK.this.sendMessage("1秒");
                Thread.sleep(1000L);
                Label_0568: {
                    if (Game_ZhuduiPK.this.checkPlayerCount()) {
                        Game_ZhuduiPK.this.setZhuduiPKStatus(2);
                        Game_ZhuduiPK.this.starWar();
                        while (true) {
                            while (!Game_ZhuduiPK.this._members.get(0).isDead() && Game_ZhuduiPK.this._members.get(0).getMapId() == 802) {
                                if (Game_ZhuduiPK.this._members.get(1).isDead() || Game_ZhuduiPK.this._members.get(1).getMapId() != 802) {
                                    Game_ZhuduiPK.this._members.get(0).getInventory().storeItem(L1Config._2056, L1Config._2057);
                                    Game_ZhuduiPK.this._members.get(0).getInventory().storeItem(L1Config._2058, L1Config._2059);
                                    World.get().broadcastPacketToAll(new S_ServerMessage(166, "血盟" + Game_ZhuduiPK.this._members.get(0).getClanname() + "打贏了血盟", new StringBuilder().append(Game_ZhuduiPK.this._members.get(1).getClanname()).toString()));
                                    Game_ZhuduiPK.this.sendMessage("血盟PK大賽將於10秒後結束！");
                                    Thread.sleep(10000L);
                                    Game_ZhuduiPK.this.endZhuduiPK();
                                    break Label_0568;
                                }
                                Thread.sleep(1000L);
                            }
                            Game_ZhuduiPK.this._members.get(1).getInventory().storeItem(L1Config._2056, L1Config._2057);
                            Game_ZhuduiPK.this._members.get(1).getInventory().storeItem(L1Config._2058, L1Config._2059);
                            World.get().broadcastPacketToAll(new S_ServerMessage(166, "血盟" + Game_ZhuduiPK.this._members.get(1).getClanname() + "打贏了血盟", new StringBuilder().append(Game_ZhuduiPK.this._members.get(0).getClanname()).toString()));
                            continue;
                        }
                    }
                }
                Thread.sleep(L1Config._2053);
                Game_ZhuduiPK.this.setZhuduiPKStatus(0);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
