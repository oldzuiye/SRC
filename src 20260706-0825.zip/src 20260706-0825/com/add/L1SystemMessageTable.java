package com.add;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.sql.Timestamp;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.Statement;
import com.lineage.server.utils.SQLUtil;
import java.sql.SQLException;
import com.lineage.DatabaseFactory;
import com.lineage.server.utils.PerformanceTimer;
import java.util.HashMap;
import org.apache.commons.logging.LogFactory;
import java.util.Map;
import org.apache.commons.logging.Log;

public class L1SystemMessageTable
{
    private static final Log _log;
    private static L1SystemMessageTable _instance;
    private final Map<Integer, L1SystemMessage> _ConfigIndex;
    
    static {
        _log = LogFactory.getLog((Class)L1SystemMessageTable.class);
    }
    
    public L1SystemMessageTable() {
        this._ConfigIndex = new HashMap<Integer, L1SystemMessage>();
    }
    
    public static L1SystemMessageTable get() {
        if (L1SystemMessageTable._instance == null) {
            L1SystemMessageTable._instance = new L1SystemMessageTable();
        }
        return L1SystemMessageTable._instance;
    }
    
    public void loadSystemMessage() {
        final PerformanceTimer timer = new PerformanceTimer();
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Label_0121: {
            try {
                con = DatabaseFactory.get().getConnection();
                pstm = con.prepareStatement("SELECT * FROM system_message");
                rs = pstm.executeQuery();
                this.fillSystemMessage(rs);
            }
            catch (SQLException e) {
                L1SystemMessageTable._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
                break Label_0121;
            }
            finally {
                SQLUtil.close(rs);
                SQLUtil.close(pstm);
                SQLUtil.close(con);
            }
            SQLUtil.close(rs);
            SQLUtil.close(pstm);
            SQLUtil.close(con);
        }
        L1SystemMessageTable._log.info((Object)("載入DB化系統設定檔資料數量: " + this._ConfigIndex.size() + "(" + timer.get() + "ms)"));
    }
    
    private void fillSystemMessage(final ResultSet rs) throws SQLException {
        while (rs.next()) {
            final int Id = rs.getInt("id");
            final String Message = rs.getString("message");
            final Timestamp time = rs.getTimestamp("resettime");
            Calendar cal = null;
            if (time != null) {
                cal = this.timestampToCalendar(rs.getTimestamp("resettime"));
            }
            final L1SystemMessage System_Message = new L1SystemMessage();
            System_Message.set_id(Id);
            System_Message.set_message(Message);
            System_Message.set_resettime(cal);
            this._ConfigIndex.put(Id, System_Message);
        }
    }
    
    public L1SystemMessage getTemplate(final int Id) {
        return this._ConfigIndex.get(Id);
    }
    
    private Calendar timestampToCalendar(final Timestamp ts) {
        final Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(ts.getTime());
        return cal;
    }
    
    public void updateResetTime(final int id, final Calendar reset_cal) {
        Connection con = null;
        PreparedStatement pstm = null;
        try {
            con = DatabaseFactory.get().getConnection();
            pstm = con.prepareStatement("UPDATE `system_message` SET `resettime`=? WHERE `id`=?");
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            final String fm = sdf.format(reset_cal.getTime());
            int i = 0;
            pstm.setString(++i, fm);
            pstm.setInt(++i, id);
            pstm.execute();
        }
        catch (Exception e) {
            L1SystemMessageTable._log.error((Object)e.getLocalizedMessage(), (Throwable)e);
            return;
        }
        finally {
            SQLUtil.close(pstm);
            SQLUtil.close(con);
        }
        SQLUtil.close(pstm);
        SQLUtil.close(con);
    }
}
