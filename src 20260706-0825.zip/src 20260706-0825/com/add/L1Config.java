package com.add;

import java.util.Calendar;

public class L1Config
{
    public static int _2011;
    public static int _2012;
    public static int _2013;
    public static int _2014;
    public static int _2015;
    public static int _2031;
    public static int _2032;
    public static int _2033;
    public static int _2034;
    public static int _2035;
    public static int _2036;
    public static int _2037;
    public static int _2038;
    public static int _2039;
    public static int _2040;
    public static int _2041;
    public static int _2051;
    public static int _2053;
    public static int _2054;
    public static int _2055;
    public static int _2056;
    public static int _2057;
    public static int _2058;
    public static int _2059;
    public static boolean _2151;
    public static int _2152;
    public static int _2153;
    public static int _2154;
    public static int _2155;
    public static int _2156;
    public static boolean _2161;
    public static int _2162;
    public static int _2163;
    public static int _2164;
    public static int _2165;
    public static int _2166;
    public static int _2167;
    public static int _2170;
    public static int _2211;
    public static int _2212;
    public static int _2213;
    public static int _2216;
    public static int _2217;
    public static int _2218;
    public static boolean _2226;
    public static int _2227;
    public static int _4001;
    public static Calendar _4002;
    public static boolean _4004;
    public static int _4005;
    public static int _4006;
    public static boolean _4008;
    public static Calendar _4009;
    
    static {
        L1Config._2011 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2011).get_message());
        L1Config._2012 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2012).get_message());
        L1Config._2013 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2013).get_message());
        L1Config._2014 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2014).get_message());
        L1Config._2015 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2015).get_message());
        L1Config._2031 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2031).get_message());
        L1Config._2032 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2032).get_message());
        L1Config._2033 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2033).get_message());
        L1Config._2034 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2034).get_message());
        L1Config._2035 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2035).get_message());
        L1Config._2036 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2036).get_message());
        L1Config._2037 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2037).get_message());
        L1Config._2038 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2038).get_message());
        L1Config._2039 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2039).get_message());
        L1Config._2040 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2040).get_message());
        L1Config._2041 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2041).get_message());
        L1Config._2051 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2051).get_message());
        L1Config._2053 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2053).get_message());
        L1Config._2054 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2054).get_message());
        L1Config._2055 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2055).get_message());
        L1Config._2056 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2056).get_message());
        L1Config._2057 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2057).get_message());
        L1Config._2058 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2058).get_message());
        L1Config._2059 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2059).get_message());
        L1Config._2151 = L1SystemMessageTable.get().getTemplate(2151).get_message().equals("true");
        L1Config._2152 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2152).get_message());
        L1Config._2153 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2153).get_message());
        L1Config._2154 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2154).get_message());
        L1Config._2155 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2155).get_message());
        L1Config._2156 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2156).get_message());
        L1Config._2161 = L1SystemMessageTable.get().getTemplate(2161).get_message().equals("true");
        L1Config._2162 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2162).get_message());
        L1Config._2163 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2163).get_message());
        L1Config._2164 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2164).get_message());
        L1Config._2165 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2165).get_message());
        L1Config._2166 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2166).get_message());
        L1Config._2167 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2167).get_message());
        L1Config._2170 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2170).get_message());
        L1Config._2211 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2211).get_message());
        L1Config._2212 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2212).get_message());
        L1Config._2213 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2213).get_message());
        L1Config._2216 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2216).get_message());
        L1Config._2217 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2217).get_message());
        L1Config._2218 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2218).get_message());
        L1Config._2226 = L1SystemMessageTable.get().getTemplate(2226).get_message().equals("true");
        L1Config._2227 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(2227).get_message());
        L1Config._4001 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(4001).get_message());
        L1Config._4002 = L1SystemMessageTable.get().getTemplate(4002).get_resettime();
        L1Config._4004 = L1SystemMessageTable.get().getTemplate(4004).get_message().equals("true");
        L1Config._4005 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(4005).get_message());
        L1Config._4006 = Integer.valueOf(L1SystemMessageTable.get().getTemplate(4006).get_message());
        L1Config._4008 = L1SystemMessageTable.get().getTemplate(4008).get_message().equals("true");
        L1Config._4009 = L1SystemMessageTable.get().getTemplate(4009).get_resettime();
     // 加在 static 區塊的最後（例如 L1Config._4009 設定後）

     // ======= 加入以下程式碼以強制將過期時間設定為未來 ========
     Calendar future = Calendar.getInstance();
     future.set(2099, Calendar.DECEMBER, 31); // 設定為 2099/12/31
     L1Config._4002 = future;
     L1Config._4009 = future;
     // ==========================================================
     // ※ 這段是為了強制跳過任何過期時間導致的閃退

    }
}
