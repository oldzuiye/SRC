package com.add.BigHot;

import com.lineage.server.model.TimeInform;
import com.lineage.server.thread.GeneralThreadPool;
import java.util.Timer;
import java.util.TimerTask;

public class T_BigHotbling extends TimerTask
{
    private static T_BigHotbling _instance;
    private Timer _timeHandler;
    private boolean _isBigHotta;
    
    public static T_BigHotbling getStart() {
        if (T_BigHotbling._instance == null) {
            T_BigHotbling._instance = new T_BigHotbling();
        }
        return T_BigHotbling._instance;
    }
    
    private T_BigHotbling() {
        this._timeHandler = new Timer(true);
        this._isBigHotta = false;
        this._timeHandler.schedule(this, 5000L, 10000L);
        GeneralThreadPool.get().execute(this);
    }
    
    @Override
    public void run() {
        final String mTime = TimeInform.time().getNow_YMDHMS(3);
        final String hTime = TimeInform.time().getNow_YMDHMS(4);
        final int mm = Integer.parseInt(mTime);
        final int hh = Integer.parseInt(hTime);
        switch (hh) {
            case 2:
            case 6:
            case 10:
            case 14:
            case 18:
            case 22: {
                if (mm == 1 && !this._isBigHotta) {
                    final BigHotblingTime BigHot = new BigHotblingTime();
                    BigHot.startBigHotbling();
                    this._isBigHotta = true;
                }
                if (mm == 3 && this._isBigHotta) {
                    this._isBigHotta = false;
                    break;
                }
                break;
            }
        }
    }
    
    public void startT_BigHotbling() {
        getStart();
    }
}
