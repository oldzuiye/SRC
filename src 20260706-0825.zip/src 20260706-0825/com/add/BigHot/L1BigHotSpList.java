package com.add.BigHot;

import java.io.IOException;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import com.lineage.server.model.L1PcInventory;
import java.sql.Timestamp;
import com.add.L1Config;
import com.lineage.server.datatables.ItemTable;
import java.util.Iterator;
import java.util.Collection;
import com.lineage.server.model.Instance.L1ItemInstance;
import java.util.ArrayList;
import com.lineage.server.model.Instance.L1PcInstance;

public class L1BigHotSpList
{
    private final L1PcInstance _pc;
    private final ArrayList<int[]> _BigHotList;
    private final ArrayList<L1ItemInstance> _BigHotSellList;
    
    public L1BigHotSpList(final L1PcInstance pc) {
        this._BigHotList = new ArrayList<int[]>();
        this._BigHotSellList = new ArrayList<L1ItemInstance>();
        this._pc = pc;
    }
    
    public void clear() {
        this._BigHotList.clear();
        this._BigHotSellList.clear();
    }
    
    public void set_copyBigHot(final ArrayList<int[]> invList) {
        this.clear();
        this._BigHotList.addAll(invList);
    }
    
    public ArrayList<int[]> get_BigHotList() {
        return this._BigHotList;
    }
    
    public void checkBigHotShop() {
        this.clear();
    }
    
    public void set_copySellBigHot(final ArrayList<L1ItemInstance> invList) {
        this.clear();
        this._BigHotSellList.addAll(invList);
    }
    
    public ArrayList<L1ItemInstance> get_BigHotSellList() {
        return this._BigHotSellList;
    }
    
    public void addSellBigHotItem(final int objid, final int count) {
        boolean isOk = false;
        final L1ItemInstance BigHotItem = this._pc.getInventory().getItem(objid);
        for (final L1ItemInstance chItem : this._BigHotSellList) {
            if (chItem == BigHotItem) {
                isOk = true;
            }
        }
        if (isOk) {
            final int BigHotId = BigHotItem.getGamNo();
            int price = 0;
            final L1BigHotbling BigHotInfo = BigHotblingLock.create().getBigHotbling(BigHotId);
            if (BigHotInfo != null) {
                final String A = BigHotInfo.get_number();
                final String B = BigHotItem.getStarNpcId();
                int AB = BigHotInfo.get_money1();
                final int BC = BigHotInfo.get_count();
                if (BC != 0) {
                    AB /= BC;
                }
                int CD = BigHotInfo.get_money2();
                final int DE = BigHotInfo.get_count1();
                if (DE != 0) {
                    CD /= DE;
                }
                int EF = BigHotInfo.get_money3();
                final int FG = BigHotInfo.get_count2();
                if (FG != 0) {
                    EF /= FG;
                }
                int ch = 0;
                for (int a = 0; a < A.split(",").length; ++a) {
                    final String[] pk = B.split(",");
                    if (("," + A).indexOf("," + pk[a] + ",") >= 0) {
                        ++ch;
                    }
                }
                if (ch >= 3) {
                    switch (ch) {
                        case 3: {
                            price = 50 * count;
                            break;
                        }
                        case 4: {
                            price = EF * count;
                            break;
                        }
                        case 5: {
                            price = CD * count;
                            break;
                        }
                        case 6: {
                            price = AB * count;
                            break;
                        }
                    }
                }
            }
            this.checkBigHotSellItem(BigHotItem, count, price);
        }
    }
    
    private void checkBigHotSellItem(final L1ItemInstance BigHotItem, final int count, final int amount) {
        if (BigHotItem == null) {
            return;
        }
        this._pc.getInventory().removeItem(BigHotItem, count);
        final L1PcInventory inv = this._pc.getInventory();
        L1ItemInstance item = null;
        item = ItemTable.get().createItem(L1Config._2167);
        item.setCount(amount);
        inv.storeItem(item);
        Bingo("IP(" + (Object)this._pc.getNetConnection().getIp() + ")" + "玩家【 " + this._pc.getName() + " 】 " + "中了第【 " + BigHotItem.getGamNo() + " 】 場，彩票號碼：【 " + BigHotItem.getStarNpcId() + " 】，" + "取得彩金：【 " + amount + " 】，" + "時間：(" + new Timestamp(System.currentTimeMillis()) + ")。");
    }
    
    public void checkBigHotSell() {
        this.clear();
    }
    
    public static void Bingo(final String info) {
        try {
            final BufferedWriter out = new BufferedWriter(new FileWriter("record/yuanbao/大樂透中獎紀錄.txt", true));
            out.write(String.valueOf(info) + "\r\n");
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
