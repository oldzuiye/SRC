package com.add.BigHot;

public interface BigHotblingStorage
{
    void create(final int p0, final String p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9);
    
    void load();
    
    L1BigHotbling[] getBigHotblingList();
    
    L1BigHotbling getBigHotbling(final int p0);
}
