package com.add.BigHot;

import java.util.concurrent.locks.ReentrantLock;

public class BigHotblingLock
{
    private static BigHotblingLock _instance;
    private final BigHotblingStorage _BigHotSt;
    private final ReentrantLock _lock;
    
    public static BigHotblingLock create() {
        if (BigHotblingLock._instance == null) {
            BigHotblingLock._instance = new BigHotblingLock();
        }
        return BigHotblingLock._instance;
    }
    
    public BigHotblingLock() {
        this._BigHotSt = new MySqlBigHotblingStorage();
        this._lock = new ReentrantLock(true);
    }
    
    public void load() {
        this._BigHotSt.load();
    }
    
    public void create(final int id, final String number, final int totalPrice, final int money1, final int count, final int money2, final int count1, final int money3, final int count2, final int count3) {
        this._lock.lock();
        try {
            this._BigHotSt.create(id, number, totalPrice, money1, count, money2, count1, money3, count2, count3);
        }
        finally {
            this._lock.unlock();
        }
        this._lock.unlock();
    }
    
    public L1BigHotbling[] getBigHotblingList() {
        return this._BigHotSt.getBigHotblingList();
    }
    
    public L1BigHotbling getBigHotbling(final int id) {
        return this._BigHotSt.getBigHotbling(id);
    }
}
