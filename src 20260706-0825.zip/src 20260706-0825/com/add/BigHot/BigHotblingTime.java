package com.add.BigHot;

import com.lineage.server.IdFactory;
import java.util.Iterator;
import com.lineage.server.serverpackets.S_NpcChatPacket;
import com.add.L1Config;
import com.lineage.server.model.Instance.L1NpcInstance;
import com.lineage.server.model.L1Object;
import com.lineage.server.serverpackets.ServerBasePacket;
import com.lineage.server.serverpackets.S_SystemMessage;
import com.lineage.server.world.World;
import com.lineage.server.thread.GeneralThreadPool;
import java.util.Timer;
import java.util.TimerTask;

public class BigHotblingTime extends TimerTask
{
    private Timer _timeHandler;
    private boolean _isOver;
    private int _BigHottTime;
    private BigHotblingTimeList _BigHot;
    public String BigHotAN;
    private int BigHotAN1;
    private int BigHotAN2;
    private int BigHotAN3;
    private int BigHotAN4;
    private int BigHotAN5;
    private int BigHotAN6;
    
    public BigHotblingTime() {
        this._timeHandler = new Timer(true);
        this._isOver = false;
        this._BigHottTime = 0;
        this._BigHot = BigHotblingTimeList.BigHot();
        this.BigHotAN1 = 0;
        this.BigHotAN2 = 0;
        this.BigHotAN3 = 0;
        this.BigHotAN4 = 0;
        this.BigHotAN5 = 0;
        this.BigHotAN6 = 0;
    }
    
    public void startBigHotbling() {
        this._timeHandler.schedule(this, 500L, 500L);
        GeneralThreadPool.get().execute(this);
        this.nowStart();
    }
    
    @Override
    public void run() {
        if (this._isOver) {
            try {
                Thread.sleep(10000L);
                this.clear();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        switch (++this._BigHottTime) {
            case 2: {
                this.toAllTimeM("60");
                this.donumber1();
                World.get().broadcastPacketToAll(new S_SystemMessage("距離大樂透開獎時間還有1個小時。"));
                break;
            }
            case 6000: {
                this.toAllTimeM("10");
                World.get().broadcastPacketToAll(new S_SystemMessage("距離大樂透開獎時間還有10分鐘。"));
                break;
            }
            case 6600: {
                this.toAllTimeM("5");
                World.get().broadcastPacketToAll(new S_SystemMessage("距離大樂透開獎時間還有5分鐘。"));
                break;
            }
            case 6720: {
                this.toAllTimeM("4");
                break;
            }
            case 6840: {
                this.toAllTimeM("3");
                break;
            }
            case 6960: {
                this.toAllTimeM("2");
                break;
            }
            case 7080: {
                this.toAllTimeM("1");
                World.get().broadcastPacketToAll(new S_SystemMessage("距離大樂透開獎時間還有1分鐘。"));
                break;
            }
            case 7190: {
                this.toAllTimeS("5");
                break;
            }
            case 7192: {
                this.toAllTimeS("4");
                break;
            }
            case 7194: {
                this.toAllTimeS("3");
                break;
            }
            case 7196: {
                this.toAllTimeS("2");
                break;
            }
            case 7118: {
                this.toAllTimeS("1");
                break;
            }
            case 7200: {
                this.Start();
                break;
            }
            case 7206: {
                this.toRate1(1);
                break;
            }
            case 7212: {
                this.toRate1(2);
                break;
            }
            case 7218: {
                this.toRate1(3);
                break;
            }
            case 7224: {
                this.toRate(1, this.BigHotAN1);
                break;
            }
            case 7234: {
                this.toRate(2, this.BigHotAN2);
                break;
            }
            case 7244: {
                this.toRate(3, this.BigHotAN3);
                break;
            }
            case 7254: {
                this.toRate(4, this.BigHotAN4);
                break;
            }
            case 7264: {
                this.toRate(5, this.BigHotAN5);
                break;
            }
            case 7274: {
                this.toRate(6, this.BigHotAN6);
                break;
            }
            case 7284: {
                this.checkVictory();
                final int BigHotId = this._BigHot.get_BigHotId();
                World.get().broadcastPacketToAll(new S_SystemMessage("大樂透 第 " + String.valueOf(BigHotId) + " 期開出的號碼是 " + this.BigHotAN + "。"));
                break;
            }
        }
    }
    
    private void toRate(final int type, final int info) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2162) {
                continue;
            }
            String Name = null;
            switch (type) {
                case 1: {
                    Name = "一";
                    break;
                }
                case 2: {
                    Name = "二";
                    break;
                }
                case 3: {
                    Name = "三";
                    break;
                }
                case 4: {
                    Name = "四";
                    break;
                }
                case 5: {
                    Name = "五";
                    break;
                }
                case 6: {
                    Name = "六";
                    break;
                }
            }
            final String toUser = "開出的第" + Name + "個號碼是(" + info + ")";
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
        }
    }
    
    private void toRate1(final int type) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2162) {
                continue;
            }
            String Name1 = null;
            int money = 0;
            switch (type) {
                case 1: {
                    Name1 = "頭獎";
                    money = this._BigHot.get_bigmoney1();
                    break;
                }
                case 2: {
                    Name1 = "一獎";
                    money = this._BigHot.get_bigmoney2();
                    break;
                }
                case 3: {
                    Name1 = "二獎";
                    money = this._BigHot.get_bigmoney3();
                    break;
                }
            }
            final String toUser = "本期" + Name1 + "的獎金是(" + money + ")";
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
        }
    }
    
    private void toAllTimeM(final String info) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2162) {
                continue;
            }
            final String toUser = "距離開獎$376 " + info + " $377";
            if (npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
        }
    }
    
    private void toAllTimeS(final String info) {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2162 || npc == null) {
                continue;
            }
            npc.broadcastPacketAll(new S_NpcChatPacket(npc, info, 2));
        }
    }
    
    private void Start() {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2162) {
                continue;
            }
            final String toUser = "大樂透即將開獎囉！！";
            if (npc != null) {
                npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
            }
            this._BigHot.set_isStart(true);
        }
        if (this._BigHot.get_yuanbao() == 0) {
            this._BigHot.add_yuanbao(L1Config._2164);
        }
        final L1BigHotbling BigHotInfo = BigHotblingLock.create().getBigHotbling(this._BigHot.get_BigHotId() - 1);
        if (BigHotInfo != null) {
            if (BigHotInfo.get_count() == 0) {
                if (BigHotInfo.get_money1() < L1Config._2166) {
                    this._BigHot.add_yuanbao(BigHotInfo.get_money1());
                }
                else {
                    this._BigHot.add_yuanbao(L1Config._2165);
                }
            }
            else {
                this._BigHot.add_yuanbao(L1Config._2165);
            }
            if (BigHotInfo.get_count1() == 0) {
                this._BigHot.add_yuanbao(BigHotInfo.get_money2());
            }
            if (BigHotInfo.get_count2() == 0) {
                this._BigHot.add_yuanbao(BigHotInfo.get_money3());
            }
        }
        else {
            this._BigHot.add_yuanbao(L1Config._2165);
        }
        this._BigHot.computationBigHot();
    }
    
    private void clear() {
        if (this.cancel()) {
            this._timeHandler.purge();
        }
        this.BigHotAN = null;
        this._BigHottTime = 0;
        this._isOver = false;
        this._BigHot.clear();
    }
    
    private void checkVictory() {
        for (final L1Object object : World.get().getObject()) {
            if (!(object instanceof L1NpcInstance)) {
                continue;
            }
            final L1NpcInstance npc = (L1NpcInstance)object;
            if (npc.getNpcTemplate().get_npcId() != L1Config._2162 || this.BigHotAN == null) {
                continue;
            }
            final int BigHotId = this._BigHot.get_BigHotId();
            final String toUser = "大樂透 $375 " + String.valueOf(BigHotId) + " 期開出的號碼是 " + this.BigHotAN + "。";
            if (npc != null) {
                npc.broadcastPacketAll(new S_NpcChatPacket(npc, toUser, 2));
            }
            this.isOver();
            this._BigHot.set_isStart(false);
        }
    }
    
    private void donumber1() {
        this.BigHotAN = "";
        while (this.BigHotAN.split(",").length < 6) {
            final int sk = 1 + (int)(Math.random() * 46.0);
            if (this.BigHotAN.indexOf(String.valueOf(sk) + ",") < 0) {
                this.BigHotAN = String.valueOf(this.BigHotAN) + String.valueOf(sk) + ",";
            }
            if (this.BigHotAN.split(",").length == 1) {
                this.BigHotAN1 = sk;
            }
            if (this.BigHotAN.split(",").length == 2) {
                this.BigHotAN2 = sk;
            }
            if (this.BigHotAN.split(",").length == 3) {
                this.BigHotAN3 = sk;
            }
            if (this.BigHotAN.split(",").length == 4) {
                this.BigHotAN4 = sk;
            }
            if (this.BigHotAN.split(",").length == 5) {
                this.BigHotAN5 = sk;
            }
            if (this.BigHotAN.split(",").length == 6) {
                this.BigHotAN6 = sk;
            }
        }
        this._BigHot.set_BigHotId1(this.BigHotAN);
    }
    
    private void isOver() {
        final int yuanbao = this._BigHot.get_yuanbao();
        final int yuanbao2 = this._BigHot.get_bigmoney1();
        final int yuanbao3 = this._BigHot.get_bigmoney2();
        final int yuanbao4 = this._BigHot.get_bigmoney3();
        final int count1 = this._BigHot.get_count1();
        final int count2 = this._BigHot.get_count2();
        final int count3 = this._BigHot.get_count3();
        final int count4 = this._BigHot.get_count4();
        BigHotblingLock.create().create(this._BigHot.get_BigHotId(), this.BigHotAN, yuanbao, yuanbao2, count1, yuanbao3, count2, yuanbao4, count3, count4);
        this._isOver = true;
    }
    
    private void nowStart() {
        final int BigHotId = IdFactory.get().nextBigHotId();
        this._BigHot.set_BigHotId(BigHotId);
        this._BigHot.set_isWaiting(true);
        this._BigHot.set_isBuy(true);
    }
}
