package com.add.BigHot;

public class L1BigHotbling
{
    private int _id;
    private String _number;
    private int _totalPrice;
    private int _count;
    private int _count1;
    private int _count2;
    private int _count3;
    private int _money1;
    private int _money2;
    private int _money3;
    
    public void set_id(final int i) {
        this._id = i;
    }
    
    public void set_number(final String i) {
        this._number = i;
    }
    
    public void set_totalPrice(final int i) {
        this._totalPrice = i;
    }
    
    public void set_money1(final int i) {
        this._money1 = i;
    }
    
    public void set_count(final int i) {
        this._count = i;
    }
    
    public void set_money2(final int i) {
        this._money2 = i;
    }
    
    public void set_count1(final int i) {
        this._count1 = i;
    }
    
    public void set_money3(final int i) {
        this._money3 = i;
    }
    
    public void set_count2(final int i) {
        this._count2 = i;
    }
    
    public void set_count3(final int i) {
        this._count3 = i;
    }
    
    public int get_id() {
        return this._id;
    }
    
    public String get_number() {
        return this._number;
    }
    
    public int get_totalPrice() {
        return this._totalPrice;
    }
    
    public int get_money1() {
        return this._money1;
    }
    
    public int get_count() {
        return this._count;
    }
    
    public int get_money2() {
        return this._money2;
    }
    
    public int get_count1() {
        return this._count1;
    }
    
    public int get_money3() {
        return this._money3;
    }
    
    public int get_count2() {
        return this._count2;
    }
    
    public int get_count3() {
        return this._count3;
    }
}
