package com.eric;

import java.util.Timer;
import com.lineage.server.utils.L1SpawnUtil;
import com.lineage.server.model.Instance.L1NpcInstance;
import java.util.TimerTask;

public class RandomMobDeleteTimer extends TimerTask
{
    private int _randomMobId;
    private L1NpcInstance _npc;
    
    public RandomMobDeleteTimer(final int randomMobId, final L1NpcInstance npc) {
        this._randomMobId = randomMobId;
        this._npc = npc;
    }
    
    @Override
    public void run() {
        this._npc.deleteMe();
        L1SpawnUtil.spawn(this._randomMobId);
        this.cancel();
    }
    
    public void begin() {
        final Timer timer = new Timer();
        if (RandomMobTable.getInstance().getTimeSecondToDelete(this._randomMobId) > 0) {
            timer.schedule(this, RandomMobTable.getInstance().getTimeSecondToDelete(this._randomMobId) * 1000);
        }
    }
}
